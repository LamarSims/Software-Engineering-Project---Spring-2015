<?php
/**
 * Class representation for the database's blogs table and the operations to manipulate the blogs table
 * Created by PhpStorm.
 * User: chad
 * Date: 2/10/15
 * Time: 10:52 AM
 */

class Blogs extends CI_Model
{

    /**
     * no-arg constructor for constructing a Blogs object
     */
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

    /**
     * returns the count of the number of Blogs that have been created and are in the database's blogs table
     * @return mixed
     */
    function count()
    {
        return $this->db->count_all('blogs');
    }

    /**
     * returns the specified blog, in the database's blogs table, identified by the specified blog_id, if id is found in
     * the database's blogs table, else returns false
     * @param $blog_id : the id number of the Blog to be queried for in the database
     * @return bool
     */
    function get_by_id($blog_id)
    {
        if ($query = $this->db->get_where('blogs', array('blog_id' => $blog_id)))
        {
            return $query->row();
        }
        else
        {
            return FALSE;
        }
    }

    /**
     * returns the specified number of records at the specified offset from the database's blogs table
     * @param int $number_of_records : specified number of records to return, if not specified default is 10
     * @param int $offset : specified offset to start retrieving records at in the database's blogs table
     * @return bool
     */
    function get($number_of_records = 10, $offset = 0)
    {
        if ($query = $this->db->get('blogs', $number_of_records, $offset))
        {
            return $query->result();
        }
        else
        {
            return FALSE;
        }
    }

    /**
     * inserts a created Blog into the database's blogs table
     * @param $title : the title for the Blog
     * @param $body : the textual body of the Blog
     * @param $posted : the date and time the Blog was posted
     * @param $user_id : the id of the user who posted the Blog
     * @return bool
     */
    function insert($title, $body, $posted, $user_id)
    {
        $data = array(
            'title' => $title,
            'body' => $body,
            'posted' => $posted,
            'user_id' => $user_id
        );

        if ($statement = $this->db->insert('blogs', $data))
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }





}