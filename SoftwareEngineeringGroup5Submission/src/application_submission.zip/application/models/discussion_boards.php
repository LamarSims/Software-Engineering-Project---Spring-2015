<?php
/**
 * Created by PhpStorm.
 * User: Chad
 * Date: 3/22/2015
 * Time: 5:05 PM
 */
class discussion_boards extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }

    public function get_by_id($discussion_board_id)
    {
        return $this->db->get_where('discussion_boards', array('discussion_board_id' => $discussion_board_id));
    }


}