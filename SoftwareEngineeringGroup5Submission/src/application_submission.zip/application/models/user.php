<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
 * Class representation for the database's users table and the operations to manipulate the users table
 * Author: Chad
 *
 */
class User extends CI_Model
{
    /**
     * no-arg constructor for constructing a User
     */
	function __construct()
	{
		parent::__construct();
	}
	
	/* Deprecated */
	function getuser($email, $password)
	{
		
		$password = sha1($password);
		
		if ($query = $this->db->get_where('users', array('email' => $email, 'password' => $password)))
		{
			return $query->result();
		}
		else
		{
			return FALSE;
		}
	}

    /**
     * Retrieves a specified number of Users from the database's users table
     * @param int $number_of_records : the number of Users to be retrieved; default is 50
     * @param int $offset : offset to start retrieving Users; default to start retrieving is 0
     * @return mixed
     */
	function get($number_of_records = 50, $offset = 0)
	{
		return $this->db->get('users', $number_of_records, $offset);
	}

    /**
     * Returns the row of the users table with the given email if it exists
     * @param $email : the email of the User to be retrieved
     * @return bool
     */
	function get_by_email($email)
	{
		if ($query = $this->db->get_where('users', array('email' => $email)))
		{
			return $query->row();
		}
		else // User does not exist in the database.
		{
			return FALSE;
		}
	}

    /**
     * Returns the row of the users table with the given user_id if it exists
     * @param $user_id : the id of the User to be returned
     * @return bool
     */
	function get_by_id($user_id)
	{
		if ($query = $this->db->get_where('users', array('user_id' => $user_id)))
		{
			return $query->row();
		}
		else // User does not exist in the database.
		{
			return FALSE;
		}
	}

    /**
     * Inserts user into the database
     * @param $username : the username of the User
     * @param $email : the email for the User
     * @param $password : the password for the User
     * @param $first_name : the first name of the User
     * @param $last_name : the last name of the User
     * @return bool
     */
	function insertuser($username, $email, $password, $first_name, $last_name)
	{
        $data = array(
            'username' => $username,
            'email' => $email,
            'password' => $password,
            'first_name' => $first_name,
            'last_name' => $last_name
        );
		if ($query = $this->db->insert('users', $data))
		{
			return TRUE;		
		}
		else
		{
			return FALSE;
		}
	}

    /**
     * Updates the permission account level of a User
     * @param $user_id : the id of the user whose account level should be updated
     * @param $account_level : the current account level of the user
     * @return bool
     */
	function update_account_level($user_id, $account_level)
	{
		$update = array(
			'account_level' => $account_level
		);
		$this->db->where('user_id', $user_id);
		if ($statement = $this->db->update('users', $update))
		{
			return TRUE;
		}
		else
		{
			return FALSE;
		}
	}

    /**
     * Gets all Users with a specified permission account level
     * @param $minimum_account_level : the account level to be queried
     * @return mixed
     */
    function get_by_account_level($minimum_account_level)
    {
        $this->db->where('account_level >=', $minimum_account_level);
        return $this->db->get('users');
    }

    /**
     * Return the string representation of the account level for the User
     * @param $account_level : the account level to be converted
     * @return string
     */
    function get_title($account_level){
        switch($account_level){
            case 0: return 'Regular';
            case 1: return 'Club Member';
            case 2: return 'Treasurer';
            case 3: return 'Advisor';
            case 4: return 'Secretary';
            case 5: return 'Vice-President';
            case 6: return 'President';
            case 7: return 'Developer';
        }
    }

	public function get_role_name($role)
	{
		switch ($role)
		{
			case 0: return '';
			case 1: return 'Photographer';
			case 2: return 'Director';
			default: return '';
		}
	}

    /**
     * Get the User's image_id that corresponds to the image_id in the database's images table,
     * to display their profile image on their profile page
     * @param $user_id : the id of the User whose profile image should be returned
     * @return mixed
     */
    function get_user_image($user_id){
        $this->db->select('users.image_id');
        $this->db->from('users');
        $this->db->join('images', 'users.image_id = images.image_id', 'left');
        $this->db->where('user_id', $user_id);
        if ($image_id = $this->db->get()->row()->image_id);
        return $this->images->get_image($image_id);
    }

    /**
     * Get the maximum image_id in the database's images table to be used
     * as the user image_id in the database's users table
     * @return mixed
     */
    function get_image_maxid(){
        return $this->db->select_max('image_id', 'max')->get('images')->row()->max;
    }

    /**
     * Insert user's profile image into the database's images table and set image in database's users table
     * @param $user_id : the id of the User who is inserting an image
     * @param $file_path : the file path of the image
     * @param $file_extension : the file extension of the image
     */
    function insert_image($user_id, $file_path, $file_extension){
        $this->db->query('call insert_user_image(' . $user_id . ',\'' . $file_path . '\',\'' . $file_extension .'\')');
    }

    /**
     * Deletes the User's profile image
     * @param $user_image_id : the id of the image to be deleted
     */
    function delete_profile_image($user_image_id){
        $this->images->delete_image($user_image_id);
    }

	public function update_user_role($user_id, $role_id)
	{
		$this->db->where(
			array('user_id' => $user_id)
		);
		return $this->db->update(
			'users',
			array('role_id' => $role_id)
		);
	}
}