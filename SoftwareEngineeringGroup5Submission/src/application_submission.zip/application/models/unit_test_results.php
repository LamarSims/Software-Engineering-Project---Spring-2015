<?php
/**
 * Created by PhpStorm.
 * User: cg03734
 * Date: 4/23/2015
 * Time: 2:39 PM
 */

class unit_test_results extends CI_Model {

    function whoa()
    {
        if (true ? $foo = 'hi' : $foo = 'hello')
        {

        }
    }

    function get_results()
    {
        return $this->db->get('unit_test_results');
    }

    function insert($insertion_array)
    {
        return $this->db->insert('unit_test_results', $insertion_array);
    }

    function delete_all()
    {
        $this->db->where('test_id > 0');
        return $this->db->delete('unit_test_results');
    }

}