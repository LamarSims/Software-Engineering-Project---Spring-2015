<?php
/**
 * Class representation for the database's suggestions table and the operations to manipulate the suggestions table
 * Created by PhpStorm.
 * User: chad
 * Date: 2/11/15
 * Time: 9:04 AM
 */

class suggestions extends CI_Model
{

    /**
     * no-arg constructor for constructing suggestions
     */
    function __construct()
    {
        parent::__construct();
    }


    /**
     * Returns a specified number of records from the database's suggestions table
     * @param int $number_of_records : the number of suggestions to be returned; default number to return is 10
     * @param int $offset : the offset to start retrieving suggestions; default for retrieval is 0
     * @return mixed
     */
    function get($number_of_records = 10, $offset = 0)
    {
        return $this->db->get('suggestions', $number_of_records, $offset);
    }

    function get_where($number_of_records = 10, $offset = 0, $where_clause = array())
    {
        return $this->db->get_where('suggestions', $number_of_records, $offset, $where_clause);
    }


    /**
     * Returns a specified number of records, ordered by the date of submission, from the database's suggestions table
     * @param int $number_of_records : the number of suggestions to be returned; default number to return is 10
     * @param int $offset : the offset to start retrieving suggestions; default for retrieval is 0
     * @return mixed
     */
    function get_order_by_date($number_of_records = 10, $offset = 0)
    {
        return $this->db->order_by('submitted', 'desc')->get('suggestions', $number_of_records, $offset);
    }

    /**
     * Insert suggestions record into the DB.
     *
     * @param $contact_first_name : first name of the contact making the suggestion
     * @param $contact_last_name : the last name of the contact making the suggestion
     * @param $contact_email : the email of the contact making the suggestion
     * @param $contact_phone : the phone number of the contact making the suggestion
     * @param $subject : the subject that the contact wishes to suggest
     * @param $body : the description for the suggestion
     * @return bool Whether the insertion was successful or not.
     */
    function insert($contact_first_name, $contact_last_name, $contact_email, $contact_phone, $subject, $body)
    {
        // Data for the record insertion
        $data = array(
            'contact_first_name' => $contact_first_name,
            'contact_last_name' => $contact_last_name,
            'contact_email' => $contact_email,
            'contact_phone' => $contact_phone,
            'subject' => $subject,
            'body' => $body
        );

        if ($statement = $this->db->insert('suggestions', $data))
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }

    /**
     * Returns whether or not the suggestions was deleted from the database's suggestions table
     * @param $suggestion_id : the id of the suggestion to be deleted
     * @return bool
     */
    function delete($suggestion_id)
    {
        if ($statement =  $this->db->delete('suggestions', array('suggestion_id' => $suggestion_id)))
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }

}