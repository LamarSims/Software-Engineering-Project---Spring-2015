<?php
/**
 * Created by PhpStorm.
 * User: Chad Golden
 * Date: 3/17/2015
 * Time: 12:44 PM
 *
 * Represents the `dynamic_content` table in the database. Includes the basic
 * CRUD operations.
 *
 */
 class dynamic_content extends CI_Model
 {

     /**
      * no-arg constructor for constructing dynamic_content
      */
     function __construct()
     {
         parent::__construct();
     }

     /**
      * Returns the specified dynamic_content in the database's dynamic content table
      * @param $content_id : the id of the dynamic content to be returned
      * @return mixed
      */
     function get_by_id($content_id)
     {
         $this->db->where('content_id', $content_id);
         return $this->db->get('dynamic_content');
     }

     /**
      * Inserts dynamic_content into the database's dynamic content table
      * @param $content_id : the id of the dynamic_content being inserted
      * @param $content_body : the body/content of the dynamic_content
      * @return mixed
      */
     function insert($content_id, $content_body)
     {
         $data = array(
             'content_id' => $content_id,
             'content_body' => $content_body
         );
         return $this->db->insert('dynamic_content', $data);
     }

     /**
      * Updates a specified dynamic_content in the database's dynamic_content table
      * @param $content_id : the id of the dynamic_content to be updated
      * @param $content_body : the new body/content for the dynamic_content
      * @return mixed
      */
     function update($content_id, $content_body)
     {
         $data = array(
             'content_body' => $content_body
         );
         $this->db->where('content_id', $content_id);
         return $this->db->update('dynamic_content', $data);
     }

     /**
      * Deletes a the specified dynamic_content from the database's dynamic_content table
      * @param $content_id : the id of the dynamic_content to be deleted from the database
      * @return mixed
      */
     function delete($content_id)
     {
         $this->db->where('content_id', $content_id);
         return $this->db->delete('dynamic_content');
     }

 }