<?php
/**
 * Class Videos_tags
 *
 * Class representation for the database's videos_tags table and the operations to manipulate the videos_tags table
 *
 * @package content
 *
 */
class Videos_tags extends CI_Model
{

    /**
     * no-arg constructor for constructing Videos_tags
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Return all Videos_tags in the database's videos_tags table
     * @return mixed
     */
    public function get()
    {
        return $this->db->get('videos_tags');
    }

    /**
     * Returns a set of tags for a particular video_id.
     *
     * @param string $video_id The YouTube ID number for the video.
     *
     * @return mixed The set of tags for the desired video.
     */
    public function get_by_video($video_id)
    {
        return $this->db->get('videos_tags', array('video_id' => $video_id));
    }

    /**
     * Retrieve Videos_tags from the database's videos_tags table, by specifying their tag_name
     * @param $tag_name : the tag name of Videos_tags to be retrieved
     * @return mixed
     */
    public function get_by_tag_name($tag_name)
    {
        return $this->db->get('videos_tags', array('tag_name' => $tag_name));
    }

    /**
     * Inserts Videos_tags into the database's videos_tags table
     * @param array $data_array : an array containing the Videos_tags's, video_id and tag_name
     * @return mixed
     */
    public function insert($data_array = array())
    {
        return $this->db->insert('videos_tags', $data_array);
    }

}