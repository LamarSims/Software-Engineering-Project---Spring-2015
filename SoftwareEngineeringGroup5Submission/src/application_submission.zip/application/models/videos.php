<?php
/**
 * Class representation for the database's videos table and the operations to manipulate the videos table
 * Created by PhpStorm.
 * User: Chad
 * Date: 4/4/2015
 * Time: 1:24 PM
 */

class videos extends CI_Model implements Searchable {

    /**
     * no-arg constructor for constructing videos
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Returns all of the videos in the database's videos table
     * @return mixed
     */
    public function get($limit = 20, $offset = 0)
    {
        $this->db->order_by('inserted desc');
        return $this->db->get('videos', $limit, $offset);
    }

    /**
     * Inserts videos into the database's videos table
     * @param array $insert_data : the data representing the video being inserted
     * @return mixed
     */
    public function insert($insert_data = array())
    {
        return $this->db->insert('videos', $insert_data);
    }

    /**
     * Searches the database's videos table based on a specified keyword, and returns the results
     * @param $keyword : the keyword used to query videos in the database's videos table
     */
    public function search($keywords)
    {
        $keywords = explode(' ', $keywords);

        $this->db->select('videos.video_id as name_or_id');
        $this->db->select('site_description as details');
        $this->db->select('tag_name as tag_name');
        $this->db->join('videos_tags', 'videos.video_id = videos_tags.video_id', 'left');
        $this->db->like('site_description', $keywords[0]);
        $this->db->or_like('tag_name', $keywords[0]);
        $count = 0;
        foreach ($keywords as $keyword)
        {
            if ($count++ == 0)  continue;
            $this->db->or_like('tag_name', $keyword);
            $this->db->or_like('site_description', $keyword);
        }
        $this->db->group_by(array('videos.video_id', 'site_description'));
        return $this->db->get('videos');
    }
}