<?php
/**
 * Class representation for the database's discussion_topics table and the operations to manipulate the
 * discussion_topics table
 * Created by PhpStorm.
 * User: Chad
 * Date: 3/20/2015
 * Time: 2:17 PM
 */

class discussion_topics extends CI_Model
{

    /**
     * no-arg constructor for constructing a discussion_topics object
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Returns all of the discussion_topics for the specified discussion board
     * @param $discussion_board_id : the id of the discussion board to get discussion_topics form
     * @return mixed
     */
    public function get_by_discussion_board($discussion_board_id)
    {
        $this->db->where('discussion_board_id', $discussion_board_id);
        return $this->db->get('discussion_topics_with_authors');
    }

    /**
     * Returns discussion_topics for the specified discussion board on the specified page number
     * @param $discussion_board_id : the id of the discussion board to get discussion_topics form
     * @param $page_number : the page number to get the discussion_topics from
     * @param $results_per_page : how many results should be returned
     * @return mixed
     */
    public function get_by_discussion_board_by_page($discussion_board_id, $page_number, $results_per_page)
    {
        $offset = ($page_number - 1) * $results_per_page; // For pagination.
        $this->db->where('discussion_board_id', $discussion_board_id);
        $this->db->order_by('timestamp', 'DESC'); // Newest posts first.
        $this->db->limit($results_per_page);
        $this->db->offset($offset);
        return $this->db->get('discussion_topics_with_authors');
    }

    /**
     * Returns discussion_topics on the specified page number
     * @param int $page_number : the page number to get discussion_topics for, if page_number is not specified
     * discussion_topics will be got for the first page
     * @return mixed
     */
    public function get_by_page($page_number = 1)
    {
        $offset = ($page_number - 1) * 20;
        return $this->db->get('discussion_topics_with_authors', 20, $offset);
    }

    /**
     * Inserts discussion_topics into the database's discussion_topics table
     * @param $title : title of the discussion_topics
     * @param $body : body/content of the discussion_topics
     * @param $user_id : the id of the user who created the discussion_topics
     * @param $discussion_board_id : the id for the discussion board the discussion_topics were created for
     * @return mixed
     */
    public function insert($title, $body, $user_id, $discussion_board_id)
    {
        $data = array(
            'title' => $title,
            'body' => $body,
            'user_id' => $user_id,
            'discussion_board_id' => $discussion_board_id
        );
        return $this->db->insert('discussion_topics', $data);
    }



}