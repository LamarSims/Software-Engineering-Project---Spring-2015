<?php
/**
 * Class representation for the database's images table and the operations to manipulate the images table
 * Created by PhpStorm.
 * User: Chad
 * Date: 3/6/2015
 * Time: 2:02 PM
 */
class images extends CI_Model
{

    /**
     * no-arg constructor to construct images
     */
    function __construct()
    {
        parent::__construct();
    }

    /**
     * Returns all of the images in the database's images table
     * @return mixed
     */
    function get_all_rows()
    {
        return $this->db->get('images');
    }

    /**
     * Returns all images that are not images owned by users
     * @return mixed
     */
    function get_all_nonuser_images(){
        return $this->db->get('non_user_images');
    }

    /**
     * Returns a specific image from the database's images table
     * @param $image_id : the id of the image to be returned
     * @return mixed
     */
    function get_image($image_id){
        return $this->db->get_where('images', array('image_id' => $image_id));
    }

    /**
     * Returns the maximum image id with one added to it
     * @return mixed
     */
    function get_maxid(){
        return $this->db->select_max('image_id', 'max')->get('images')->row()->max + 1;
    }

    /**
     * Insert images into the database's images table
     * @param $file_path : the file path of the image to be inserted
     * @param $file_extension : the extension of the file to be inserted
     * @return mixed
     */
    function insert_image($file_path, $file_extension){
        $data = array(
            'path' => $file_path,
            'filetype' => $file_extension
        );
        return $this->db->insert('images', $data);
    }

    /**
     * Deletes image by the specified image_id in the database's images table
     * @param $image_id : the id of the image to be deleted from the database
     */
    function delete_image($image_id){
        $this->db->where('image_id', $image_id);
        $this->db->delete('images');
    }

}