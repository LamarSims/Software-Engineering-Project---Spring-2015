<?php
/**
 * Class representation for the database's discussion_replies table and the operations to manipulate the
 * discussion_replies table
 * Created by PhpStorm.
 * User: Chad
 * Date: 3/20/2015
 * Time: 2:28 PM
 */
class discussion_replies extends CI_Model
{

    /**
     * no-arg constructor for constructing discussion_replies
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function get_replies_by_discussion_topic_id($discussion_topic_id)
    {
        return $this->db->get_where('discussion_replies_with_authors', array('discussion_topic_id' => $discussion_topic_id));
    }

    /**
     * Rename of above.
     * Gets all of the replies for a discussion topic specified by the discussion_topic_id
     * @param $discussion_topic_id : the id of the discussion topic to get replies for
     * @return mixed
     */
    public function get_by_discussion_topic_id($discussion_topic_id)
    {
        return $this->db->get_where('discussion_replies_with_authors', array('discussion_topic_id' => $discussion_topic_id));
    }

    /**
     * Inserts discussion_replies into the database's discussion_replies table
     * @param $user_id : the id of the user who made the reply
     * @param $discussion_topic_id : the id of the discussion topic being replied to
     * @param $body : the body/content of the reply
     * @return mixed
     */
    public function insert($user_id, $discussion_topic_id, $body)
    {
        $data = array(
            'user_id' => $user_id,
            'discussion_topic_id' => $discussion_topic_id,
            'title' => '',
            'body' => $body
        );
        return $this->db->insert('discussion_replies', $data);
    }

}