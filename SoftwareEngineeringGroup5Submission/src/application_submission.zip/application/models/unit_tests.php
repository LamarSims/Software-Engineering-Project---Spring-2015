<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 4/30/15
 * Time: 7:02 PM
 */
class unit_tests extends CI_Model {

    function __construct()
    {
        parent::__construct();
    }

    function get()
    {
        $this->db->order_by('unit_test_id desc');
        return $this->db->get('unit_tests');
    }

    function insert($count)
    {
        return $this->db->insert('unit_tests', array('coverage' => $count));
    }

}