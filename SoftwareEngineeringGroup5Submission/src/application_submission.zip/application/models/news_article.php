<?php

/**
 * Class representation for the database's news_articles table and the operations to manipulate the
 * news_articles table
 */
class News_article extends CI_Model 
{

    /**
     * no-arg constructor for constructing News_article
     */
	function __construct()
	{
		// Call the Model constructor
		parent::__construct();
	}

    /**
     * Retrieve the records in the `news_articles` table
     * @param int $number_of_records : the number of records to retrieve; default to retrieve is 10
     * @param int $offset : the offset to start retrieving records; default offset to start at is 0
     * @return bool
     */
	function get($number_of_records = 10, $offset = 0)
	{
		if ($query = $this->db->get('news_articles', $number_of_records, $offset))
		{
			return $query->result();
		}
		else
		{
			return FALSE;
		}
	}

    /**
     * Returns the count of all of the New_articles in the database's news_articles table
     * @return mixed
     */
	function count()
	{
		return $this->db->count_all('news_articles');
	}

    /**
     * Returns a specified News_article from the database's news_articles table
     * @param $news_id : the id of the News_article to be returned
     * @return bool
     */
	function get_by_id($news_id)
	{
		if ($query = $this->db->get_where('news_articles', array('news_id' => $news_id)))
		{
			return $query->row();
		}
		else
		{
			return FALSE;
		}
	}

    /**
     * Inserts News_article into the database's news_articles table
     * @param $title : the title for the News_article
     * @param $body : the body/content for the News_article
     * @return bool
     */
	function insert($title, $body)
	{
		$data = array(
				'title' => $title,
				'body' => $body
		);
		
		if ($statement = $this->db->insert('news_articles', $data)) 
		{
			return TRUE;
		}
		else
		{
			return FALSE;
		}
	}
}
