<?php
/**
 * Class representation for the database's discussions table and the operations to manipulate the discussions table
 * Created by PhpStorm.
 * User: Chad
 * Date: 3/7/2015
 * Time: 10:49 AM
 */

class discussions extends CI_Model
{

    /**
     * no-arg constructor for constructing discussions objects
     */
    function __construct()
    {
        parent::__construct();
    }

    /**
     * Returns all of the discussions inside of the databases's discussions table
     */
    function get()
    {
        $this->db->get('discussions');
    }

    /**
     * Returns the discussions for the discussion page. The discussions are actually replies
     * to the discussion of discussion_id = 2.
     */
    function get_discussion_page()
    {
        $this->db->get_where('discussions', array('reply_id', 2));
    }

    /**
     * Returns custom discussion pages based on the specified page_id
     * @param $page_id : the id of the custom page to return
     * @return mixed
     */
    function get_by_custom_page($page_id) {
        $this->db->where('page_id', $page_id);
        return $this->db->get('discussions_for_custom_page');
    }

    /**
     * Returns the replies corresponding to a custom discussion page
     * @param $page_id : the id of the custom page whose replies are to be returned
     * @return mixed
     */
    function replies_by_custom_page($page_id)
    {
        //$this->db->where('page_id', $page_id);
        //return $this->db->get('replies_for_custom_page');
        return $this->db->get_where('replies_for_custom_page', array('page_id' => $page_id));
    }

}