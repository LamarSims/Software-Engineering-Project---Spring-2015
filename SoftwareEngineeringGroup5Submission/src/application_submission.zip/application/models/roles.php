<?php

/**
 * Class roles
 *
 * Represents the abstraction model for the roles table in the database.
 *
 */
class roles extends CI_Model
{

    /**
     * Default no-arg class contructor for the roles model.
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Returns the roles records from the database.
     *
     * @return object The roles records within the database.
     */
    public function get_all()
    {
        return $this->db->get('roles');
    }

    /**
     * Returns a roles record if it exists from the DB when given an ID as an argument.
     *
     * @param int $role_id The ID number of the role.
     * @return object The roles record.
     */
    public function get_by_id($role_id)
    {
        return $this->db->get_where('roles', array('role_id' => $role_id));
    }

    public function insert($params = array('role_name' => '', 'role_description' => ''))
    {
        return $this->db->insert('roles', $params);
    }

    /**
     *
     * Returns the count of rows for the roles table in the database.
     *
     * @return string The number of rows for the roles table in the database.
     */
    public function count()
    {
        return $this->db->count_all_results('roles');
    }

}