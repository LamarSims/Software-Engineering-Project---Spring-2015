<?php
/**
 * Class representation for the database's custom_pages table and the operations to manipulate the custom_pages table
 * Created by PhpStorm.
 * User: Chad
 * Date: 3/6/2015
 * Time: 4:54 PM
 */
class custom_pages extends CI_Model implements Searchable {

    /**
     * no-arg constructor for constructing custom_pages
     */
    function __construct()
    {
        parent::__construct();
    }

    /**
     * returns all of the custom_pages created and inserted into the database's custom_pages table
     * @return mixed
     */
    function get($limit = 1000, $offset = 0) {
        return $this->db->get('custom_pages_comments_authors', $limit, $offset);
    }

    /**
     * Returns all the custom pages created and inserted into the database's custom pages table. Stored by
     * descending post dates.
     * @param int $limit
     * @param int $offset
     */
    function get_latest($limit = 1000, $offset = 0)
    {
        $this->db->order_by('created', 'desc');
        return $this->db->get('custom_pages_comments_authors', $limit, $offset);
    }

    /**
     * returns a specific custom_page from the database's custom_pages table based on the specified page_id
     * @param $page_id : the specific page id to query for in the database's custom_pages table
     * @return mixed
     */
    function get_custom_page($page_id)
    {
       // return $this->db->get_where('custom_pages_with_author_and_count_of_comments', array('page_id' => $page_id));
        return $this->db->get_where('custom_pages_comments_authors', array('page_id' => $page_id));
    }

    /**
     * returns the author/user who created the custom_page specified by the page_id
     * @param $page_id : the specific page id to query the author for
     * @return mixed
     */
    function get_author_of_page($page_id)
    {
        $this->db->select('username');
        $this->db->from('users');
        $this->db->join('custom_pages', 'users.user_id = custom_pages.user_id');
        $this->db->where(array('page_id' => $page_id));
        return $this->db->get();
    }

    /**
     * returns the title of the custom_page specified by the page_id
     * @param $page_id : the specific page id to query for and get it's title
     * @return mixed
     */
    function get_title($page_id)
    {
        $this->db->select('title');
        return $this->db->get_where('custom_pages', array('page_id' => $page_id));
    }

    /**
     * returns the count of the number of custom pages that have been created and are in its database table
     * @return mixed
     */
    function count()
    {
        return $this->db->count_all('custom_pages');
    }

    /**
     * inserts a created custom_page into the database's custom_pages table, and returns whether it was
     * successfully inserted
     * @param $title : the title of the custom_page
     * @param $body : the body or content of the custom_page
     * @param $account_level : the permission level for who can view the custom_page
     * @param $user_id : the id of the user who created the custom_page
     * @return bool
     */
    function insert($title, $body, $account_level, $user_id) {

        $data = array(
            'title' => $title,
            'body' => $body,
            'account_level' => $account_level,
            'user_id' => $user_id
        );

        if ($statement = $this->db->insert('custom_pages', $data))
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }

    }

    /**
     * updates a specified custom_page in the database's custom_pages table based on the page_id, and
     * returns whether is was successfully updated
     * @param $page_id : the id for the custom_page to be updated
     * @param $title : the title for the custom_page
     * @param $body : the body/content for the custom_page
     * @param $account_level : the permission level for who can view the custom_page
     * @param $user_id : the id for the user who created the custom_page
     * @return bool
     */
    function update($page_id, $title, $body, $account_level, $user_id) {

        $data = array(
            'title' => $title,
            'body' => $body,
            'account_level' => $account_level,
            'user_id' => $user_id
        );

        $this->db->where('page_id', $page_id);

        if ($statement = $this->db->update('custom_pages', $data))
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }

    }

    /**
     * deletes the custom_page specified by page_id in the database's custom_pages table, and returns
     * whether the custom_page was successfully deleted
     * @param $page_id : the id of the custom_page to be deleted
     * @return bool
     */
    function delete($page_id)
    {
        if ($statement = $this->db->delete('custom_pages', array( 'page_id' => $page_id)))
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }

    public function search($keywords)
    {
        $keywords = explode(' ', $keywords);

        $this->db->select('custom_pages.page_id as name_or_id');
        $this->db->select('title as details');
        $this->db->select('tag_name as tag_name');
        $this->db->join('custom_pages_tags', 'custom_pages.page_id = custom_pages_tags.page_id', 'left');
        $this->db->like('title', $keywords[0]);
        $this->db->or_like('body', $keywords[0]);
        $this->db->or_like('tag_name', $keywords[0]);
        $count = 0;
        foreach ($keywords as $keyword)
        {
            if ($count++ == 0)  continue;
            $this->db->or_like('title', $keyword);
            $this->db->or_like('tag_name', $keyword);
            $this->db->or_like('body', $keyword);
        }
        $this->db->group_by(array('custom_pages.page_id', 'title'));
        return $this->db->get('custom_pages');
    }

}