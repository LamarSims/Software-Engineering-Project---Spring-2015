<?php
/**
 * Class representation for the database's events table and the operations to manipulate the events table
 * Created by PhpStorm.
 * User: cg03734
 * Date: 3/12/2015
 * Time: 2:11 PM
 */

class events extends CI_Model
{

    /**
     * no-arg constructor for constructing events
     */
    function __construct()
    {
        parent::__construct();
    }

    /**
     * Returns all the events in the database's events table
     * @return mixed
     */
    function get_all_rows()
    {
        return $this->db->get('events');
    }

    /**
     * Returns a specific events from the database's events table
     * @param $event_id : the id of the event to be returned
     * @return mixed
     */
    function get_event($event_id)
    {
        return $this->db->get_where('events', array('event_id' => $event_id));
    }

    /**
     * Returns all events on a specified date
     * @param $date : the date for the events
     * @return mixed
     */
    function get_event_by_date($date)
    {
        $condition = array(
            'date' => $date
        );
        return $this->db->get_where('events', $condition);
    }

    /**
     * Inserts events into the database's events table
     * @param $event_name : the name of the events
     * @param $date : the date the events take place
     * @param $time : the time of the day the events take place
     * @param $location : the location the events take place at
     * @param $event_description : a description of the event
     * @return mixed
     */
    function insert_event($event_name, $date, $time, $location, $event_description)
    {
        $data = array(
          'event_name' => $event_name,
            'date' => $date,
            'time' => $time,
            'location' => $location,
            'event_description' => $event_description
        );
        return $this->db->insert('events', $data);
    }

    public function delete_event($event_id)
    {
        return $this->db->delete('events', array('event_id' => $event_id));
    }

}