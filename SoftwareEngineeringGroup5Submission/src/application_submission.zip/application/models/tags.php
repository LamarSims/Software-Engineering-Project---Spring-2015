<?php
/**
 * Class representation for the database's tags table and the operations to manipulate the tags table
 * Created by PhpStorm.
 * User: Chad
 * Date: 4/4/2015
 * Time: 8:20 AM
 */

class Tags extends CI_Model
{

    /**
     * no-arg constructor for constructing Tags
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Retrieves all tags.
     */
    public function get()
    {
        return $this->db->get('tags');
    }

    /**
     * Retrieve Tag by id. The id field for Tag is "tag_name" of type VARCHAR(30) in the mysql Db.
     * @param $tag_name : the name of the Tag to be retrieved
     * @return mixed
     */
    public function get_by_id($tag_name)
    {
        return $this->db->get('tags', array('tag_name' => $tag_name));
    }

    /**
     * Does the same as get_by_id()...
     * @param $tag_name : the name of the Tag to be retrieved
     * @return mixed
     */
    public function get_by_name($tag_name)
    {
        return $this->get_by_id($tag_name);
    }

    /**
     * Deletes a Tag from the database's tags table
     * @param $tag_name : the name of the Tag to be deleted
     * @return mixed
     */
    public function delete($tag_name)
    {
        return $this->db->delete('tags', array('tag_name' => $tag_name));
    }

    /**
     * Inserts Tags into the database's tags table
     * @param $tag_name : the name of the Tag
     * @param $tag_description : the description for the Tag
     * @return mixed
     */
    public function insert($tag_name, $tag_description)
    {
        $insert_data = array(
            'tag_name' => $tag_name,
            'description' => $tag_description
        );
        return $this->db->insert('tags', $insert_data);
    }

}