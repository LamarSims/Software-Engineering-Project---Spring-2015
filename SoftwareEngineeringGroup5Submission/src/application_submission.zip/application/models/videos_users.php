<?php
/**
 * Created by PhpStorm.
 * User: Chad
 * Date: 4/4/2015
 * Time: 12:59 PM
 */

class Videos_users extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }

    public function get()
    {
        return $this->db->get('videos_users');
    }

    public function get_by_tag_name($tag_name)
    {
        return $this->db->get('videos_users', array('tag_name' => $tag_name));
    }

    public function insert($data_array = array())
    {
        return $this->db->insert('videos_users', $data_array);
    }

}