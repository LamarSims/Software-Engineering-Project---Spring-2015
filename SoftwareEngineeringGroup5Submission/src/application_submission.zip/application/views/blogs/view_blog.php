<div class="container body-content">
    <div class="col-xs-12 col-md-8 col-md-offset-2">
        <div class="well">
            <h1>
                <?php echo $article->title; ?>
            </h1>
            <p class="text-muted">
                <small>
                    <em>
                        posted <?php echo date('F j, Y, g:i a') . ' by '; ?>
                        <a href="">
                            <?php echo 'author'; ?>
                        </a>
                    </em>
                </small>
            </p>
            <div class="row">
                <div class="col-xs-10 col-xs-offset-1">
                    <img style="margin-left: auto; margin-right: auto; border: 1px solid gray;" class="img-responsive" src="http://placehold.it/400x300" />
                </div>
            </div>
            <br />
            <div class="row">
                <div class="col-xs-10 col-xs-offset-1">
                    <p>
                        <?php echo nl2br($article->body); ?>
                    </p>
                </div>
            </div>
        </div>
        <div class="well">
            <h3>
                Comments
                <small>
                    <?php echo rand(0, 100); ?>
                </small>
            </h3>
            <hr />
            <?php $comments = array(array(
                'author' => 'AwesomeDude3',
                'body' => 'I\'m not quite sure about this. I would do this differently.'
            ),array(
                'author' => 'HiImLeonardMaltin',
                'body' => 'This is excellent news!'
            ));
            foreach($comments as $comment) { ?>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <?php echo $comment['author'] . ' says:'; ?>
                        <span class="text-muted" style="float: right">
						<small>
                            <em>
                                <?php echo date('F j, Y, g:i a'); ?>
                            </em>
                        </small>
					</span>
                    </div>
                    <div class="panel-body">
                        <?php echo $comment['body']; ?>
                    </div>
                </div>
            <?php } ?>
            <div class="row">
                <div class="col-xs-12 col-md-10 col-md-offset-1">
                    <form class="form-horizontal" method="post" action="/se/test/index.php/news/insert">
                        <legend>
                            Post your own Comment!
                        </legend>
                        <div class="form-group">
                            <div class="col-md-12">
                                <textarea class="form-control" id="comment_body" name="comment_body" rows="10" placeholder="Type your comment here..."></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-12">
                                <div class="text-center">
                                    <input class="btn btn-primary btn-border" type="submit" value="Post Comment"
                                </div>

                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>