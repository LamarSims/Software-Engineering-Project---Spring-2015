<div class="container body-content">
	<div class="panel panel-danger">
		<div class="panel-heading">
			<h3>
				<span class="glyphicon glyphicon-remove-circle">&nbsp;</span>
				<?php echo $error_header; ?>
			</h3>
		</div>
		<div class="panel-body">
			<p>
				<?php echo $error_message; ?>
			</p>
		</div>
	</div>
</div>