<div class="container body-content">
	<div class="row">
		<div class="col-xs-12 col-md-6">
			<div class="panel panel-danger">
				<div class="panel-heading">
					<h3>
						<div style="display: inline; text-align: right" class="text-right">
							<span class="glyphicon glyphicon-remove-circle"></span>
						</div>
						&nbsp;404 - Page Not Found
					</h3>					
				</div>
				<div class="panel-body">
					The page you requested was not found.
					<div style="display: block; margin-top: 20px; text-align: center;">
						<a href="home" class="btn btn-info btn-border">
							Return Home &raquo;
						</a>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-6 col-xs-12">
		</div>
	</div>
</div>