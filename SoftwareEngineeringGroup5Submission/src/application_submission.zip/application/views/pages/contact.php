<div class="container body-content">

	<h1>
		Contact Information&nbsp;
		<small>
			The Film Club of Georgia Southern University
		</small>
	</h1>
	<span>
		<hr />
	</span>
    <div class="row">
        <div class="col-xs-12">
            <h5 class="text-warning">
                Note: If you would like to work with us or have a suggestion, please fill out the form at
                <a href="<?php echo base_url(); ?>suggestions"> our suggestions page.</a>
            </h5>
            <br />
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 col-md-5">
            <div class="well">
                <? echo $content_body; ?>
            </div>
        </div>
    </div>
	<!--<div class="row">
		<div class="col-xs-12 col-md-4">
			<div class="well">
				<legend>Address</legend>
				<address>
					<strong>Sanford Hall</strong><br />
					P.O. Box 8091<br />
					Statesboro, GA 30460<br />
					United States
				</address>
				<br />
				<legend>Contact</legend>
				<address>
					<strong>Darrell Fullmer</strong><br />
					df02200@georgiasouthern.edu
				</address>
			</div>
			<!-- old <div style="border: 1px solid gray;" class="well">
				<h4>Address</h4>
				<div class="panel panel-default">
					<div style="border: 1px solid white;" class="panel-body bg-primary">
						<address>
							<strong>Sanford Hall</strong><br />
							P.O. Box 8091<br />
							Statesboro, GA 30460<br />
							United States
						</address>
					</div>
				</div>
				<div class="panel panel-default">
					<div style="border: 1px solid white;" class="panel-body bg-primary">
						<address>
							<strong>Darrell Fullmer</strong><br /><br />
							<span style="font-size: 14px;" class="label label-default">df02200</span>
							<i class="fa fa-at">
							</i>
							<span style="font-size: 14px;" class="label label-default">
								georgiasouthern
							</span>
							<i class="fa fa-dot-circle-o">
							</i>
							<span style="font-size: 14px;" class="label label-default">edu</span>
						</address>
					</div>
				</div>
				
				
			</div>-->

		</div>
	</div>
</div>