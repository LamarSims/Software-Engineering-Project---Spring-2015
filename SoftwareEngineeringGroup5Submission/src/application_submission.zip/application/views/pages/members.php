<div class="container body-content">
	<h1>
		Our Members
	</h1>
	<hr />
	<div class="row">
		<div class="col-xs-12 col-md-8 col-md-offset-2">
			<div style="max-height: 900px; overflow-y: scroll">
				<table class="table table-bordered table-striped">
					<tr>
						<th style="width: 1px"></th>
						<th style="width: 1px">Picture</th>
						<th>Name</th>
						<th>Type</th>
						<th>Role</th>
						<th>Date Joined</th>
					</tr>
					<!--
				<?php
					for ($i = 1; $i < 20; $i++)
					{
						echo '<tr>' .
							'<td>' . $i . '</td>' .
							'<td></td>' .
							'<td></td></tr>';
					}
					?>
				old -->
					<?
					$row_count = 1;
					foreach($film_club_members->result() as $row):
						if ($row->account_level > 6)  continue; // Don't include developers in the list.
						echo '<tr>';
						echo '<td>' . $row_count++ . '</td>';
						echo '<td>' . '<img src="http://placehold.it/75x75" />' . '</td>';
						echo '<td>' . $row->first_name . ' ' . $row->last_name . '</td>';
						//echo '<td>Film Club Member</td>';
						echo '<td>' . $account_type[$row->account_level] . '</td>';
						echo '<td>' . $role_name[$row->role_id] . '</td>';
						echo '<td>' . $row->created . '</td>';
						echo '</tr>';

					endforeach;
					?>
				</table>
			</div>

		</div>
	</div>
</div>