<div class="container body-content">
    <div class="col-xs-8 col-xs-offset-2">
        <div class="well">
            <h1><?php echo $blog_title; ?></h1>
            <p><?php echo $blog_body; ?></p>
        </div>
    </div>
</div>