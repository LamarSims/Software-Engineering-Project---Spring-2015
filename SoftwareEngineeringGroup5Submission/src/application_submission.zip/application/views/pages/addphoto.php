<div class="well">
    <form class="form-horizontal">
        <legend>Select Pictures to Upload</legend>
        <img class="img-responsive" style="height: 100px; width: 100px; display: inline;" src="http://placehold.it/100x100"/>
        <br />
        <br />
        <div class="form-group">
            <label for="userfile" class="col-lg-2 control-label">Choose a File</label>
            <div class="col-lg-10">
                <input type="file" class="form-control" name="userfile" size="20" />
            </div>
        </div>
        <div class="form-group">
            <div class="col-lg-10 col-lg-offset-2">
                <input type="submit" class="btn btn-info btn-border" name="submit" value="Upload">
            </div>
        </div>
    </form>

</div>
