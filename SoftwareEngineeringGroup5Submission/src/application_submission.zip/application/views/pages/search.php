<div class="container body-content">
    <h1 class="page-header">
        Search Results
        <small><? echo '"' . explode('Search for: ', $title)[1] . '"'; ?></small>
        <hr />
    </h1>
    <div class="row">
        <div class="col-xs-12">
            <? echo $html_result_tables; ?>
        </div>
    </div>
</div>