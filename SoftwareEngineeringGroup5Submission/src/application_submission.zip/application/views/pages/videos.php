<div class="container body-content">
    <h1>Browse Videos
        <div class="dropdown pull-right">
            <button class="btn btn-default dropdown-toggle" type="button" id="menu1" data-toggle="dropdown">Categories
                <span class="caret"></span></button>
            <? if ($this->session->userdata('account_level') >= 7): ?>
                <button onclick="location.href='<? echo base_url(); ?>dashboard/videos'" class="btn btn-primary" type="button">Add Videos</button>
            <? endif; ?>
            <ul class="dropdown-menu" role="menu">
                <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Club Videos</a></li>
                <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Tutorials</a></li>
                <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Interest Videos</a></li>
            </ul>
        </div></h1>
	<span>
		<hr />
	</span>
    <p>View the latest videos our members have submitted.</p>
    <? foreach($videos->result() as $video): ?>
        <div class="row">
            <div class="col-xs-8 col-xs-offset-2">
                <div class="well">
                    <div class="text-center">
                        <iframe
                            width="480"
                            height="320"
                            src="<? echo 'https://www.youtube.com/embed/' . $video->video_id ?>"
                            frameborder="0"
                            allowfullscreen>
                        </iframe>
                    </div>
                    <hr />
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th style="width: 25%; font-weight: bolder">Description</th>
                            <td><? echo nl2br($video->site_description); ?></td>
                        </tr>
                        <tr>
                            <th style="width: 25%; font-weight: bolder;">
                                Tags
                            </th>
                            <td>
                                <? foreach ($videos_tags[$video->video_id]->result() as $tag): ?>
                                    <span class="badge"><? echo $tag->tag_name; ?></span>
                                <? endforeach; ?>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    <? endforeach; ?>
    <div class="col-xs-6 col-md-2">
        <div class="text-center">

        </div>

    </div>
    <!-- 1. The <iframe> (and video player) will replace this <div> tag. -->
    <div class="row">
        <div class="col-xs-12 col-md-8 col-md-offset-3">
            <div style="border: 1px solid gray" id="player"></div>
        </div>
    </div>

    <script>
        // 2. This code loads the IFrame Player API code asynchronously.
        var tag = document.createElement('script');

        tag.src = "https://www.youtube.com/iframe_api";
        var firstScriptTag = document.getElementsByTagName('script')[0];
        firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

        // 3. This function creates an <iframe> (and YouTube player)
        //    after the API code downloads.
        var player;
        function onYouTubeIframeAPIReady() {
            player = new YT.Player('player', {
                height: '390',
                width: '640',
                videoId: 'M7lc1UVf-VE',
                events: {
                    'onReady': onPlayerReady,
                    'onStateChange': onPlayerStateChange
                }
            });
        }

        // 4. The API will call this function when the video player is ready.
        function onPlayerReady(event) {
            event.target.playVideo();
        }

        // 5. The API calls this function when the player's state changes.
        //    The function indicates that when playing a video (state=1),
        //    the player should play for six seconds and then stop.
        var done = false;
        function onPlayerStateChange(event) {
            if (event.data == YT.PlayerState.PLAYING && !done) {
                setTimeout(stopVideo, 6000);
                done = true;
            }
        }
        function stopVideo() {
            player.stopVideo();
        }
    </script>
</div>