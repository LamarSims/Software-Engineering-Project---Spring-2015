<?php
/**
 * Must ensure user has appropriate privileges.
 */
if ( ! $this->data['session']['account_level'] >= 3)
{
  show_error('403: You are not authorized to view this page.');
}
?>

<style>
  /*
 * Base structure
 */

  /* Move down content because we have a fixed navbar that is 50px tall */
  body {
    /*padding-top: 50px;*/
  }


  /*
   * Global add-ons
   */

  .sub-header {
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
  }

  /*
   * Top navigation
   * Hide default border to remove 1px line.
   */
  .navbar-fixed-top {
    border: 0;
  }

  /*
   * Sidebar
   */

  /* Hide for mobile, show later */
  .sidebar {
    display: none;
  }
  @media (min-width: 768px) {
    .sidebar {
      position: fixed;
      top: 51px;
      bottom: 0;
      left: 0;
      z-index: 1000;
      display: block;
      padding: 20px;
      overflow-x: hidden;
      overflow-y: auto; /* Scrollable contents if viewport is shorter than content. */
      background-color: #f5f5f5;
      background-color: #000000;
      /*border-right: 1px solid #eee;*/
    }
  }

  /* Sidebar navigation */
  .nav-sidebar {
    margin-right: -21px; /* 20px padding + 1px border */
    margin-bottom: 20px;
    margin-left: -20px;
  }
  .nav-sidebar > li > a {
    padding-right: 20px;
    padding-left: 20px;
  }
  .nav-sidebar > .active > a,
  .nav-sidebar > .active > a:hover,
  .nav-sidebar > .active > a:focus {
    color: #fff;
    background-color: #428bca;
  }


  /*
   * Main content
   */

  .main {
    padding: 20px;
  }
  @media (min-width: 768px) {
    .main {
      padding-right: 40px;
      padding-left: 40px;
    }
  }
  .main .page-header {
    margin-top: 0;
  }


  /*
   * Placeholder dashboard ideas
   */

  .placeholders {
    margin-bottom: 30px;
    text-align: center;
  }
  .placeholders h4 {
    margin-bottom: 0;
  }
  .placeholder {
    margin-bottom: 20px;
  }
  .placeholder img {
    display: inline-block;
    border-radius: 50%;
  }
</style>

<div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li class="active"><a href="#">Overview <span class="sr-only">(current)</span></a></li>
            <li><a href="dashboard/reports">Reports</a></li>
            <li><a href="dashboard/videos">Videos</a></li>
            <li><a href="dashboard/images">Images</a></li>
          </ul>
          <ul class="nav nav-sidebar">
            <li><a href="">Manage Users</a></li>
            <li><a href="">Custom Pages</a></li>
            <li><a href="">Settings</a></li>
          </ul>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h1 class="page-header">Dashboard</h1>

          <div class="row placeholders">
            <div class="col-xs-6 col-sm-3 placeholder">
              <img src="http://placehold.it/200x200" class="img-responsive" alt="Generic placeholder thumbnail">
              <h4>Reports</h4>
              <span class="text-muted">Something else</span>
            </div>
            <div class="col-xs-6 col-sm-3 placeholder">
              <img src="http://placehold.it/200x200" class="img-responsive" alt="Generic placeholder thumbnail">
              <h4>Videos</h4>
              <span class="text-muted">Something else</span>
            </div>
            <div class="col-xs-6 col-sm-3 placeholder">
              <img src="http://placehold.it/200x200" class="img-responsive" alt="Generic placeholder thumbnail">
              <h4><a href="dashboard/images">Images</a></h4>
              <span class="text-muted">Something else</span>
            </div>
            <div class="col-xs-6 col-sm-3 placeholder">
              <img src="http://placehold.it/200x200" class="img-responsive" alt="Generic placeholder thumbnail">
              <h4>Manage Users</h4>
              <span class="text-muted">Something else</span>
            </div>
              <div class="col-xs-6 col-sm-3 placeholder">
                  <img src="http://placehold.it/200x200" class="img-responsive" alt="Generic placeholder thumbnail">
                  <h4>Manage Tags</h4>
                  <span class="text-muted">Something else</span>
              </div>
          </div>

          <h2 class="sub-header">Section title</h2>
          <div class="table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Header</th>
                  <th>Header</th>
                  <th>Header</th>
                  <th>Header</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>1,001</td>
                  <td>Lorem</td>
                  <td>ipsum</td>
                  <td>dolor</td>
                  <td>sit</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
</div>