<div class="container body-content">
	<h1>
		About Us&nbsp;
		<small>
			The Film Club of Georgia Southern University
		</small>
	</h1>
	<span>
		<hr />
	</span>
    <!-- old
	<h4 class="text-center">Our Mission</h4>
	<div class="row">
		<div class="col-xs-12 col-md-8 col-md-offset-2">
			<div class="well">
				<p>
					The purpose and goals of Film Club GSU are for all of its members to learn quick and professional film production while, at the same time, collaborating with peers in other campus departments/colleges to produce quality entertaining content. Acting as the Southern Georgia chapter of Media Communications Association � International, the club will consider its MCA-I affiliation as part of a greater resource for students to network with professionals for building possible internships and careers. We endeavor to distribute quality content on Youtube as well as on our local campus television station and will compete in local/regional/international festivals/contests. However, our primary purpose will always focus on getting discovered by building on our talents and skills, whether it be in writing, acting, production, and/or post-production.
				</p>
			</div>
		</div>
	</div>-->
    <div class="row">
        <div class="col-xs-10 col-xs-offset-1">
            <div class="well">
                <? echo $content_body; ?>
            </div>
        </div>
    </div>
</div>