<div class="container body-content">
	<div class="">
		<h1>
			Registration
		</h1>
		<span>
			<hr />
		</span>
		<?php if (validation_errors() != '') { ?>
		<div class="alert alert-danger">
			<?php echo validation_errors() ?>
		</div>
		<?php ; }?>
        <?php if ($success = $this->session->flashdata('success')) { ?>
            <div class="alert alert-success">
                <?php echo $success; ?>
            </div>
        <?php  } ?>
		<div class="row">
			<div class="col-xs-12 col-md-8 col-md-offset-2">
				<div class="well">
						<?php //echo form_open('verify_login', array('class' => "form-horizontal")); ?>
						<form class="form-horizontal" method="post" action="<?php echo base_url(); ?>register_user">
  							<fieldset>
	    						<legend>Registration Form</legend>
							    <div class="form-group">
							      	<label for="username" class="col-lg-3 control-label">Username</label>
							      	<div class="col-lg-9">
							        	<input type="text" class="form-control" name="username" id="username" placeholder="Username" autocomplete="off" value="<?php echo set_value('username'); ?>">
							      	</div>
							    </div>
							    <div class="form-group">
							      	<label for="email" class="col-lg-3 control-label">Email</label>
							      	<div class="col-lg-9">
							        	<input type="text" class="form-control" name="email" id="email" placeholder="Email" autocomplete="off" value="<?php echo set_value('email'); ?>">
							      	</div>
							    </div>
                                <div class="form-group">
                                    <label for="first_name" class="col-lg-3 control-label">First Name</label>
                                    <div class="col-lg-9">
                                        <input type="text" class="form-control" name="first_name" id="first_name" placeholder="First Name" autocomplete="off" value="<?php echo set_value('first_name'); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="last_name" class="col-lg-3 control-label">Last Name</label>
                                    <div class="col-lg-9">
                                        <input type="text" class="form-control" name="last_name" id="last_name" placeholder="Last Name" autocomplete="off" value="<?php echo set_value('last_name'); ?>">
                                    </div>
                                </div>
							    <div class="form-group">
							      	<label for="password" class="col-lg-3 control-label">Password</label>
							      	<div class="col-lg-9">
							        	<input type="password" class="form-control" name="password" id="password" placeholder="Password" autocomplete="off" >
							      	</div>
							    </div>
							    <div class="form-group">
							      	<label for="password_conf" class="col-lg-3 control-label">Confirm</label>
							      	<div class="col-lg-9">
							        	<input type="password" class="form-control" name="password_conf" id="password_conf" placeholder="Password" autocomplete="off">
							      	</div>
							    </div>
							    <div class="form-group">
							      	<div class="col-lg-10 col-lg-offset-3">
							        	<input type="submit" class="btn btn-primary btn-border" value="Register">
							      	</div>
							    </div>
  							</fieldset>
						</form>
				</div>
			</div>
		</div>
	</div>
</div>