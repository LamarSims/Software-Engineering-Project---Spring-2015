<div class="container body-content">
	<div class="">
		<h1>
			Login
		</h1>
		<span>
			<hr />
		</span>
		<?php if ($errors = $this->session->flashdata('validation_errors')) { ?>
		<div class="alert alert-danger">
			<?php echo $errors; ?>
		</div>
		<?php  } ?>

		<div class="row">
			<div class="col-xs-12 col-md-6">
				<div class="well">
						<?php //echo form_open('verify_login', array('class' => "form-horizontal")); ?>
						<form class="form-horizontal" method="post" action="<?php echo base_url(); ?>verify_login">
  							<fieldset>
	    						<legend>Login Form</legend>
							    <div class="form-group">
							      	<label for="email" class="col-lg-2 control-label">Email</label>
							      	<div class="col-lg-10">
							        	<input type="text" class="form-control" name="email" id="email" placeholder="Email" autocomplete="off">
							      	</div>
							    </div>
							    <div class="form-group">
							      	<label for="password" class="col-lg-2 control-label">Password</label>
							      	<div class="col-lg-10">
							        	<input type="password" class="form-control" name="password" id="password" placeholder="Password" autocomplete="off" >
							        	<div class="checkbox">
							          		<label>
							            		<input type="checkbox"> Remember Me
							          		</label>
							        	</div>
							      	</div>
							    </div>
							    <div class="form-group">
							      	<div class="col-lg-10 col-lg-offset-2">
							        	<input type="submit" class="btn btn-primary btn-border" value="Login">
							      	</div>
							    </div>
  							</fieldset>
						</form>
				</div>
			</div>
		</div>
	</div>
</div>

