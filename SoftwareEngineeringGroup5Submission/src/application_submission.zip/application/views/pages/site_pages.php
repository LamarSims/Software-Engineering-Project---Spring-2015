<div class="container body-content">
    <h1 class="page-header">
        Site Page Map
        <small>View this site's pages.</small>
    </h1>
    <!--<table class="table table-bordered table-striped table-responsive table-hover">
        <tr>
            <th>
                URL
            </th>
            <th>
                Title
            </th>
            <th>
                Description
            </th>
        </tr>
        <tr>
            <td>
                http://blah.blah
            </td>
            <td>
                Blah
            </td>
            <td>
                Blah blah blah.
            </td>
        </tr>
    </table>-->
    <div class="table-responsive">
        <table class="table table-striped table-hover table-bordered">
            <thead>
            <tr>
                <th>URL</th>
                <th>Title</th>
                <th>Author</th>
                <th>Last Modified</th>
                <th># of Comments</th>
            </tr>
            </thead>
            <tbody>
            <? foreach ($custom_pages_table->result() as $row): // Loop through (ordered) suggestions records. ?>
                <tr>
                    <td>
                        <a href="<? echo base_url() . 'custom/' . $row->page_id ?>">
                            <? echo base_url() . 'custom/' . $row->page_id ?>
                        </a>
                    </td>
                    <td><? echo $row->title ?></td>
                    <td><? echo $row->username ?></td>
                    <td><? echo $row->created ?></td>
                    <td><? echo $row->comments ?></td>
                </tr>
            <? endforeach; // Done looping through suggestions records. ?>
            </tbody>
        </table>
    </div>
</div>