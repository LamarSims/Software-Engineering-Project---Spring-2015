<style>
	.well:hover {
		/*background-color: black;*/
		border: 1px solid darkgray;
	}
</style>
	<div id="carousel-example-generic" style="margin-top: -21px;" class="carousel slide" data-ride="carousel" data-interval="4000">
	  <!-- Indicators -->
	  <ol class="carousel-indicators">
	    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
	    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
	    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
	  </ol>
	 
	  <!-- Wrapper for slides -->
	  <!-- Strongly recommended the images used have dimensions 1920x350px -->
	  <div class="carousel-inner">
	    <div class="item active">
	      <img src="<?php echo base_url(); ?>images/film_club_banner.png" alt="..." style="opacity: 1.0;">
	      <div class="carousel-caption">
	      	<div class="hidden-md hidden-lg">
		        	<p>Welcome</p>
	      	</div>
	      	<div class="hidden-xs hidden-sm">

	      	</div>
	      </div>
	    </div>
	    <div class="item">
	      <img src="<?php echo base_url(); ?>images/press_conference1.jpg" alt="...">
	      <div class="carousel-caption">
	      	<div class="hidden-md hidden-lg">
	      		
		    		<a class="btn btn-primary btn-xs btn-border" href="<?php echo base_url(); ?>login">
		          		Do something &raquo;
		        	</a>
	        	
	      	</div>
	      	<div class="hidden-xs hidden-sm">
	      		<h1>
	      			Placeholder
	      		</h1>
	      		<p>
		    		<a class="btn btn-primary btn-border" href="<?php echo base_url(); ?>login">
		          		Do something &raquo;
		        	</a>
	        	</p>
	      	</div>
	      </div>
	    </div>
	    <div class="item">
	      <img src="<?php echo base_url(); ?>images/city1.jpg" alt="...">
	      <div class="carousel-caption">
	      	<div class="hidden-md hidden-lg">
	      		
		    		<a class="btn btn-primary btn-xs btn-border" href="<?php echo base_url(); ?>login">
		          		Button &raquo;
		        	</a>
	        	
	      	</div>
	      	<div class="hidden-xs hidden-sm">
	      		<h1>
	      			Something will go here.
	      		</h1>
	      		<p>
		    		<a class="btn btn-primary btn-border" href="<?php echo base_url(); ?>login">
		          		Button! &raquo;
		        	</a>
	        	</p>
	      	</div>
	      </div>
	    </div>
	  </div>
	 
	  <!-- Controls -->
	  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
	    <span class="glyphicon glyphicon-chevron-left"></span>
	  </a>
	  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
	    <span class="glyphicon glyphicon-chevron-right"></span>
	  </a>
	</div> <!-- Carousel -->
<div class="container body-content">
	<div class="row" style="margin-top: 20px">
		<div class="col-xs-12 col-md-8">
			<h1>
				Latest
				<span class="glyphicon glyphicon-film pull-right"></span>
			</h1>
			<hr />
					<?php foreach ($custom_page_query->result() as $row): ?>
						<div class="well">
							<h3 class="news-headline">
								<a href="<?php echo base_url() . 'custom/' . $row->page_id; ?>">
									<?php echo $row->title; ?>
								</a>
							</h3>
							<p class="text-muted">
								<small>
									<em>
										&nbsp;
										<small class="glyphicon glyphicon-paperclip"></small>
										<?php //echo ' posted ' . date('F j, Y, g:i a') . ' by '; ?>
                                        <?php echo ' posted ' . $timestamp = date('F j, Y, g:i a', strtotime($row->created)) . ' by ' ?>
										<a href="#">
											<?php echo $row->username; ?>
										</a>
									</em>
								</small>
							</p>
							<br />
							<div class="row">
								<div class="col-xs-6 col-md-9">
									<p class="visible-xs visible-sm">
										<?php echo substr(strip_tags($row->body), 0, 125) . '... '; ?>
										<a href="<?php echo base_url() . 'custom/' . $row->page_id; ?>">Read more &raquo;</a>
									</p>
									<p class="visible-md visible-lg">
										<?php echo substr(strip_tags($row->body), 0, 500) . '... '; ?>
										<a href="<?php echo base_url() . 'custom/' . $row->page_id; ?>">Read more &raquo;</a>
									</p>

								</div>
							</div>
							<hr />
							<div class="row visible-xs">
								<div class="col-xs-5">
									<button class="btn btn-sm btn-default">
										Read more &raquo;
									</button>
								</div>
								<div class="col-xs-7">
									<div class="text-right">
										<button class="btn btn-sm btn-success btn-border">
											<span style="font-size: 16px; color: black; border: 1px solid black;" class="badge"><?php echo rand(1,100); ?></span>
											&nbsp;
											<span style="font-size: 16px;" class="glyphicon glyphicon-thumbs-up"></span>
										</button>
										<button class="btn btn-sm btn-danger btn-border">
											<span style="font-size: 16px;" class="glyphicon glyphicon-thumbs-down"></span>
											&nbsp;
											<span style="font-size: 16px; color: black; border: 1px solid black;"class="badge"><?php echo rand(1,5); ?></span>
										</button>
									</div>
								</div>
							</div>
							<div class="row visible-md visible-lg visible-sm">
								<div class="col-xs-6">
									<div class="text-muted">
										<p>
											<small>
												<i class="fa fa-comment">&nbsp;</i>
												<?php echo $row->comments . ' comments'; ?></small>
										</p>
									</div>
								</div>
								<div class="col-xs-6">
									<div class="text-right">
										<button class="btn btn-sm btn-success btn-border">
											<span style="font-size: 16px; color: black; border: 1px solid black;" class="badge"><?php echo rand(1,100); ?></span>
											&nbsp;
											<span style="font-size: 16px;" class="glyphicon glyphicon-thumbs-up"></span>
										</button>
										<button class="btn btn-sm btn-danger btn-border">
											<span style="font-size: 16px;" class="glyphicon glyphicon-thumbs-down"></span>
											&nbsp;
											<span style="font-size: 16px; color: black; border: 1px solid black;"class="badge"><?php echo rand(1,5); ?></span>
										</button>
									</div>
								</div>
							</div>
						</div>
					<?php endforeach; ?>
<!--			<h1>Blog</h1>-->
<!--			<hr />-->
<!--				--><?php //foreach ($blog_query as $row): ?>
<!--				<div class="well">-->
<!--					<h3 class="news-headline">-->
<!--						<a href="--><?php //echo base_url() . 'blogs/view/' . $row->blog_id; ?><!--">-->
<!--							--><?php //echo $row->title; ?>
<!--						</a>-->
<!--					</h3>-->
<!--					<p class="text-muted">-->
<!--						<small>-->
<!--						<em>-->
<!--							&nbsp;-->
<!--							<small class="glyphicon glyphicon-paperclip"></small>-->
<!--							--><?php //echo ' posted ' . date('F j, Y, g:i a') . ' by '; ?>
<!--							<a href="#">-->
<!--								--><?php //echo ' author'; ?>
<!--							</a>-->
<!--						</em>-->
<!--						</small>-->
<!--					</p>-->
<!--					<br />-->
<!--					<div class="row">-->
<!--						<div class="col-xs-6 col-md-3">-->
<!--							<img style="height: 150px; width: 150px; align: left; margin-right: 5px; margin-bottom: 5px;" src="http://placehold.it/150x150" />-->
<!--						</div>-->
<!--						<div class="col-xs-6 col-md-9">-->
<!--							<p class="visible-xs visible-sm">-->
<!--								--><?php //echo substr($row->body, 0, 125) . '... '; ?>
<!--								<a href="--><?php //echo base_url() . 'blogs/view/' . $row->blog_id; ?><!--">Read more &raquo;</a>-->
<!--							</p>-->
<!--							<p class="visible-md visible-lg">-->
<!--								--><?php //echo substr($row->body, 0, 500) . '... '; ?>
<!--								<a href="--><?php //echo base_url() . 'blogs/view/' . $row->blog_id; ?><!--">Read more &raquo;</a>-->
<!--							</p>-->
<!--							-->
<!--						</div>-->
<!--					</div>-->
<!--					<hr />-->
<!--					<div class="row visible-xs">-->
<!--						<div class="col-xs-5">-->
<!--							<button class="btn btn-sm btn-default">-->
<!--								Read more &raquo;-->
<!--							</button>	-->
<!--						</div>-->
<!--						<div class="col-xs-7">-->
<!--							<div class="text-right">-->
<!--								<button class="btn btn-sm btn-success btn-border">-->
<!--									<span style="font-size: 16px; color: black; border: 1px solid black;" class="badge">--><?php //echo rand(1,100); ?><!--</span>-->
<!--									&nbsp;-->
<!--									<span style="font-size: 16px;" class="glyphicon glyphicon-thumbs-up"></span>-->
<!--								</button>-->
<!--								<button class="btn btn-sm btn-danger btn-border">-->
<!--									<span style="font-size: 16px;" class="glyphicon glyphicon-thumbs-down"></span>-->
<!--									&nbsp;-->
<!--									<span style="font-size: 16px; color: black; border: 1px solid black;"class="badge">--><?php //echo rand(1,5); ?><!--</span>-->
<!--								</button>-->
<!--							</div>-->
<!--						</div>		-->
<!--					</div>-->
<!--					<div class="row visible-md visible-lg visible-sm">-->
<!--						<div class="col-xs-6">-->
<!--							<div class="text-muted">-->
<!--								<p>-->
<!--									<small>-->
<!--										<i class="fa fa-comment">&nbsp;</i>-->
<!--										--><?php //echo rand(0,100) . ' comments'; ?><!--</small>-->
<!--								</p>-->
<!--							</div>	-->
<!--						</div>-->
<!--						<div class="col-xs-6">-->
<!--							<div class="text-right">-->
<!--								<button class="btn btn-sm btn-success btn-border">-->
<!--									<span style="font-size: 16px; color: black; border: 1px solid black;" class="badge">--><?php //echo rand(1,100); ?><!--</span>-->
<!--									&nbsp;-->
<!--									<span style="font-size: 16px;" class="glyphicon glyphicon-thumbs-up"></span>-->
<!--								</button>-->
<!--								<button class="btn btn-sm btn-danger btn-border">-->
<!--									<span style="font-size: 16px;" class="glyphicon glyphicon-thumbs-down"></span>-->
<!--									&nbsp;-->
<!--									<span style="font-size: 16px; color: black; border: 1px solid black;"class="badge">--><?php //echo rand(1,5); ?><!--</span>-->
<!--								</button>-->
<!--							</div>-->
<!--						</div>		-->
<!--					</div>-->
<!--			</div>-->
<!--				--><?php //endforeach; ?>
			<div class="col-xs-12">
			<div class="text-center">
				<nav>
  					<ul class="pagination">
    					<li>
      						<a href="<?php base_url() . 'home/'; ?>1" aria-label="First">
        						<span  aria-hidden="true">&laquo;</span>
      						</a>
   						</li>
   						<? for ($i = 1; $i <= intval($num_rows/3 + 1); $i++): ?>
   						<li <? if ($i == $current_blogs_page):  ?> class="active" <? endif; ?>>
   							<a href="<?php echo base_url() . 'home/' . $i; ?>">
   								<?php echo $i; ?>
   							</a>
   						</li>
   						<? endfor; ?>
    					<li>
      						<a href="<?php echo base_url() . 'home/' . intval($num_rows/3 + 1); ?>" aria-label="Next">
        						<span aria-hidden="true">&raquo;</span>
      						</a>
    					</li>
  					</ul>
				</nav>
			</div>
		</div>
		</div>
		<div class="col-xs-12 col-md-4">
				<h1>
					Twitter
					<i class="fa fa-twitter text-info pull-right"></i>
				</h1>
				<hr />
					<a class="twitter-timeline" href="https://twitter.com/FilmClubGSU" data-widget-id="558332090157400064">Tweets by @FilmClubGSU</a>
					<script>
						!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");
					</script>
<!--			<h1>-->
<!--				<i class="fa fa-twitter text-info"></i>-->
<!--				Twitter-->
<!--			</h1>-->
<!--			<hr />-->
<!--			<div class="well">-->
<!--				<a class="twitter-timeline" href="https://twitter.com/FilmClubGSU" data-widget-id="558332090157400064">Tweets by @FilmClubGSU</a>-->
<!--				<script>-->
<!--				!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");-->
<!--				</script>-->
<!--			</div>-->
<!--			<div>-->
<!--			</div>-->
		</div>
	</div>
</div>