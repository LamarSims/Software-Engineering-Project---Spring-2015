<div class="container body-content">
	<h1 class=page-header">
		Developer Test Page
		<small>
			For the purpose of testing script outputs, design elements, etc.
		</small>
	</h1>
	<hr />
	<div class="row">
		<div class="col-xs-12">
			<h3>
				Password hash/salt testing...
			</h3>
			<p>
				MD5 hash of <em>password</em>: <?php echo md5('password'); ?>
			</p>
			<p>
				SHA-1 hash of <em>password</em>: <?php echo sha1('password'); ?>
			</p>

			<p>
				bcrypt hash of <em>password</em>: 
				<?php
				$this->load->library('benchmark');
				$this->benchmark->mark('my_mark_start');
				echo $bcrypt = password_hash('password', PASSWORD_BCRYPT, array('cost' => 8));
				$this->benchmark->mark('my_mark_end');
				?>
			</p>
			<p>
				bcrypt hash completed in: <?php echo $this->benchmark->elapsed_time() . ' seconds.'; ?>
			</p>
			<p>
				bcrypt match hash using: <code>password_verify('password', $bcrypt)</code>: <?php echo password_verify('password', '$2y$11$NKyehKTvpRQTfoCl.vUTxub1cnDrd2Eq.5CvaljnK7WXapbmh4PmC'); ?>
			</p>
			
		</div>
	</div>
	<div class="row">
		<div class="col-xs-12">
			<h3>Database Testing...</h3>
			<p>
			</p>
		</div>
	</div>
	
	<hr />
	
	<?php if (isset($session['account_level']) == TRUE) { echo $session['account_level'] . " " . $session['email']; } else { echo 'Not Logged In!'; } ?>
	
	<hr />

	<h3>This is a test <?php echo '.' ?></h3>
	<h2>This is a bigger test.</h2>
	<h1>Noop?</h1>
	<h1>XYZ</h1>
	<h2>ABCDEF</h2>
	<h2>Stop Making Excuses</h2>

	<hr />

	/* draw table */
	$calendar = '<table cellpadding="0" cellspacing="0" class="calendar">';

		/* table headings */
		$headings = array('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
		$calendar.= '<tr class="calendar-row"><td class="calendar-day-head">'.implode('</td><td class="calendar-day-head">',$headings).'</td></tr>';

		/* days and weeks vars now ... */
		$running_day = date('w',mktime(0,0,0,$month,1,$year));
		$days_in_month = date('t',mktime(0,0,0,$month,1,$year));
		$days_in_this_week = 1;
		$day_counter = 0;
		$dates_array = array();

		/* row for week one */
		$calendar.= '<tr class="calendar-row">';

			/* print "blank" days until the first of the current week */
			for($x = 0; $x < $running_day; $x++):
			$calendar.= '<td class="calendar-day-np"> </td>';
			$days_in_this_week++;
			endfor;

			/* keep going with days.... */
			for($list_day = 1; $list_day <= $days_in_month; $list_day++):
			$calendar.= '<td class="calendar-day">';
				/* add in the day number */
				$calendar.= '<div class="day-number">'.$list_day.'</div>';

				/** QUERY THE DATABASE FOR AN ENTRY FOR THIS DAY !!  IF MATCHES FOUND, PRINT THEM !! **/
				$calendar.= str_repeat('<p> </p>',2);

				$calendar.= '</td>';
			if($running_day == 6):
			$calendar.= '</tr>';
		if(($day_counter+1) != $days_in_month):
		$calendar.= '<tr class="calendar-row">';
			endif;
			$running_day = -1;
			$days_in_this_week = 0;
			endif;
			$days_in_this_week++; $running_day++; $day_counter++;
			endfor;

			/* finish the rest of the days in the week */
			if($days_in_this_week < 8):
			for($x = 1; $x <= (8 - $days_in_this_week); $x++):
			$calendar.= '<td class="calendar-day-np"> </td>';
			endfor;
			endif;

			/* final row */
			$calendar.= '</tr>';

		/* end the table */
		$calendar.= '</table>';

	/* all done, return result */
	return $calendar;
	}


	<hr />

<img src="<? echo base_url() ?>submitted_images/logo11w.png" alt="..." />

</div>