<div class="container body-content">
<?php
echo $session['username']; 
echo $session['password']?>
</div>