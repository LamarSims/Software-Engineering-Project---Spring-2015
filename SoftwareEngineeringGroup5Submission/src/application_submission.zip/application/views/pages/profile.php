<div class="container body-content">
    <h1 class="page-header">
            <? echo (isset($profile->row()->image_id))
                ? '<img class="img-responsive" style="width:100px; height:100px; display:inline" src="' . base_url() . $profile->row()->path . $profile->row()->image_id . $profile->row()->filetype . '"" />'
                : '<img class="img-responsive" src="http://placehold.it/100x100" />'; ?>
        <? echo "&nbsp;&nbsp;" . $user_data->first_name . "'s"?> Profile
    </h1>
    <hr />
    <div class="row">
        <div class="col-xs-10 col-xs-offset-1">
            <h3>User Profile Information</h3>
            <table class="table table-bordered table-striped">
                <tr>
                    <th style="width: 20%">User ID Number</th>
                    <td><? echo $user_data->user_id ?></td>
                </tr>
                <tr>
                    <th style="width: 20%">Username</th>
                    <td><? echo $user_data->username ?></td>
                </tr>
                <tr>
                    <th style="width: 20%">Email Address</th>
                    <td><? echo $user_data->email ?></td>
                </tr>
                <tr>
                    <th style="width: 20%">First Name</th>
                    <td><? echo $user_data->first_name ?></td>
                </tr>
                <tr>
                    <th style="width: 20%">Last Name</th>
                    <td><? echo $user_data->last_name ?></td>
                </tr>
                <tr>
                    <th style="width: 20%">Registered On</th>
                    <td><? echo $user_data->created ?></td>
                </tr>
            </table>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-10 col-xs-offset-1">
            <div class="well">
                <?php echo form_open_multipart('user/do_upload', array('class' => 'form-horizontal'));?>
                <form class="form-horizontal" metod="post" action="<? echo base_url() ?>user/do_upload" enctype="multipart/form-data">
                    <legend>Manage Profile Picture</legend>
                    <h5>Current Picture: </h5>
                        <? echo (isset($profile->row()->image_id))
                            ? '<img class="img-responsive" style="width:100px; height:100px; display:inline" src="' . base_url() . $profile->row()->path . $profile->row()->image_id . $profile->row()->filetype . '"" />'
                            : '<img class="img-responsive" src="http://placehold.it/100x100" />'; ?>
                    <br />
                    <br />
                    <legend>Add or Edit Profile Picture</legend>
                    <div class="form-group">
                        <label for="userfile" class="col-lg-2 control-label">Choose a File</label>
                        <div class="col-lg-10">
                            <input type="file" class="form-control" name="userfile" size="20" />
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-lg-10 col-lg-offset-2">
                            <input type="submit" class="btn btn-info btn-border" name="submit" value="Upload">
                        </div>
                    </div>
                    <legend>Delete Profile Picture</legend>
                    <a href="<? echo base_url() ?>user/delete_image" class="btn btn-danger">
                        Delete
                    </a>
                </form>

            </div>
        </div>
    </div>
</div>