<div class="container body-content">
	<h1>Browse Our Gallery</h1>
    <button onclick="location.href = 'http://chadgolden.com/se/test/upload/file';" type="button" class="btn btn-primary">Add Photos</button>
	<span>
		<hr />
	</span>
		<div class="row">
			<?php
	    $row_num = 0;
            foreach($pictures->result() as $row) {
            	if ($row_num % 3 == 0) echo '<div class="col-xs-6 col-md-4">';
                echo '<a data-toggle="modal" data-target="#modal_image_' . $row->image_id . '" class="thumbnail">' .
                    '<img src=' . $row->path . $row->image_id . $row->filetype . ' alt="...">' .
                    '</a>';
                if ($row_num++ % 3 == 2) echo '</div>';
            }
			/*for ($i = 0; $i < 40; $i++) {


                echo    '<div class="col-xs-6 col-md-3">' .
						'<a href="#" class="thumbnail">' .
						'<img src="http://placehold.it/200x200" alt="...">' .
						'</a></div>';
			}*/
			?>

	</div>
	
</div>
<? foreach ($pictures->result() as $row): ?>
<div class="modal fade" id="modal_image_<? echo $row->image_id?>" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="modal_title">View Image</h4>
            </div>
            <div class="modal-body">
                <img class="img-responsive" src="<? echo base_url() . $row->path . $row->image_id . $row->filetype; ?>" />

            </div>
        </div>
    </div>
</div>
<? endforeach; ?>