<div class="container body-content">
    <h1>
        Events
        <small>
            Create an event on the calendar!
        </small>
    </h1>
    <hr />
    <div class="row">
        <div class="col-xs-12 col-md-8 col-md-offset-2">
            <?php if ($errors = $this->session->flashdata('validation_errors')) { ?>
                <div class="alert alert-danger">
                    <?php echo $errors; ?>
                </div>
            <?php  } ?>
            <?php if ($success = $this->session->flashdata('success')) { ?>
                <div class="alert alert-success">
                    <?php echo $success; ?>
                </div>
            <?php  } ?>
            <form class="form-horizontal" method="post" action="<?php echo base_url(); ?>submit_event">
                <fieldset>
                    <legend>Event Information</legend>
                    <div class="form-group">
                        <label for="event_name" class="col-lg-2 control-label">Event name</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" name="event_name" id="event_name" placeholder="Event Name" autocomplete="off">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="date" class="col-lg-2 control-label">Date</label>
                        <div class="col-lg-10">
                            <input type="date"
                                   class="form-control"
                                   name="date"
                                   id="date"
                                   placeholder="Date of the event. (mm/dd/yyyy) Format is required."
                                   autocomplete="off">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="time" class="col-lg-2 control-label">Time</label>
                        <div class="col-lg-10">
                            <input type="time"
                                   class="form-control"
                                   name="time"
                                   id="time"
                                   placeholder="The starting time of the event. (--:-- --) hh:mm AM/PM Format is required."
                                   autocomplete="off">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="location" class="col-lg-2 control-label">Location</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" name="location" id="location"
                                   placeholder="The location the event is being held." autocomplete="off">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="event_description" class="col-lg-2 control-label">Event Description</label>
                        <div class="col-lg-10">
                            <textarea rows="15" class="form-control" name="event_description" id="event_description"
                                      placeholder="Detailed description of the event." autocomplete="off"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-lg-10 col-lg-offset-2">
                            <input type="submit" class="btn btn-primary btn-border" value="Submit">
                        </div>
                    </div>
                </fieldset>
            </form>
        </div>
    </div>
</div>