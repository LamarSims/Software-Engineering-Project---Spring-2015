<?php
$current_month = $calendar_data['current_month'];
$year = $calendar_data['current_year'];
$first_month = 1;
$last_month = 12;

$temp_year = $year;

if ($current_month == 1)
{
    $previous_month = $last_month;
}
else
{
    $previous_month = $current_month - 1;
}

if ($current_month == 12)
{
    $next_month = $first_month;
}
else
{
    $next_month = $current_month + 1;
}
?>
<div class="container body-content">
    <? $this->view('templates/error_success_bar'); ?>
    <h1 class="text-center">
        <strong>
<!--            <a href="--><?php //echo base_url() . 'events/' . $previous_month . '/' . (($current_month == 1) ? $year - 1 : $year); ?><!--">&laquo;</a>-->
            &nbsp;
            <?php
            $make_month = mktime(0, 0, 0, $current_month + 1, 0, 0);
            echo date('F', $make_month);
            ?>
            &nbsp;
<!--            <a href="--><?php //echo base_url() . 'events/' . $next_month . '/' . (($current_month == 12) ? $year + 1 : $year); ?><!--">&raquo;</a>-->
        </strong>
    </h1>

    <h5 class="text-center">
        <?php echo $calendar_data['current_year']; ?>
    </h5>

    <div class="text-center">
        <div class="btn-group" style="">
            <a href="<?php echo base_url() . 'events/' . $previous_month . '/' . (($current_month == 1) ? $year - 1 : $year); ?>"
               class="btn btn-default btn-sm">
                &laquo; Prev
            </a>
            <a href="<?php echo base_url() . 'events/' . $next_month . '/' . (($current_month == 12) ? $year + 1 : $year); ?>"
               class="btn btn-default btn-sm">
                Next &raquo;
            </a>
        </div>
    </div>

    <? if ($this->session->userdata('account_level') > 0): ?>
    <div class="text-right">
        <a class="btn btn-info" href="<?php echo base_url() ?>event_submission"> Add Event
        </a>
    </div>
    <? endif ?>

    <p></p>
    <table class="table table-striped table-bordered table-responsive">
            <tr>
            <?php for ($j = 1; $j <= 7; $j++) { if (1 == 1) { ?>

                    <th class="text-center">
                        <strong>
                            <?php echo $calendar_data['day_heading'][$j - 1];  ?>
                        </strong>
                    </th>
<!--            <th class="text-center" style="background-color: white;">-->
<!--                --><?php //if ($calendar_data['day_heading'][$j - 1] == $get_current_day) { ?>
<!--                    <em class="text-info">-->
<!--                        --><?php //echo $calendar_data['day_heading'][$j - 1]; ?>
<!--                    </em>-->
<!--                    --><?php //} else { ?>
<!--                <strong>-->
<!--                    --><?php //echo $calendar_data['day_heading'][$j - 1]; } ?>
<!--                </strong>-->
<!--            </th>-->
            <?php } else { ?>

            <?php } } ?>

        <?php


        $count = 1;
        $flag = false;
        $events = $all_events->result();
        for ($num_rows = 0; $num_rows < 6; $num_rows++) { ?>
            </tr>
            <?php
            for ($num_columns = 0; $num_columns < 7; $num_columns++) {
                if ($count == $calendar_data['days_in_current_month']+1){
                    $flag = true;
                    break;
                }

                if ((6 * $num_rows + $num_columns) < $calendar_data['start_day']) {
                    echo '<td style="width: 10em; height: 10em"></td>';
                } else {
                    //change color of the cell based on if the count of the cell is the current day of the month
                    echo ($count == $calendar_data['current_day_of_month'] && date('m') == date('m', $make_month) && date('Y') == $calendar_data['current_year'])
                        ? "<td style=\"background-color: white; color: black; width: 10em; height: 10em;\"><div style=\"overflow: auto; width: 100%; height: 100%; margin: 0; padding: 0;\">$count"
                        : "<td style=\"width: 10em; height: 10em;\"><div style=\"overflow: auto; width: 100%; height: 100%; margin: 0; padding: 0;\">$count";
                        foreach($events as $row):
                            $date = new DateTime($row->date);
                            $day = $date->format('d');
                            $month = $date->format('m');
                            $year = $date->format('Y');
                            if ($count == $day && $calendar_data['current_year'] == $year && date('m', $make_month) == $month):
                                echo "<p><a href=\"" . base_url() . "view_event/" . $row->event_id . "\">$row->event_name</a></p>";
                            endif;
                        endforeach;
                        "</div></td>";
                    $count++;
                }

            }
            if ($flag) break;

            ?>
<!--            <td style="width: 10em; height: 10em"></td>-->
            <?php }  ?>
    </table>
    <p>
        <?/* foreach ($all_events->result() as $row):  ?>
        <?
            echo '<p>';
            echo $row->event_id;
            echo $row->date;
            echo $row->time;
            echo $row->event_name;
            echo $row->event_description;
            echo $row->location;
            echo '</p>';
        ?>
        <? endforeach; */?>
    </p>
</div>