<div class="container body-content">

	<h2>Example of creating Modals with Twitter Bootstrap</h2>
<!-- Button trigger modal -->
<button class="btn btn-primary btn-lg" data-toggle="modal" 
   data-target="#myModal">
   Launch demo modal
</button>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" 
   aria-labelledby="myModalLabel" aria-hidden="true">
   <div style="width: 100%;" class="modal-dialog">
      <div style="height: 400px; background: url('http://www.chadgolden.com/media/filmclub.png'); background-repeat: no-repeat; background-size: 100%" class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" 
               data-dismiss="modal" aria-hidden="true">
                  &times;
            </button>
            <h1 style="font-weight: normal" class="modal-title text-center" id="myModalLabel">
               Welcome.
            </h1>
         </div>
         <div style="height: 100%" class="modal-body">
            Add some text here
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-default" 
               data-dismiss="modal">Close
            </button>
            <button type="button" class="btn btn-primary">
               Submit changes
            </button>
         </div>
      </div><!-- /.modal-content -->
</div><!-- /.modal -->
</div>
<div class="container body-content">
      <p><img class="img img-responsive" src="http://www.chadgolden.com/media/filmclub.png"></p>
</div>