<div class="container body-content">
    <h1>
        Suggestions
        <small>
            Have a suggestion? Want to work with us? Tell us here!
        </small>
    </h1>
    <hr />
    <div class="row">
        <div class="col-xs-12 col-md-8 col-md-offset-2">
            <?php if ($errors = $this->session->flashdata('validation_errors')) { ?>
                <div class="alert alert-danger">
                    <?php echo $errors; ?>
                </div>
            <?php  } ?>
            <?php if ($success = $this->session->flashdata('success')) { ?>
                <div class="alert alert-success">
                    <?php echo $success; ?>
                </div>
            <?php  } ?>
            <form class="form-horizontal" method="post" action="<?php echo base_url(); ?>submit_suggestion">
                <fieldset>
                    <legend>Contact Information</legend>
                    <div class="form-group">
                        <label for="first_name" class="col-lg-2 control-label">First Name</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" name="first_name" id="first_name" placeholder="First Name" autocomplete="off">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="last_name" class="col-lg-2 control-label">Last Name</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" name="last_name" id="last_name" placeholder="Last Name" autocomplete="off">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="email" class="col-lg-2 control-label">Email</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" name="email" id="email" placeholder="What email address may we contact you with?" autocomplete="off">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="phone" class="col-lg-2 control-label">Phone</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" name="phone" id="phone" placeholder="What phone number may we contact you with?" autocomplete="off">
                        </div>
                    </div>
                    <legend>Suggestion Information</legend>
                    <div class="form-group">
                        <label for="subject" class="col-lg-2 control-label">Subject</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" name="subject" id="subject" placeholder="What is this in regards to?" autocomplete="off">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="body" class="col-lg-2 control-label">Message</label>
                        <div class="col-lg-10">
                            <textarea rows="15" class="form-control" name="body" id="body" placeholder="Enter your detailed message." autocomplete="off"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-lg-10 col-lg-offset-2">
                            <input type="submit" class="btn btn-primary btn-border" value="Submit">
                        </div>
                    </div>
                </fieldset>
            </form>
        </div>
    </div>
</div>