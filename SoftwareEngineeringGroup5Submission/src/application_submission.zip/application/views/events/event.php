<div class="container body-content">
    <? $this->view('templates/error_success_bar'); ?>
    <h1><? echo $event_data->row()->event_name; ?></h1>
    <hr />
    <? if ($this->session->userdata('account_level') > 2): ?>
    <div class="row">
        <div class="col-xs-12">
            <div class="pull-right">
                <button class="btn btn-danger"
                        data-toggle="modal"
                        data-target="#event_delete_modal">
                    Delete Event
                </button>
            </div>
        </div>
    </div>
    <? endif; ?>
    <div class="row">
        <div class="col-xs-10 col-xs-offset-1">
            <h3>Event Information</h3>
            <table class="table table-bordered table-striped">
                <tr>
                    <th style="width: 20%">Event #</th>
                    <td><? echo $event_data->row()->event_id ?></td>
                </tr>
                <tr>
                    <th style="width: 20%">Date</th>
                    <td><? echo $event_data->row()->date ?></td>
                </tr>
                <tr>
                    <th style="width: 20%">Time</th>
                    <td><? echo $event_data->row()->time ?></td>
                </tr>
                <tr>
                    <th style="width: 20%">Location</th>
                    <td><? echo $event_data->row()->location ?></td>
                </tr>
                <tr>
                    <th style="width: 20%">Event Description</th>
                    <td><? echo $event_data->row()->event_description ?></td>
                </tr>

            </table>
        </div>
    </div>
</div>
<div class="modal fade" id="event_delete_modal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="modal_title">Delete Event "<? echo $event_data->row()->event_name ?>"</h4>
            </div>
            <div class="modal-body">
                Are you sure you would like to delete this event? This action cannot be undone.
                <p></p>
                <form class="form-horizontal" method="post" action="<? echo base_url(); ?>delete_event" id="modal_form">
                    <fieldset>
                        <input type="hidden"
                               name="hidden_event_id"
                               id="hidden_event_id"
                               value="<? echo $event_data->row()->event_id ?>" />
                        <div class="form-group">
                            <div class="col-lg-12">
                                <input type="submit" class="btn btn-danger" name="submit" id="submit" value="Delete" />
                                <button type="button" class="btn btn-default" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">Cancel</span>
                                </button>
                            </div>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
</div>