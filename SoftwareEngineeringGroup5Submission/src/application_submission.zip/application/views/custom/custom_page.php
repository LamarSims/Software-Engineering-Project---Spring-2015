<? $this->view('templates/error_success_bar'); ?>
<div class="container body-content">

    <h1 class="page-header">
        <? echo $title ?>
    </h1>
    <h4>
        <small>
            posted by <?echo '<strong style="color: #ffffff">' . $page_data->row()->username . '</strong>' . ' at ' .  date('F j, Y, g:i a', strtotime($page_data->row()->created)); ?>
        </small>
    </h4>
    <hr />

    <div class="row">
        <div class="col-xs-10 col-xs-offset-1">
            <div style="min-height: 250px" class="well">
                <? echo nl2br($page_data->row()->body); ?>
            </div>
        </div>
    </div>
    <h3>
        <? //echo $discussion_data->row()->title; ?>
        Comments
        <span class="badge"><? echo $page_data->row()->comments; ?></span>
    </h3>

    <hr />
    <div class="row">
        <div class="col-xs-10 col-xs-offset-1">
            <? if ($discussion_topics->num_rows() < 1): ?>
            <p>
                <em>This page contains no comments.</em>
            </p>
            <? $this->unit->run($discussion_topics->num_rows(), 0, 'Discussion topics should be zero, here.') ?>
            <? else: ?>
            <? foreach($discussion_topics->result() as $row): ?>
                <div class="row">
                    <div class="col-xs-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-12 col-md-6">
                                        <? echo $title = $row->title ?>
                                    </div>
                                    <div class="col-xs-12 col-md-6">
                                        <div class="text-muted pull-right">
                                            <? echo 'by <strong>' . $author = $row->username; echo '</strong> on ' .
                                                $timestamp = date('F j, Y, g:i a', strtotime($row->timestamp)) ?>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-xs-11">
                                        <? echo $body = $row->body ?>
                                    </div>
                                    <div class="col-xs-1">
                                        <a href="#modal_reply" class="btn btn-default btn-xs" data-toggle="modal"
                                           data-target="#modal_reply"
                                           data-reply-to-discussion-id="<? echo $row->discussion_topic_id ?>">
                                            <span class="glyphicon glyphicon-share-alt"></span>
                                            &nbsp;Reply
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <? if (isset($discussion_replies)): // Start check for replies. ?>
                <? foreach ($discussion_replies[$row->discussion_topic_id]->result() as $reply): ?>
                    <div class="row">
	                    	<div class="col-xs-10 col-xs-offset-2">
	              <div class="panel panel-default">
			    <div class="panel-heading" role="tab" id="headingOne">
			      <h4 class="panel-title">
			        <!--<a data-toggle="collapse" data-parent="#accordion" href="#collapse_<? echo $reply->reply_id ?>" aria-expanded="true" aria-controls="collapse_<? echo $reply->reply_id ?>">-->
			          <span class="glyphicon glyphicon-share-alt"></span>
                                  &nbsp;
			          <? echo '<strong>Re: ' . $title . '</strong>' ?>
	                          <? echo '<div style="display:inline" class="text-muted"> by <strong>' . $replier = $reply->username . '</strong> on ' . $reply_timestamp = date('F j, Y, g:i a', strtotime($reply->timestamp)) . '</div>'?>
	                          <div class="pull-right">
	                          	<button data-toggle="collapse" data-parent="#accordion" data-target="#collapse_<? echo $reply->reply_id ?>" class="btn btn-primary btn-xs">Expand</button>
	                          </div>
			        <!--</a>-->
			      </h4>
			    </div>
			    <div id="collapse_<? echo $reply->reply_id ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
			      <div class="panel-body">
			        <br />
	                        <? echo $reply->body ?>
			      </div>
			    </div>
			  </div>
			  </div>
                        <div class="col-xs-10 col-xs-offset-2">
                            <div class="panel panel-default">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <span class="glyphicon glyphicon-share-alt"></span>
                                            &nbsp;
                                            <? echo '<strong>Re: ' . $title . '</strong>' ?>
                                            <? echo '<div style="display:inline" class="text-muted"> by <strong>' .
                                                $replier = $reply->username . '</strong> on ' .
                                                    $reply_timestamp
                                                        = date('F j, Y, g:i a', strtotime($reply->timestamp))
                                                        . '</div>' ?>
                                        </div>
                                        <div class="col-xs-3 pull-right text-muted">
                                            <?// echo ' by <strong>' . $replier = $reply->username . '</strong> on ' . $reply_timestamp = date('F j, Y, g:i a', strtotime($reply->timestamp)) ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <br />
                                            <? echo $reply->body ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <? endforeach ?>
            <? endif; // End check for replies. ?>
            <? endforeach; ?>
            <div class="row">
                <div class="col-xs-12">
                    <div class="text-center">
                        <nav>
                            <ul class="pagination">
                                <li>
                                    <a href="<?php echo base_url() . 'discussion/load/1/' . $pagination['results_per_page']; ?>" aria-label="First">
                                        <span  aria-hidden="true">&laquo;</span>
                                        &nbsp; First
                                    </a>
                                </li>
                                <!--                            <a href="--><?php //echo base_url() . 'home/' ?><!--">-->
                                <!--                                --><?// echo $pagination['current_page'] ?>
                                <!--                            </a>-->
                                <? for ($page_number = 1; $page_number <= $pagination['total_pages']; $page_number++): ?>
                                    <? if ($page_number > 9): ?>
                                        <li class="<? if ($page_number == $pagination['current_page']) echo 'active'; ?>">
                                            <a href=
                                               "<?php echo base_url() . 'custom/' . $page_data->row()->page_id
                                                . '/' . $page_number . '/' . $pagination['results_per_page']; ?>" >
                                                <? echo '...'; ?>
                                            </a>
                                        </li>
                                        <? break; ?>
                                    <? endif; ?>
                                    <li class="<? if ($page_number == $pagination['current_page']) echo 'active'; ?>">
                                        <a href="
                                            <?php echo base_url() . 'custom/' . $page_data->row()->page_id
                                            . '/' . $page_number . '/' . $pagination['results_per_page']; ?>" >
                                                <? echo $page_number ?>
                                        </a>
                                    </li>
                                <? endfor; ?>
                                <li>
                                    <a href="
                                        <?php echo base_url() . 'custom/' . $page_data->row()->page_id
                                        . '/' . $page_number . '/' . $pagination['results_per_page']; ?>"
                                       aria-label="Next">
                                            Last &nbsp;&nbsp;
                                            <span aria-hidden="true">&raquo;</span>
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
            <? endif; ?>
            <?
            //$row_number = 1;
            foreach ($reply_data->result() as $row):
                //if ($row_number++ == 1) continue;
            ?>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <? echo $row->title ?>
                        <div style="float: right" class="text-muted">
                            posted by <? echo $row->username . ' at ' . $row->timestamp ?>
                        </div>
                    </div>
                    <div class="panel-body">
                        <? echo nl2br($row->body) ?>
                    </div>
                </div>
            <?
            endforeach
            ?>
        </div>
    </div>
    <h3>
        Post Comment
        <small style="font-size: 16px">
            Login Required
        </small>
    </h3>

    <hr />
    <div class="row">
        <div class="col-xs-12 col-md-8 col-md-offset-2">
            <div class="well">
                <form class="form-horizontal" method="post" action="<?php echo base_url(); ?>discussion/new_topic">
                    <fieldset>
                        <legend>New Topic</legend>
                        <div class="form-group">
                            <label for="discussion_topic" class="col-lg-2 control-label">Title</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="discussion_topic" id="discussion_topic" placeholder="Enter a title." autocomplete="off" />
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="discussion_body" class="col-lg-2 control-label">Message</label>
                            <div class="col-lg-10">
                            <textarea rows="10" class="form-control" name="discussion_body" id="discussion_body" placeholder="Enter the main content for this page." autocomplete="off">

                            </textarea>
                            </div>
                        </div>
                        <input type="hidden" value="<? if ($user_id = $this->session->userdata('user_id')) echo $user_id; ?>" name="user_id_hidden" id="user_id_hidden" />
                        <input type="hidden" value="<? echo $page_data->row()->discussion_board_id ?>" name="discussion_board_id_hidden" id="discussion_board_id_hidden" />
                        <input type="hidden" value="<? echo uri_string() ?>" name="page_route_hidden" id="page_route_hidden" />
                        <div class="form-group">
                            <div class="col-lg-2"></div>
                            <div class="col-lg-10">
                                <input type="submit" class="btn btn-success btn-border" value="Submit" />
                            </div>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="modal_reply" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="modal_title">Reply</h4>
            </div>
            <div class="modal-body">
                Complete the following information and click "Submit" to post your reply.
                <form class="form-horizontal" method="post" action="" id="modal_form">
                    <fieldset>
                        <input type="hidden" name="hidden_discussion_topic_id" id="hidden_discussion_topic_id" value="" />
                        <input type="hidden" name="hidden_user_id" id="hidden_user_id" value="<? echo $this->session->userdata('user_id'); ?>" />
                        <input type="hidden" value="<? echo uri_string() ?>" name="page_route_hidden" id="page_route_hidden" />
                        <p></p>
                        <div class="form-group">
                            <label for="reply_body" class="col-lg-2 control-label">Message</label>
                            <div class="col-lg-10">
                                <textarea rows="15" name="reply_body" id="reply_body" placeholder="Enter your message here." autocomplete="off"></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-lg-12">
                                <input type="submit" class="btn btn-success" name="submit" id="submit" value="Submit" onclick="return submitForm()" autocomplete="off">
                                <button type="button" class="btn btn-default" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">Cancel</span></button>
                            </div>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="<? echo base_url() ?>scripts/tinymce/js/tinymce/tinymce.min.js"></script>
<script type="text/javascript">
    tinymce.init({
        skin: "darkly",
        selector: "textarea",
        plugins: [
            "autolink lists link image charmap print preview anchor",
            "searchreplace visualblocks code fullscreen",
            "insertdatetime media contextmenu paste"
        ],
        toolbar: "bold italic | bullist numlist | link image"
    });
</script>
<script>
    // To set the correct discussion_topic_id for the modal reply.
    $(document).ready(function() {
        $('#modal_reply').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget) // Button that triggered the modal
            var discussionId = button.data('reply-to-discussion-id') // Extract info from data-* attributes
            // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
            // Update the modal's content. We'll use jQuery here,
            // but you could use a data binding library or other methods instead.
            var modal = $(this)
            modal.find('#hidden_discussion_topic_id').val(discussionId);
        })
    });
</script>
<script>
    /* Sends the form action to reply to a discussion_topic of some ID number */
    function submitForm() {
        /* For debugging */ //var formUrl = $("#modal_form").attr("action"); alert(formUrl);
        // Get the page ID number from the hidden_page_id input element.
        var discussionId = $("#hidden_discussion_topic_id").val();

        // Set the action for the confirmation form within the modal dialog.
        // Sends to the delete function within the custom page controller with the page ID.
        $("#modal_form").attr("action","<? echo base_url() ?>discussion/new_reply");

        // Submit the form.
        $("#modal_form").submit();
    }
</script>