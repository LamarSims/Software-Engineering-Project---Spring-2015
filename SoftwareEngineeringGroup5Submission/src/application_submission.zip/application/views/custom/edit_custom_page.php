<div class="container body-content">
    <h1>
        Edit Custom Page
        <small>
            <em><? echo $page_data->row()->title; ?></em>
        </small>
    </h1>
    <hr />

    <div class="row">
        <div class="col-xs-12 col-md-8 col-md-offset-2">
            <?php if ($errors = $this->session->flashdata('validation_errors')): ?>
    <div class="alert alert-danger">
        <?php echo $errors; ?>
    </div>
    <?php endif ?>
    <?php if ($success = $this->session->flashdata('success')): ?>
        <div class="alert alert-success">
            <?php echo $success; ?>
        </div>
    <?php  endif ?>
<form class="form-horizontal" method="post" action="<?php echo base_url(); ?>dashboard/custom_pages/submit_edit">
    <fieldset>
        <legend>Who will be able to see this page?</legend>
        <div class="form-group">
            <label for="account_level_option" class="col-lg-2 control-label">Audience</label>
            <div class="col-lg-10">
                <select class="form-control" name="account_level_option" id="account_level_option" placeholder="Who can access this page?" autocomplete="off" >
                    <? $level = $page_data->row()->account_level ?>
                    <option <? if ($level == -1) echo 'selected' ?> value="-1">Everyone</option>
                    <option <? if ($level == 0) echo 'selected' ?> value="0">Registered Website Users</option>
                    <option <? if ($level == 1) echo 'selected' ?> value="1">Film Club Members</option>
                    <option <? if ($level == 2) echo 'selected' ?> value="2">Film Club Moderators</option>
                    <option <? if ($level == 3) echo 'selected' ?> value="3">Administrators</option>
                </select>
            </div>
        </div>
        <br />
        <br />
        <br />
        <br />
        <legend>Page Information</legend>

        <div class="form-group">
            <label for="custom_page_title" class="col-lg-2 control-label">Title</label>
            <div class="col-lg-10">
                <input type="text" class="form-control" name="custom_page_title" id="custom_page_title"
                       placeholder="Enter the title for this page." autocomplete="off"
                       value="<? echo $page_data->row()->title ?>">
            </div>
        </div>
        <script type="text/javascript" src="<? echo base_url() ?>scripts/tinymce/js/tinymce/tinymce.min.js"></script>
        <script type="text/javascript">
            tinymce.init({
                skin: "darkly",
                selector: "textarea",
                plugins: [
                    "advlist autolink lists link image charmap print preview anchor",
                    "searchreplace visualblocks code fullscreen",
                    "insertdatetime media table contextmenu paste"
                ],
                toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright | bullist numlist outdent indent | link image video"
            });
        </script>
        <legend>Body Content</legend>
        <div class="form-group">
            <div class="col-lg-12">
                <textarea rows="25" class="form-control" name="custom_page_body" id="custom_page_body" placeholder="Enter the main content for this page." autocomplete="off">
                    <? echo $page_data->row()->body ?>
                </textarea>
            </div>
        </div>
        <input type="hidden" value="<? echo $session['user_id'] ?>" name="user_id_hidden" id="user_id_hidden" />
        <input type="hidden" value="<? echo $page_data->row()->page_id ?>" name="page_id_hidden" id="page_id_hidden" />
        <div class="form-group">
            <div class="col-lg-10">
                <input type="submit" class="btn btn-info btn-border" value="Submit">
            </div>
        </div>
    </fieldset>
</form>
</div>
</div>
</div>