<div class="container body-content">
    <h1>
        Create Custom Page
        <small>
            Users will access the page you create.
        </small>
    </h1>
    <hr />

    <div class="row">
        <div class="col-xs-12 col-md-8 col-md-offset-2">
            <?php if ($errors = $this->session->flashdata('validation_errors')): ?>
                <div class="alert alert-danger">
                    <?php echo $errors; ?>
                </div>
            <?php endif ?>
            <?php if ($success = $this->session->flashdata('success')): ?>
                <div class="alert alert-success">
                    <?php echo $success; ?>
                </div>
            <?php  endif ?>
            <form class="form-horizontal" method="post" action="<?php echo base_url(); ?>dashboard/custom_pages/submit_create">
                <fieldset>
                    <legend>Who will be able to see this page?</legend>
                    <div class="form-group">
                        <label for="account_level_option" class="col-lg-2 control-label">Audience</label>
                        <div class="col-lg-10">
                            <select class="form-control" name="account_level_option" id="account_level_option" placeholder="Who can access this page?" autocomplete="off">
                                <option value="-1">Everyone</option>
                                <option value="0"> Registered Website Users</option>
                                <option value="1">Film Club Members</option>
                                <option value="2">Film Club Moderators</option>
                                <option value="3">Administrators</option>
                            </select>
                        </div>
                    </div>
                    <br />
                    <br />
                    <br />
                    <br />
                    <legend>Page Information</legend>

                    <div class="form-group">
                        <label for="custom_page_title" class="col-lg-2 control-label">Title</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" name="custom_page_title" id="custom_page_title" placeholder="Enter the title for this page." autocomplete="off">
                        </div>
                    </div>

                    <!--
                    <div class="form-group">
                        <div class="btn-group col-lg-offset-2 col-lg-10">
                            <button class="btn btn-default" style="" onclick="alert('HEY!!!');">
                                <span class="glyphicon glyphicon-bold"></span>
                            </button>
                            <button class="btn btn-default">
                                <span class="glyphicon glyphicon-italic"></span>
                            </button>
                            <button class="btn btn-default">
                                <span class="glyphicon glyphicon-film"></span>
                                &nbsp;&nbsp;Embed Video
                            </button>
                            <button class="btn btn-default">
                                <span class="glyphicon glyphicon-picture"></span>
                                &nbsp;&nbsp;Embed Image
                            </button>
                            <button class="btn btn-default">
                                <span class="glyphicon glyphicon-link"></span>
                                &nbsp;&nbsp;Hyperlink
                            </button>
                            <button class="btn btn-default">
                                <span class="glyphicon glyphicon-folder-open"></span>
                                &nbsp;&nbsp;Attach
                            </button>

                        </div>
                    </div>
                    -->
                    <!--<div class="form-group">
                        <label for="custom_page_body" class="col-lg-2 control-label">Body Text</label>
                        <div class="col-lg-10">
                            <textarea rows="25" class="form-control" name="custom_page_body" id="custom_page_body" placeholder="Enter the main content for this page." autocomplete="off"></textarea>
                        </div>
                    </div>-->
                    <!-- JS HTML Text editor thanks to tinymce -->
                    <script type="text/javascript" src="<? echo base_url() ?>scripts/tinymce/js/tinymce/tinymce.min.js"></script>
                    <script type="text/javascript">
                        tinymce.init({
                            skin: "darkly",
                            selector: "textarea",
                            plugins: [
                                "advlist autolink lists link image charmap print preview anchor",
                                "searchreplace visualblocks code fullscreen",
                                "insertdatetime media table contextmenu paste"
                            ],
                            toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
                        });
                    </script>
                    <!--
                    <div class="form-group">
                        <label for="custom_page_body" class="col-lg-2 control-label">Body</label>
                        <div class="col-lg-10">
                            <textarea name="custom_page_body" rows="25"></textarea>
                        </div>
                    </div>
                    -->
                    <legend>Body Content</legend>
                    <div class="form-group">
                        <div class="col-lg-12">
                            <textarea rows="25" class="form-control" name="custom_page_body" id="custom_page_body" placeholder="Enter the main content for this page." autocomplete="off">
                            </textarea>
                        </div>
                    </div>
                    <input type="hidden" value="<? echo $session['user_id'] ?>" name="user_id_hidden" id="user_id_hidden" />
                    <div class="form-group">
                        <div class="col-lg-10">
                            <input type="submit" class="btn btn-info btn-border" value="Submit">
                        </div>
                    </div>
                </fieldset>
            </form>
        </div>
    </div>
</div>