	<footer class="footer navbar navbar-fixed-bottom">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#footer-body">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <div class="container">
	            <div class="row">
	            	<div class="col-sm-12 col-md-5">
	            		<p class="text-center">
	            			<!-- old <img class="hidden-xs hidden-sm" style="height: 125px; width: auto" src="<?php echo base_url(); ?>images/GSU_film_club.png" />
	            			<img class="hidden-md hidden-lg" style="height: 60px; width: auto;" src="<?php echo base_url(); ?>images/GSU_film_club.png" /> -->
	            			<img class="hidden-xs hidden-sm" style="height: 200px; width: auto" src="http://www.chadgolden.com/media/film_club_logo_transparent_small_with_gsu.png" />
	            			<img class="hidden-md hidden-lg" style="height: 100px; width: auto;" src="http://www.chadgolden.com/media/film_club_logo_transparent_small_with_gsu.png" />
	            		</p>
	            	</div>
	            	<div class="col-sm-12 col-md-7">
	            		<div class="well">
	            			<div class="row">
	            				<div class="col-sm-12 col-md-4">
	            					<div class="text-center">
		            					<span class="footer-head-text text-center">Site</span>
		            					<ul class="nav nav-stacked">
	  										<li role="presentation">
												<a href="dropdown-toggle" data-toggle="dropdown" role="button" class="text-left">
													<div class="row">
	  													<div class="col-xs-11 col-xs-offset-1">
	  														About
															<span class="caret"></span>
	  													</div>
	  												</div>
												</a>
												<ul class="dropdown-menu" role="menu">
													<li>
														<a href="members">Our Members</a>
													</li>
													<li>
														<a href="about">About Us</a>
													</li>
													<li>
														<a href="contact">Contact</a>
													</li>
												</ul>
											</li>
	  										<li role="presentation">		
	  											<a href="<?php echo base_url(); ?>news/view">
	  												<div class="row">
	  													<div class="col-xs-11 col-xs-offset-1">
	  														News
	  													</div>
	  												</div>
	  											</a>
	  										</li>
	  										<li role="presentation">
	  											<a href="<?php echo base_url(); ?>events">
	  												<div class="row">
	  													<div class="col-xs-11 col-xs-offset-1">
	  														Events
	  													</div>
	  												</div>
	  											</a>
	  										</li>
	  										<li role="presentation">
	  											<a href="dropdown-toggle" data-toggle="dropdown" role="button">
	  												<div class="row">
	  													<div class="col-xs-11 col-xs-offset-1">
	  														Media
															<span class="caret"></span>
	  													</div>
	  												</div>
												</a>
												<ul class="dropdown-menu" role="menu">
													<li>
														<a href="images">Images</a>
													</li>
													<li>
														<a href="videos">Videos</a>
													</li>
													<li>
														<a href="<?php echo base_url(); ?>">Documents</a>
													</li>
												</ul>
	  										</li>
										</ul>
	            					</div>
	            				</div>
	            				<div class="col-sm-12 col-md-4">
									<div class="text-center">
	            						<span class="footer-head-text">Links</span>
											<div class = "row">
												<ul class="nav nav-stacked">
													<li role="presentation">
														<a  href="https://my.georgiasouthern.edu/">
															<div class="row">
																<div class="col-xs-11 col-xs-offset-1">
																	MyGeorgiaSouthern
																</div>
															</div>
														</a>
													</li>

													<li role="presentation">
														<a href="http://www.thegeorgeanne.com/">
															<div class="row">
																<div class="col-xs-11 col-xs-offset-1">
																	George-Anne
																</div>
															</div>
														</a>
													</li>

													<li role="presentation">
														<a href= "http://www.wunderground.com/q/zmw:30458.1.99999?MR=1">
															<div class="row">
																<div class="col-xs-11 col-xs-offset-1">
																	Weather
																</div>
															</div>
														</a>
													</li>
												</ul>
											</div>

									</div>
								</div>


	            				<div class="col-sm-12 col-md-4 text-center">
	            					<span class="footer-head-text">Follow Us</span>
										<a class="btn btn-social-icon btn-youtube"  href="http://www.youtube.com/FilmClubGSU">
    										<i class="fa fa-youtube"></i>
  										</a>
	            						<a class="btn btn-social-icon btn-twitter"  href="http://www.twitter.com/FilmClubGSU">
    										<i class="fa fa-twitter"></i>
  										</a>
  										<a class="btn btn-social-icon btn-facebook" href="http://www.facebook.com/">
    										<i class="fa fa-facebook"></i>
  										</a>
  										<a class="btn btn-social-icon btn-google-plus" href="http://www.googleplus.com/">
    										<i class="fa fa-google-plus"></i>
  										</a>
	            				</div>	            					            				
	            			</div>
	            		</div>
	            	</div>
            	</div>
            	<div class="row">
            		<div class="col-xs-12 col-lg-12 text-center">
            			<div class="col-xs-12 col-md-4 col-md-offset-4">
<!--							<form class="form" action="http://www.google.com/cse" id="tubigakawal" target="_blank" method="get">-->
<!--								<div class="input-group">-->
<!--									<input type="hidden" name="cx" value="014069094613642644910:k0k122uptq4" />-->
<!--    								<input type="hidden" name="ie" value="UTF-8" />-->
<!--		      						<input type="text" name="q" class="form-control" placeholder="Search this site...">-->
<!--		      						<span class="input-group-btn">-->
<!--		      							<button type="submit" name="sa" class="btn btn-info btn-outline">-->
<!--		      								<span class="glyphicon glyphicon-search"></span>-->
<!--		      							</button>-->
<!--		      						</span>-->
<!--								</div>-->
<!--	    					</form><!-- form -->-->
							<form class="form" action="<? echo base_url(); ?>search" target="_blank" method="post">
								<div class="input-group">
									<input type="text"
										   name="search_bar_footer"
										   id="search_bar_footer"
										   class="form-control"
										   placeholder="Search this site..." />
									<span class="input-group-btn">
										<button type="submit" name="search_bar_footer_submit" class="btn btn-info btn-outline">
											<span class="glyphicon glyphicon-search"></span>
										</button>
									</span>
								</div>
							</form>
            			</div>
            		</div>
            	</div>
            	<div class="row">
            		<div class="col-xs-12 col-lg-12">
            			<p class="copyright-md hidden-sm hidden-xs">
            				Copyright&nbsp;&copy; <?php echo date('Y') . '. The Film Club of Georgia Southern University. All rights reserved.'; ?>
            			</p>
            			<p class="copyright-sm hidden-md hidden-lg">
            				Copyright&nbsp;&copy; <?php echo date('Y') . '. The Film Club of Georgia Southern University. All rights reserved.'; ?>
            			</p>        			
            		</div>
            	</div>
            </div>
            <p>
            </p>
	</footer>
	<script type="text/javascript" src="http://www.google.com/cse/cse/brand?form=cse-search-box&amp;lang=en"></script>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
</body>
</html>