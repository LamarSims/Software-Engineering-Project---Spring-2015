<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<?
	// Load CI Inflector.
	// This will properly space and capitalize words that have underscores. (e.g. My_name -> My Name)
	// Note this only applies to the templates/header view, the global data array is passed again for each view.
	$this->load->helper('inflector');
	$title = humanize($title);
	?>
	<title><?php echo $title ?></title>
	
	<link href="<?php echo base_url(); ?>styles/css/bootstrap.min.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>styles/css/custom.css?<?php echo time(); ?>" rel="stylesheet"><!-- time() to avoid cache for timely tests -->
	<link href="<?php echo base_url(); ?>styles/css/bootstrap-social.css" rel="stylesheet">
	<link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
	<link rel="icon" type="image/png"
		  href="<? echo base_url(); ?>images/icon.png" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script type="text/javascript">
	  var _gaq = _gaq || [];
	  _gaq.push(['_setAccount', 'UA-12953034-1']);
	  _gaq.push(['_setDomainName', 'ellislab.com']);
	  _gaq.push(['_setCustomVar', 1, 'Category', 'user-guide',3]);
	  _gaq.push(['_setCustomVar', 2, 'Product', 'ExpressionEngine',3]);
	  _gaq.push(['_setCustomVar', 3, 'Member Group', '3',3]);
	  _gaq.push(['_setCustomVar', 4, 'Site', '{site_short_name}',3]);
	  _gaq.push(['_trackPageview']);

	function trackOutboundLink(link, category, action, label) {

	try {
	_gaq.push(['_trackEvent', category , action, label]);
	} catch(err){}

	setTimeout(function() {
	// jQuery handles rel="external" links for us so we don't have anything to do here but pause
	return false;
	}, 100);
	}

	(function() {
	    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
	    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
	    var s = document.getElementsByTagName('script')[0];
		s.parentNode.insertBefore(ga, s);
	})();
	</script>
	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
	<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
</head>
<body>
	<nav class="navbar navbar-default">
	  	<div class="container">
			<div class="navbar-header">
		  		<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span> 
		  		</button>
		  		<!-- <a class="navbar-brand" href="home.php"></a> -->
		  		<a href="<?php echo base_url(); ?>">
		  			<img style="height: 50px; width: auto; margin-left: 5px; margin-right: 5px; margin-top: 5px;" src="<? echo base_url(); ?>images/film_club_logo_transparent_small.png" />
		  		</a>
			</div>
			<div id="navbar" class="navbar-collapse collapse">
	   			<ul class="nav navbar-nav">
					<li role="presentation">
						<a href="dropdown-toggle" data-toggle="dropdown" role="button">
							About
							<span class="caret"></span>
						</a>
						<ul class="dropdown-menu" role="menu">
							<li>
								<a href="<?php echo base_url(); ?>members">
									<i class="glyphicon glyphicon-user"></i>
									&nbsp;Our Members
								</a>
							</li>
							<li>
								<a href="<?php echo base_url(); ?>about">
									<i class="glyphicon glyphicon-question-sign"></i>
									&nbsp;About Us
								</a>
							</li>
							<li>
								<a href="<?php echo base_url(); ?>contact">
									<i class="glyphicon glyphicon-phone"></i>
									&nbsp;Contact
								</a>
							</li>
							<li>
								<a href="<?php echo base_url(); ?>suggestions">
									<i class="glyphicon glyphicon-exclamation-sign"></i>
									&nbsp;Suggestions
								</a>
							</li>
							<? if ($this->session->userdata('account_level') >= 7): ?>
							<li>
								<a href="developer">DEVELOPER TEST PAGE</a>
							</li>
							<? endif; ?>
						</ul>
					</li>
					<li role="presentation">
						<a href="<?php echo base_url(); ?>discussion">Discussion</a>
					</li>
					<li role="presentation">
						<a href="<?php echo base_url(); ?>events">Events</a>
					</li>
					<li role="presentation">
						<a href="dropdown-toggle" data-toggle="dropdown" role="button">
							Media
							<span class="caret"></span>
						</a>
						<ul class="dropdown-menu" role="menu">
							<li>
								<a href="<?php echo base_url(); ?>pictures">
									<i class="glyphicon glyphicon-picture"></i>
									&nbsp;Pictures
								</a>
							</li>
							<li>
								<a href="<?php echo base_url(); ?>videos">
									<i class="glyphicon glyphicon-film"></i>
									&nbsp;Videos
								</a>
							</li>
							<li>
								<a href="<?php echo base_url(); ?>site_pages">
									<i class="glyphicon glyphicon-file"></i>
									&nbsp;Site Pages
								</a>
							</li>
						</ul>
					</li>
	   			</ul>
	   			<?php if ($is_logged_in === FALSE) { ?>
		 	<form class="navbar-form navbar-right" method="post" action="<?php echo base_url(); ?>verify_login/header">
				<div class="form-group">
			  		<input type="text" placeholder="Email" name="email" class="form-control input-sm">
				</div>
				<div class="form-group">
			  		<input type="password" placeholder="Password" name="password" class="form-control input-sm">
				</div>
				<span class="hidden-xs">&nbsp;</span>
				<div class="btn-group">
					<button type="submit" class="btn btn-info btn-border" >
						Sign in&nbsp;
						<span class="glyphicon glyphicon-user"></span>
					</button>
					<a class="btn btn-info btn-border" href="<?php echo base_url(); ?>register">
						Register&nbsp;
						<span class="glyphicon glyphicon-pencil"></span>
					</a>
				</div>
		  </form>
		  <?php } else { ?>
		  <div class="navbar-right">
			  	<ul class="nav navbar-nav">
			  		<li role="presentation">
						<a href="dropdown-toggle" data-toggle="dropdown" role="button">
							Logged in as: <strong><?php echo $session['username']; ?></strong>
							<span class="caret"></span>
						</a>
						<ul class="dropdown-menu" role="menu">
							<li>
								<a href="<?php echo base_url(); ?>profile">
									<i class="glyphicon glyphicon-user"></i>
									&nbsp;Your Profile
								</a>
							</li>
							<?php if ($session['account_level'] > 2) { ?>
							<li>
								<a href="<?php echo base_url(); ?>dashboard">
									<i class="glyphicon glyphicon-dashboard"></i>
									&nbsp;Dashboard
								</a>
							</li>
							<?php } ?>
							<li>
								<a href="<?php echo base_url(); ?>#">
									<i class="glyphicon glyphicon-question-sign"></i>
									&nbsp;Placeholder Item
								</a>
							</li>
							<li>
								<a href="<?php echo base_url(); ?>#">
									<i class="glyphicon glyphicon-question-sign"></i>
									&nbsp;Placeholder Item
								</a>
							</li>
							<? if ($this->session->userdata('account_level') >= 7): ?>
								<li role="presentation" class="divider">

								</li>
								<li>
									<a href="<?php echo base_url(); ?>dev/view/1">
										<i class="glyphicon glyphicon-info-sign"></i>
										&nbsp;Developer
									</a>
								</li>
							<? endif; ?>
							<li>
								<a href="<?php echo base_url(); ?>logout">
									<i class="glyphicon glyphicon-off"></i>
									&nbsp;Sign Out
								</a>
							</li>

						</ul>
					</li>
					<li class="text-danger">
						<a href="logout">Sign Out</a>
					</li>
			  	</ul>
		  </div>
		  <?php } ?>
		</div><!--/.navbar-collapse -->
	  </div>
	</nav>