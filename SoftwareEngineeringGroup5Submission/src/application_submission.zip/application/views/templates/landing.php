<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $title ?></title>
	
	<link href="<?php echo base_url(); ?>styles/css/bootstrap.min.css?<?php echo time(); ?>" rel="stylesheet">
	<!--<link href="<?php echo base_url(); ?>styles/css/custom.css?<?php echo time(); ?>" rel="stylesheet"><!-- time() to avoid cache for timely tests -->
	<link href="<?php echo base_url(); ?>styles/css/bootstrap-social.css" rel="stylesheet">
	<link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script type="text/javascript">
	  var _gaq = _gaq || [];
	  _gaq.push(['_setAccount', 'UA-12953034-1']);
	  _gaq.push(['_setDomainName', 'ellislab.com']);
	  _gaq.push(['_setCustomVar', 1, 'Category', 'user-guide',3]);
	  _gaq.push(['_setCustomVar', 2, 'Product', 'ExpressionEngine',3]);
	  _gaq.push(['_setCustomVar', 3, 'Member Group', '3',3]);
	  _gaq.push(['_setCustomVar', 4, 'Site', '{site_short_name}',3]);
	  _gaq.push(['_trackPageview']);

	function trackOutboundLink(link, category, action, label) {

	try {
	_gaq.push(['_trackEvent', category , action, label]);
	} catch(err){}

	setTimeout(function() {
	// jQuery handles rel="external" links for us so we don't have anything to do here but pause
	return false;
	}, 100);
	}

	(function() {
	    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
	    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
	    var s = document.getElementsByTagName('script')[0];
		s.parentNode.insertBefore(ga, s);
	})();
	</script>
	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
	<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<style>
		.carousel {
			position: absolute;
			margin: auto;
			top: 0;
			bottom: 0;
			left: 0;
			right: 0;
		}
		.carousel-inner > .item > img {
			min-width: 100%;
			opacity: 0.1;
		}
		.carousel-caption {
			position: absolute;
			line-height: 1;
			top: 5%;
		}
		.carousel-caption > img {
			opacity: 1.0;
			max-height: 70%;
			max-width: 70%;
			margin-left: auto; 
			margin-right: auto; 
			margin-bottom: 20%;
		}
		.btn-round {
			border-radius: 50%;
		}
		/* Smartphones (portrait) ----------- */
		@media only screen 
		and (max-width : 320px) {
		.carousel {
			position: absolute;
			margin: auto;
			top: 0;
			bottom: 0;
			left: 0;
			right: 0;
		}
		.carousel-inner > .item > img {
			min-height: 100%;
		}
	</style>
	<script>
		function init_carousel() {
	        H = +($(window).height() /* -height here  */); // or $('.carousel-inner') as you want ...
	        $('.carousel-inner').css('height', H + 'px');
	    }
	    window.onload = init_carousel;
	    init_carousel();
	</script>
</head>
<body>
</body>
   <div id="myCarousel" class="carousel slide" data-ride="carousel">
   <!-- <img class="img-responsive" style="z-index: 1; position: absolute; opacity: 1.0; max-height: 66%; max-width:66%; left: 33%; top: 0; margin-left: auto; margin-right: auto; margin-top: 10%;" src="http://www.chadgolden.com/media/film_club_logo_transparent_small_with_gsu.png" /> -->
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
  </ol>

  <!-- Wrapper for slides --> 
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img class="img-responsive visible-sm visible-md visible-lg" src="http://www.chadgolden.com/media/film_club_carousel_1.jpg" alt="">
      <div class="carousel-caption">
      	<img class="img-responsive" style="opacity: 1.0; max-height: 66%; max-width:66%; " src="http://www.chadgolden.com/se/test/images/film_club_logo_transparent_small_banner_with_gsu.png?" />
      	<div class="visible-sm visible-md visible-lg">
      		<a href="<?php echo base_url(); ?>home" style="color: white; font-size: 48px; font-outline: 10px 10px black; font-weight: lighter;">
      			&laquo; Enter &raquo;
      		</a>
      	</div>
      	<div class="visible-xs">
      		<a href="<?php echo base_url(); ?>home" style="color: white; font-size: 20px; font-outline: 10px 10px black; font-weight: lighter; padding-top: 15%">
      			&laquo; Enter &raquo;
      		</a>
      	</div>
      	<hr />
      		<a class="btn btn-social-icon btn-youtube btn-round btn-lg"  href="http://www.youtube.com/">
    			<i class="fa fa-youtube"></i>
  			</a>
	        <a class="btn btn-social-icon btn-twitter btn-round btn-lg"  href="http://www.twitter.com/">
    			<i class="fa fa-twitter"></i>
  			</a>
  			<a class="btn btn-social-icon btn-facebook btn-round btn-lg" href="http://www.facebook.com/">
    			<i class="fa fa-facebook"></i>
  			</a>
  			<a class="btn btn-social-icon btn-google-plus btn-round btn-lg" href="http://www.googleplus.com/">
    			<i class="fa fa-google-plus"></i>
  			</a>
      </div>
      <img class="img-responsive visible-xs" src="http://www.chadgolden.com/media/film_club_carousel_1_mobile.jpg" alt="">
    </div>
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</html>