<? if ($errors = $this->session->flashdata('errors')): ?>
    <div class="container">
        <div class="alert alert-dismissable alert-danger">
            <? echo $errors ?>
        </div>
    </div>
<? elseif ($warning = $this->session->flashdata('warning')): ?>
    <div class="container">
        <div class="alert alert-dismissable alert-warning">
            <? echo $warning ?>
        </div>
    </div>
<? elseif ($success = $this->session->flashdata('success')): ?>
    <div class="container">
        <div class="alert alert-dismissable alert-success">
            <? echo $success ?>
        </div>
    </div>
<? elseif ($info = $this->session->flashdata('info')): ?>
    <div class="container">
        <div class="alert alert-dismissable alert-info">
            <? echo $info ?>
        </div>
    </div>
<? endif ?>