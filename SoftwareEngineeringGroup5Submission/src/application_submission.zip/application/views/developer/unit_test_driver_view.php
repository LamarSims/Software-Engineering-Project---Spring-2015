<div class="container body-content">
    <? $NUMBER_OF_AREAS = 10; ?>
    <div class="page-header">
        <h1>
            Unit Test Driver
            <small>
                <?
                if ( ! isset($is_running)):
                    return;
                else:
                    echo ($is_running) ? '<span class="badge text-success" style="font-size: 20px">Running</span>'
                        : '<span class="badge text-danger" style="font-size: 20px">Not Running</span>';
                endif;
                ?>
                <br />
                <?
                if ( ! isset($is_running)):
                    return;
                else:
                    echo ( ! $is_running) ? '<a href="' . base_url() . 'unit_test_driver/start" class="btn btn-success btn-border">Start</a>'
                        : '<a href="' . base_url() . 'unit_test_driver/stop" class="btn btn-danger btn-border">Stop</a>';
                endif;
                ?>
            </small>
        </h1>

    </div>
    <h3>
        Results
    </h3>
    <a href="<? echo base_url() ?>unit_test_driver/view" class="btn btn-default btn-sm">Refresh</a>
    <hr />
    <div class="row">
        <div class="col-xs-12">
            <?
            $number_of_failures = 0;
            $number_of_successes = 0;
            ?>
            <table class="table table-striped table-bordered" style="font-size: 12px">
                <tr>
                    <th>Test Name</th>
                    <th>Test Datatype</th>
                    <th>Expected Datatype</th>
                    <th>Result</th>
                    <th>File Name</th>
                    <th>Line Number</th>
                    <th>Notes</th>
                    <th>Timestamp</th>
                </tr>
                <? foreach ($current_test_results->result() as $row): ?>
                    <? ($row->result == 'Passed') ? $number_of_successes++ : $number_of_failures++; ?>
                    <tr class="<? echo ($row->result == 'Passed') ? 'success' : 'danger' ?>">
                        <td><? echo $row->test_name ?></td>
                        <td><? echo $row->test_datatype ?></td>
                        <td><? echo $row->expected_datatype ?></td>
                        <td><? echo $row->result ?></td>
                        <td><? echo $row->file_name ?></td>
                        <td><? echo $row->line_number ?></td>
                        <td><? echo $row->notes ?></td>
                        <td><? echo $row->timestamp ?></td>
                    </tr>
                <? endforeach; ?>
            </table>
            <h3>
                Summary
            </h3>
            <hr />
            <p class="text-success">
                Successes: <? echo $number_of_successes; ?>
            </p>
            <p class="text-danger">
                Failures: <? echo $number_of_failures; ?>
            </p>
            <? if (!$number_of_failures == 0 || !$number_of_successes == 0): ?>
            <h4 class="text-info" style="font-weight: bolder;">
                Rate: <? echo round(1.0 - floatval($number_of_failures / ($number_of_successes + $number_of_failures)), 5) * 100.0 . "%" ?>
            </h4>
                <h4 class="text-warning">
                    Coverage:
                    <? echo round(floatval($area_count / ($NUMBER_OF_AREAS)), 5) * 100.0 . "%" ?>
                </h4>
            <? endif; ?>
        </div>
    </div>

</div>
