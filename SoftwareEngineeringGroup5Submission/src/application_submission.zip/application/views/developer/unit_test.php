<?php
/**
 * Created by PhpStorm.
 * User: Chad
 * Date: 3/24/2015
 * Time: 8:15 PM
 */
?>

<div class="container body-content">
    <h1 class="page-header">
        <? echo $title; ?>
    </h1>
    <div class="row">
        <div class="col-xs-12">
            <span class="text-success pull-left"> Unit Test Library Documentation:&nbsp;</span>
            <a href="https://ellislab.com/codeigniter/user-guide/libraries/unit_testing.html">CI Unit Testing</a><br />

            <span class="text-success pull-left"> Controller location:&nbsp;</span>
           <? echo $controller_location; ?>
        </div>
    </div>
    <hr />
    <div class="row">
        <? echo $this->unit->report() ?>
    </div>
</div>