<?
if ( ! $this->session->userdata('account_level') >= 7)
    show_error('403: Forbidden', 'You are not allowed to this view this page.');
?>
<div class="container">
    <? echo $test; ?>
</div>