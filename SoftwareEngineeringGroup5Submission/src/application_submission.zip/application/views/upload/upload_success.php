
<div class="container body-content">
       <div class="alert alert-success">
        <p>Your file was successfully uploaded!</p>
    </div>
    <!-- Uploaded file specification will show up here -->
    <h4>Details</h4>
    <ul>
        <?php foreach ($upload_data as $item => $value):?>
            <li><?php echo $item;?>: <?php echo $value;?></li>
        <?php endforeach; ?>
    </ul>
    <p><?php echo anchor('upload_controller/file_view', 'Upload Another File!'); ?></p>
</div>
