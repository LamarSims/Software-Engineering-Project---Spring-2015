<div class="container body-content">
    <div class="row">
        <div class="col-xs-10 col-xs-offset-1">
            <div class="well">
                <div class="row">

                    <div class="col-xs-10 col-xs-offset-1">
                        <? if ($error != ' '): ?>
                        <div class="alert alert-danger">
                            <? echo $error; ?>
                        </div>
                        <? endif; ?>
                        <!-- Error Message will show up above -->
                        <?php echo form_open_multipart('upload/do_upload', array('class' => 'form-horizontal'));?>
                        <legend>File Upload</legend>
                        <div class="form-group">
                            <label for="userfile" class="col-lg-2 control-label">Choose a File</label>
                            <div class="col-lg-10">
                                <input type="file" class="form-control" name="userfile" size="20" />
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-lg-10 col-lg-offset-2">
                                <input type="submit" class="btn btn-info btn-border" name="submit" value="Upload">
                            </div>
                        </div>
                        <?php echo "</form>"?>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
