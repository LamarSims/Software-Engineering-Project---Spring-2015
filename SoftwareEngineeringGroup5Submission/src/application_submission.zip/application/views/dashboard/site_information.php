<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
    <h1 class="page-header">
        Site Information
        <small>
            Manage the content of pages.
        </small>
    </h1>
    <hr />
    <?php if ($errors = $this->session->flashdata('validation_errors')): ?>
        <div class="row">
            <div class="col-xs-12">
                <div class="alert alert-danger">
                    <?php echo $errors; ?>
                </div>
            </div>
        </div>
    <?php endif ?>
    <?php if ($success = $this->session->flashdata('success')): ?>
        <div class="row">
            <div class="col-xs-12">
                <div class="alert alert-success">
                    <?php echo $success; ?>
                </div>
            </div>
        </div>
    <?php  endif ?>
    <div class="row">
        <div class="col-xs-11 col-md-6">
            <div class="well">
                <form class="form-horizontal" method="post" action="<?php echo base_url(); ?>dashboard/site_information/submit_changes/about">
                    <fieldset>
                        <legend><em>About Us</em></legend>
                        <!-- JS HTML Text editor thanks to tinymce -->
                        <script type="text/javascript" src="<? echo base_url() ?>scripts/tinymce/js/tinymce/tinymce.min.js"></script>
                        <script type="text/javascript">
                            tinymce.init({
                                skin: "darkly",
                                selector: "textarea",
                                plugins: [
                                    "advlist autolink lists link image charmap print preview anchor",
                                    "searchreplace visualblocks code fullscreen",
                                    "insertdatetime media table contextmenu paste"
                                ],
                                toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
                            });
                        </script>
                        <br />
                        <div class="form-group">
                            <div class="col-lg-12">
                            <textarea rows="15" class="form-control" name="about_content_body" id="about_content_body" placeholder="Enter the main content for this page." autocomplete="off">
                                <? echo $dynamic_content_about->row()->content_body; ?>
                            </textarea>
                            </div>
                        </div>
                        <input type="hidden" value="content_id" name="content_id_hidden" id="content_id_hidden" />
                        <div class="form-group">
                            <div class="col-lg-10">
                                <input type="submit" class="btn btn-info btn-border" value="Submit Changes" />
                            </div>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
        <div class="col-xs-12 col-md-6">
            <div class="well">
                <form class="form-horizontal" method="post" action="<?php echo base_url(); ?>dashboard/site_information/submit_changes/contact">
                    <fieldset>
                        <legend><em>Contact Us</em></legend>
                        <!-- JS HTML Text editor thanks to tinymce -->
                        <script type="text/javascript" src="<? echo base_url() ?>scripts/tinymce/js/tinymce/tinymce.min.js"></script>
                        <script type="text/javascript">
                            tinymce.init({
                                skin: "darkly",
                                selector: "textarea",
                                plugins: [
                                    "advlist autolink lists link image charmap print preview anchor",
                                    "searchreplace visualblocks code fullscreen",
                                    "insertdatetime media table contextmenu paste"
                                ],
                                toolbar: "insertfile | styleselect | bold italic | bullist numlist | link image"
                            });
                        </script>
                        <br />
                        <div class="form-group">
                            <div class="col-xs-12">
                            <textarea rows="15" class="form-control" name="contact_content_body" id="contact_content_body" placeholder="Enter the main content for this page." autocomplete="off">
                                <? echo $dynamic_content_contact->row()->content_body; ?>
                            </textarea>
                            </div>
                        </div>
                        <input type="hidden" value="content_id" name="content_id_hidden" id="content_id_hidden" />
                        <div class="form-group">
                            <div class="col-lg-10">
                                <input type="submit" class="btn btn-info btn-border" value="Submit Changes" />
                            </div>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
</div>
