<div class="container body-content">
    <div class="row">
        <div class="col-xs-10 col-xs-offset-1">
            <div class="well">

            </div>
        </div>
    </div>
</div>
