<div class="col-sm-9 col-sm-offset-5 col-md-10 col-md-offset-2 main">

    <div class="container-fluid">

        <div class="row">
            <div class="col-xs-12">
                <h1>
                    Manage User Roles
                </h1>
                <hr />
            </div>
            <div class="col-xs-10 col-xs-offset-1">
                <p class="text-muted">
                    Here is where you may add roles to assign to various members of the club. These will displayed
                    next to their name on the members page and the administrative user management page.
                </p>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12">
                <? if ($errors = $this->session->flashdata('errors')): ?>
                    <div class="alert alert-dismissable alert-danger">
                        <? echo $errors ?>
                    </div>
                <? elseif ($warning = $this->session->flashdata('warning')): ?>
                    <div class="alert alert-dismissable alert-warning">
                        <? echo $warning ?>
                    </div>
                <? elseif ($success = $this->session->flashdata('success')): ?>
                    <div class="alert alert-dismissable alert-success">
                        <? echo $success ?>
                    </div>
                <? elseif ($info = $this->session->flashdata('info')): ?>
                    <div class="alert alert-dismissable alert-info">
                        <? echo $info ?>
                    </div>
                <? endif ?>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12 col-md-6">
                <div class="well">
                    <h3 class="text-center">Current Roles</h3>
                    <br />
                    <p>
                        Here are the current roles of the club.
                    </p>
                    <br />
                    <table class="table table-responsive table-striped table-bordered">
                        <tr>
                            <th>Role ID</th>
                            <th>Role Name</th>
                            <th>Description</th>
                        </tr>
                        <? foreach ($roles_table->result() as $role): ?>
                            <tr>
                                <td><? echo $role->role_id; ?></td>
                                <td><? echo $role->role_name; ?></td>
                                <td><? echo $role->role_description; ?></td>
                            </tr>
                        <? endforeach ?>
                    </table>
                </div>
            </div>

            <div class="col-xs-12 col-md-6 pull-right">
                <div class="well">
                    <h3 class="text-center">Add Role</h3>
                    <br />
                    <p>
                        You may add roles here. After which you may assign these roles to current members.
                    </p>
                    <br />
                    <form class="form-horizontal" method="post" action="<?php echo base_url(); ?>dashboard/roles/insert_role">
                        <fieldset>
                            <!--                        <legend>Add Role Form</legend>-->
                            <br />

                            <div class="form-group">
                                <label for="insert_role_name" class="col-xs-2 control-label">Role Name</label>
                                <div class="col-xs-8">
                                    <input type="text"
                                           class="form-control"
                                           name="insert_role_name"
                                           id="insert_role_name"
                                           placeholder="Enter the name of the role."
                                           autocomplete="off"
                                           value=""/>
                                </div>
                            </div>
                            <div class="form-group">

                                <label for="insert_role_description" class="col-xs-2 control-label">Role Description</label>
                                <div class="col-xs-8">
                                        <textarea rows="10"
                                                  class="form-control"
                                                  name="insert_role_description"
                                                  id="insert_role_description"
                                                  placeholder="Enter the description of the role."
                                                  autocomplete="off"></textarea>
                                </div>
                            </div>
                            <!--<input type="hidden" value="content_id" name="content_id_hidden" id="content_id_hidden" />-->
                            <div class="form-group">
                                <div class="col-xs-8 col-xs-offset-2">
                                    <input type="submit" class="btn btn-info btn-border" value="Submit" />
                                </div>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>

            <div class="col-xs-12 col-md-6">
                <div class="well">
                    <h3 class="text-center">Manage Roles of Current Members</h3>
                    <br />
                    <p>
                        You may view or modify current member's roles here.
                    </p>
                    <br />
                    <div style="max-height: 720px; overflow-y: scroll">
                        <table class="table table-responsive table-striped table-bordered">
                            <tr>
                                <th style="width: 25%">Username</th>
                                <th style="width: 25%">Current Role</th>
                                <th>New Role</th>
                            </tr>
                            <? foreach($members->result() as $member): ?>
                                <tr>
                                    <td><? echo $member->username ?></td>
                                    <td><? echo $roles[$member->role_id] ?></td>
                                    <td>
                                        <form class="form-horizontal"
                                              method="post"
                                              action="<? echo base_url(); ?>dashboard/users/update_user_role">
                                            <input type="hidden"
                                                   name="hidden_user_id"
                                                   value="<? echo $member->user_id ?>" />
                                            <div class="input-group">
                                                <div class="input-group-btn">
                                                    <input class="btn btn-info"
                                                           type="submit"
                                                           value="Set"
                                                           style="border: 1px solid white"/>
                                                </div>
                                                <? echo $role_select_list; ?>


                                            </div>


                                        </form>
                                    </td>
                                </tr>
                            <? endforeach ?>
                        </table>
                    </div>
                </div>
            </div>

        </div>

    </div>


</div>