<div class="ol-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
<div class="container body-content">
    <div class="row">
        <div class="col-xs-12">
            <h1 class="page-header">
                Tag Management
                <small>
                    Tags increase the usefulness of searches and help you organize elements.
                </small>
            </h1>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Existing Tags</h3>
                </div>
                <div class="panel-body">
                    <p>Click the tags for their descriptions.</p>
                    <? foreach ($tags->result() as $row): ?>
                        <!--<span style="font-size: 20px" class="label label-default"><? echo $row->tag_name; ?></span>-->
                        <button
                            style="font-size: 20px; font-weight: bold; border-radius: 10%; border: none"
                            class="btn btn-default btn-sm" data-toggle="modal"
                            data-target="#view_tag_modal"
                            data-tag-name="<? echo $row->tag_name; ?>"
                            data-tag-description="<? echo $row->description; ?>">
                                <span class="glyphicon glyphicon-tag"></span>
                                <? echo $row->tag_name; ?>
                        </button>
                    <? endforeach; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Insert Tag</h3>
                </div>
                <div class="panel-body">
                    <form class="form-horizontal" method="post" action="<?php echo base_url(); ?>dashboard/tags/insert_tag">
                        <fieldset>
                            <legend>Tag Creation</legend>
                            <br />
                            <?php if ($errors = $this->session->flashdata('validation_errors')): ?>
                                <div class="row">
                                    <div class="col-xs-12">
                                        <div class="alert alert-danger alert-dismissable">
                                            <?php echo $errors; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif ?>
                            <?php if ($success = $this->session->flashdata('success')): ?>
                                <div class="row">
                                    <div class="col-xs-12">
                                        <div class="alert alert-success alert-dismissable">
                                            <?php echo $success; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php  endif ?>
                            <div class="form-group">
                                <label for="insert_tag_name" class="col-xs-2 control-label">Tag Name</label>
                                <div class="col-xs-8">
                                    <input type="text"
                                           class="form-control"
                                           name="insert_tag_name"
                                           id="insert_tag_name"
                                           placeholder="Tag Name"
                                           autocomplete="off"
                                           value=""/>
                                </div>
                            </div>
                            <div class="form-group">

                                    <label for="insert_tag_description" class="col-xs-2 control-label">Tag Description</label>
                                    <div class="col-xs-8">
                                        <textarea rows="10"
                                                  class="form-control"
                                                  name="insert_tag_description"
                                                  id="insert_tag_description"
                                                  placeholder="Enter the description of the tag."
                                                  autocomplete="off"></textarea>
                                    </div>
                            </div>
                            <!--<input type="hidden" value="content_id" name="content_id_hidden" id="content_id_hidden" />-->
                            <div class="form-group">
                                <div class="col-xs-8 col-xs-offset-2">
                                    <input type="submit" class="btn btn-info btn-border" value="Submit" />
                                </div>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Get correct information in the modal. -->
<script>
    $(document).ready(function() {
        $('#view_tag_modal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget); // Button that triggered the modal
            var tagName = button.data('tag-name'); // Extract info from data-* attributes
            var tagDescription = button.data('tag-description');
            // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
            // Update the modal's content. We'll use jQuery here,
            // but you could use a data binding library or other methods instead.
            var modal = $(this);
            modal.find('#modal_tag_name').text('Description of ' + tagName);
            modal.find('#modal_tag_description').text(tagDescription);
        })
    });
</script>
<!-- Modal -->
<div class="modal fade" id="view_tag_modal" tabindex="-1" role="dialog" aria-labelledby="view_tag_label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title" id="modal_tag_name">
                </h4>
            </div>
            <div class="modal-body" id="modal_tag_description">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
    </div>