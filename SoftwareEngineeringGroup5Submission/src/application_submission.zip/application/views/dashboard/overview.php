<div class="col-sm-9 col-sm-offset-5 col-md-10 col-md-offset-2 main">
    <h1 class="page-header">
        Administrator Dashboard <?php echo  ' ('. $session['username'] . ')'; ?>

    </h1>
    <hr />

    <div class="row placeholders">

        <!--        <div class="col-xs-6 col-sm-2 placeholder col-sm-offset-1">-->
        <!--            <span class="glyphicon glyphicon-file" style="font-size: 100px"></span>-->
        <!--            <h4><a href="dashboard/reports">Reports</a></h4>-->
        <!--            <span class="text-muted">View statistics and reports</span>-->
        <!--        </div>-->
        <!--        <div class="col-xs-6 col-sm-2 placeholder" >-->
        <!--            <span class="glyphicon glyphicon-picture" style="font-size: 100px"></span>-->
        <!--            <h4><a href="dashboard/images">Images</a></h4>-->
        <!--            <span class="text-muted">Manage Images</span>-->
        <!--        </div>-->
        <div class="col-xs-12 col-sm-4 placeholder">
            <span class="glyphicon glyphicon-facetime-video" style="font-size: 100px"></span>
            <br />
            <h4><a class="btn btn-primary btn-lg" href="dashboard/videos">Videos</a></h4>
            <br />
            <span class="text-muted">Add videos to display to users on the Videos page.</span>
        </div>
        <div class="col-xs-12 col-sm-4 placeholder">
            <span class="glyphicon glyphicon-user" style="font-size: 100px"></span>
            <br />
            <h4><a class="btn btn-primary btn-lg" href="dashboard/manage_users">Manage Users</a></h4>
            <br />
            <span class="text-muted">Manage user accounts by promoting, demoting or suspending users.</span>
        </div>
        <div class="col-xs-12 col-sm-4 placeholder">
            <span class="glyphicon glyphicon-tags" style="font-size: 100px"></span>
            <br />
            <h4><a class="btn btn-primary btn-lg" href="dashboard/manage_tags">Manage Tags</a></h4>
            <br />
            <span class="text-muted">Manage content associations by creating tags. This helps with searching and categorization.</span>
        </div>

    </div>

    <h2 class="sub-header">
        Messages
        <small>
            View the latest suggestions and concerns.
        </small>
    </h2>
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>Subject</th>
                <th style="width: 50%">Message</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Date</th>
                <th>Delete</th>
            </tr>
            </thead>
            <tbody>
            <? foreach ($ordered_suggestions->result() as $row): // Loop through (ordered) suggestions records. ?>
                <tr>
                    <td><? echo $row->subject ?></td>
                    <td><? echo $row->body ?></td>
                    <td><? echo $row->contact_first_name ?></td>
                    <td><? echo $row->contact_last_name ?></td>
                    <td><? echo $row->contact_email ?></td>
                    <td><? echo $row->contact_phone ?></td>
                    <td><? echo $row->submitted ?></td>
                    <td>
                        <form action="<? echo base_url() ?>dashboard/delete/suggestion/<? echo $row->suggestion_id ?>" method="post">
                            <button class='btn btn-danger' type="submit" name="delete_suggestion" value="delete">Delete</button>
                        </form>
                    </td>
                </tr>
            <? endforeach; // Done looping through suggestions records. ?>
            </tbody>
        </table>
    </div>
</div>