<?php
/**
 * Must ensure user has appropriate privileges.
 */
if ( ! $this->data['session']['account_level'] >= 3)
{
    show_error('403: You are not authorized to view this page.');
}
?>

<style>
    /*
   * Base structure
   */

    /* Move down content because we have a fixed navbar that is 50px tall */
    body {
        /*padding-top: 50px;*/
    }


    /*
     * Global add-ons
     */

    .sub-header {
        padding-bottom: 10px;
        border-bottom: 1px solid #eee;
    }

    /*
     * Top navigation
     * Hide default border to remove 1px line.
     */
    .navbar-fixed-top {
        border: 0;
    }

    /*
     * Sidebar
     */

    /* Hide for mobile, show later */
    .sidebar {
        display: none;
    }
    @media (min-width: 768px) {
        .sidebar {
            position: fixed; /* orig: fixed */
            top: 51px;
            bottom: 0;
            left: 0;
            z-index: 1000;
            display: block; /* orig: block */
            padding: 50px;
            overflow-x: hidden;
            overflow-y: auto; /* Scrollable contents if viewport is shorter than content. */ /* orig: auto */
            background-color: #f5f5f5;
            background-color: #000000;
            /*border-right: 1px solid #eee;*/
        }
    }

    /* Sidebar navigation */
    .nav-sidebar {
        margin-right: -21px; /* 20px padding + 1px border */
        margin-bottom: 20px;
        margin-left: -20px;
        border: 1px solid gray;
        border-radius: 5px;
    }
    .nav-sidebar > li > a {
        padding-right: 20px;
        padding-left: 20px;
        color: #fff;
        background-color: #222;
        border: 1px solid gray;

    }
    .nav-sidebar > .active > a,
    .nav-sidebar > .active > a:hover,
    .nav-sidebar > .active > a:focus {
        color: #fff;
        background-color: #428bca;
    }


    /*
     * Main content
     */

    .main {
        padding: 20px;
    }
    @media (min-width: 768px) {
        .main {
            padding-right: 40px;
            padding-left: 40px;
        }
    }
    .main .page-header {
        margin-top: 0;
    }


    /*
     * Placeholder dashboard ideas
     */

    .placeholders {
        margin-bottom: 30px;
        text-align: center;
    }
    .placeholders h4 {
        margin-bottom: 0;
    }
    .placeholder {
        margin-bottom: 20px;
    }
    .placeholder img {
        display: inline-block;
        border-radius: 50%;
    }
    #codeigniter_profiler {
        background-color: #000000;
    }
</style>

<?php
$this->load->helper('inflector');
$title = humanize($title);
$url = base_url();
?>

<div class="container-fluid">
    <div class="row">
        <div style="" class="col-sm-3 col-md-2 sidebar">
            <ul class="nav nav-sidebar">
                <li <?php if ($title === 'Overview') echo ' class = "active" '; ?>>
                    <a href="<? echo $url ?>dashboard">
                        <span class="glyphicon glyphicon-dashboard"></span>
                        &nbsp;&nbsp;Overview
                        <span class="sr-only">(current)</span>
                    </a>
                </li>
                <!--                <li --><?php ////if ($title === 'Reports') echo ' class = "active" '; ?><!-->
                <!--                    <a href="--><?// echo $url ?><!--dashboard/reports">-->
                <!--                        <span class="glyphicon glyphicon-file"></span>-->
                <!--                        &nbsp;&nbsp;Reports-->
                <!--                    </a>-->
                <!--                </li>-->
                <li <?php if ($title === 'Videos') echo ' class = "active" '; ?>>
                    <a href="<? echo $url ?>dashboard/videos">
                        <span class="glyphicon glyphicon-film"></span>
                        &nbsp;&nbsp;Videos
                    </a>
                </li>
                <!--                <li --><?php //if ($title === 'Images') echo ' class = "active" '; ?><!-->
                <!--                    <a href="--><?// echo $url ?><!--dashboard/images">-->
                <!--                        <span class="glyphicon glyphicon-picture"></span>-->
                <!--                        &nbsp;&nbsp;Images-->
                <!--                    </a>-->
                <!--                </li>-->
                <!-- Using band-aid fix for page title names with underscores. Something to look at later. -->
                <li <?php if ($title == 'Manage Users') echo ' class = "active" '; ?>>
                    <a href="<? echo $url ?>dashboard/manage_users">
                        <span class="glyphicon glyphicon-user"></span>
                        &nbsp;&nbsp;Manage Users
                    </a>
                </li>
                <li <?php if ($title == 'Manage User Roles') echo ' class = "active" '; ?>>
                    <a href="<? echo $url ?>dashboard/manage_user_roles">
                        <span class="glyphicon glyphicon-list-alt"></span>
                        &nbsp;&nbsp;Manage User Roles
                    </a>
                </li>
                <li <?php if ($title === 'Custom Pages') echo ' class = "active"'; ?>>
                    <a href="<? echo $url ?>dashboard/custom_pages">
                        <span class="glyphicon glyphicon-bookmark"></span>
                        &nbsp;&nbsp;Custom Pages
                    </a>
                </li>
                <li <?php if ($title === 'Site Information') echo ' class = "active"'; ?>>
                    <a href="<? echo $url ?>dashboard/site_information">
                        <span class="glyphicon glyphicon-cog"></span>
                        &nbsp;&nbsp;Site Information
                    </a>
                </li>
                <li <?php if ($title === 'Manage Tags') echo ' class = "active"'; ?>>
                    <a href="<? echo $url ?>dashboard/manage_tags">
                        <span class="glyphicon glyphicon-tags"></span>
                        &nbsp;&nbsp;Manage Tags
                    </a>
                </li>
                <!--                <li --><?php //if ($title === 'Settings') echo ' class = "active"'; ?><!-->
                <!--                    <a href="--><?// echo $url ?><!--dashboard/settings">-->
                <!--                        <span class="glyphicon glyphicon-wrench"></span>-->
                <!--                        &nbsp;&nbsp;Settings-->
                <!--                    </a>-->
                <!--                </li>-->
            </ul>
        </div>