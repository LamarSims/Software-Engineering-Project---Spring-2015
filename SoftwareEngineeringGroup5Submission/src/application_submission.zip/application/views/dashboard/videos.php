<div class="ol-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <h1 class="page-header">
                Add Videos
                <small>Embed a YouTube Video to the site.</small>
            </h1>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Video Entry</h3>
                </div>
                <div class="panel-body">
                    <form class="form-horizontal" method="post" action="<?php echo base_url(); ?>dashboard/videos/insert_video">
                        <fieldset>
                            <legend>Video Information</legend>
                            <br />
                            <?php if ($errors = $this->session->flashdata('errors')): ?>
                                <div class="row">
                                    <div class="col-xs-12">
                                        <div class="alert alert-danger alert-dismissable">
                                            <?php echo $errors; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif ?>
                            <?php if ($success = $this->session->flashdata('success')): ?>
                                <div class="row">
                                    <div class="col-xs-12">
                                        <div class="alert alert-success alert-dismissable">
                                            <?php echo $success; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php  endif ?>
                            <div class="form-group">
                                <label for="insert_video_id" class="col-xs-2 control-label">
                                    <i style="font-size: 20px;"class="fa fa-youtube-play">&nbsp;</i>
                                    YouTube ID
                                </label>
                                <div class="col-xs-8">
                                    <input type="text"
                                           class="form-control"
                                           name="insert_video_id"
                                           id="insert_video_id"
                                           placeholder="The ID found in the URL of the YouTube video."
                                           autocomplete="off"
                                           value=""/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="insert_tag_name" class="col-xs-2 control-label">
                                    <span class="glyphicon glyphicon-tags">&nbsp;</span>
                                    Tags
                                </label>
                                <div class="col-xs-8">
                                    <div style="background-color: #222;" class="well well-sm">

                                        <div class="row">
                                            <div class="col-xs-12">
                                                <p>Select some tags to aid in searching and organizing elements.</p>
                                            </div>
                                            <? foreach($tags->result() as $row): ?>
                                                <div class="col-xs-3">
                                                    <div class="checkbox-inline"
                                                         style="margin-left: 5%; margin-right: 5%;">
                                                        <!--<label class="label label-default">
                                                            <input type="checkbox" />
                                                        </label>-->
                                                        <input type="checkbox"
                                                               name="checkbox_tags[]"
                                                               value="<? echo $row->tag_name ?>"/>
                                                        <span style="font-size: 16px; padding: 6px;"
                                                              class="badge">
                                                            <span class="glyphicon glyphicon-tag"></span>
                                                            <? echo $row->tag_name ?>
                                                        </span>

                                                    </div>
                                                </div>
                                            <? endforeach; ?>
                                            <div class="col-xs-12">
                                                <p></p>
                                                <p>
                                                    Don't see an appropriate tag?
                                                    <a href="<? echo base_url(); ?>dashboard/manage_tags">
                                                        Add tags here.
                                                    </a>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="insert_site_description" class="col-xs-2 control-label">Site Description</label>
                                <div class="col-xs-8">
                                        <textarea rows="10"
                                                  class="form-control"
                                                  name="insert_site_description"
                                                  id="insert_site_description"
                                                  placeholder="Enter a description of this video to display on this site."></textarea>
                                </div>
                            </div>
                            <input type="hidden"
                                   value="<? echo $this->session->userdata('user_id'); ?>"
                                   name="user_id_hidden"
                                   id="user_id_hidden" />
                            <div class="form-group">
                                <div class="col-xs-8 col-xs-offset-2">
                                    <input type="submit" class="btn btn-info btn-border" value="Submit" />
                                </div>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
</div>
    </div>