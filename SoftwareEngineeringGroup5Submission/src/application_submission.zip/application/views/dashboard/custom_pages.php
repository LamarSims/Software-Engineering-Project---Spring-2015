<div class="col-sm-10 col-sm-offset-2 col-md-10 col-md-offset-2">
    <? $this->view('templates/error_success_bar') ?>
</div>
<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
    <h1 class="page-header">
        Manage Custom Pages
    </h1>
    <hr />
    <div class="text-left">
        <a href="<? echo base_url()?>dashboard/custom_pages/create" class="btn btn-success">
            Create New Page
        </a>
    </div>
    <br />
    <div class="table-responsive">
        <table class="table table-striped table-hover table-bordered">
            <thead>
            <tr>
                <th>URL</th>
                <th>Title</th>
                <th>Author</th>
                <th>Last Modified</th>
                <th>Comments</th>
                <th>Manage</th>
            </tr>
            </thead>
            <tbody>
            <? foreach ($custom_pages_table->result() as $row): // Loop through (ordered) suggestions records. ?>
                <tr>
                    <td>
                        <a href="<? echo base_url() . 'custom/' . $row->page_id ?>">
                            <? echo base_url() . 'custom/' . $row->page_id ?>
                        </a>
                    </td>
                    <td><? echo $row->title ?></td>
                    <td><? echo $row->username ?></td>
                    <td><? echo $row->created ?></td>
                    <td><? echo $row->comments ?></td>
                    <td>
                        <form style="display: inline" action="<? echo base_url() ?>dashboard/custom_pages/edit/<? echo $row->page_id ?>" method="post">
                            <button class='btn btn-info btn-sm' type="submit" name="edit_custom_page" value="edit">Edit</button>
                        </form>
                        <!--<form style="display: inline" action="<? echo base_url() ?>dashboard/custom_pages/delete/<? echo $row->page_id ?>" method="post">
                            <button class='btn btn-danger btn-sm' type="submit" name="edit_custom_page" value="edit">Delete</button>
                        </form>-->
                        <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#delete_modal" data-page-id="<? echo $row->page_id; ?>">Delete</button>
                    </td>
                </tr>
            <? endforeach; // Done looping through suggestions records. ?>
            </tbody>
        </table>
    </div>
    <script>
        $(document).ready(function() {
            $('#delete_modal').on('show.bs.modal', function (event) {
                var button = $(event.relatedTarget) // Button that triggered the modal
                var pageId = button.data('page-id') // Extract info from data-* attributes
                // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
                // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
                var modal = $(this)
                modal.find('#hidden_page_id').val(pageId)
            })
        });
    </script>
    <div class="modal fade" id="delete_modal" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="modal_title">Delete Page</h4>
                </div>
                <div class="modal-body">
                    Are you sure you would like to delete this? This action cannot be undone.
                    <form class="form-horizontal" method="post" action="" id="modal_form">
                        <fieldset>
                            <input type="hidden" name="hidden_page_id" id="hidden_page_id" value="" />
                            <p></p>
                            <div class="form-group">
                                <div class="col-lg-12">
                                    <input type="submit" class="btn btn-danger" name="submit" id="submit" value="Yes, delete the page." onclick="return submitForm()" autocomplete="off">
                                    <button type="button" class="btn btn-info" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">No, do not delete.</span></button>
                                </div>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        /* Sends the form action to delete a custom page based on its ID number. */
        function submitForm() {
            /* For debugging var formUrl = $("#modal_form").attr("action"); */
            // Get the page ID number from the hidden_page_id input element.
            var pageId = $("#hidden_page_id").val();

            // Set the action for the confirmation form within the modal dialog.
            // Sends to the delete function within the custom page controller with the page ID.
            $("#modal_form").attr("action","<? echo base_url() ?>dashboard/custom_pages/delete/" + pageId);
            // Submit the form.
            $("#modal_form").submit();
        }
    </script>
</div>
