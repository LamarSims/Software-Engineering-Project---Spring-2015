<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
    <h1 class="page-header">
        User Management
    </h1>
    <hr />
    <div class="table-responsive">
        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Email</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Type</th>
                    <th>Joined</th>
                    <th>Suspend</th>
                </tr>
            </thead>
            <tbody>
            <? foreach ($users_table->result() as $row): // Loop through (ordered) suggestions records. ?>
                <tr>
                    <td><? echo $row->username ?></td>
                    <td><? echo $row->email ?></td>
                    <td><? echo $row->first_name ?></td>
                    <td><? echo $row->last_name ?></td>
                    <td><? echo $account_level[$row->user_id] ?></td>
                    <td><? echo $row->created ?></td>
                    <td>
                        <div class="btn-group">
                        <? if ($row->account_level < 7): ?>
                        <form style="display: inline" action="<? echo base_url() ?>dashboard/users/level/<? echo $row->user_id . '/' . (-1) ?>" method="post">
                            <button class='btn btn-danger btn-sm' type="submit" name="suspend_user" value="suspend">Suspend</button>
                        </form>
                        <form style="display: inline" action="<? echo base_url() ?>dashboard/users/level/<? echo $row->user_id . '/' . ($row->account_level - 1) ?>" method="post">
                            <button class='btn btn-warning btn-sm' type="submit" name="demote_user" value="demote">Demote</button>
                        </form>
                        <form style="display: inline" action="<? echo base_url() ?>dashboard/users/level/<? echo $row->user_id . '/' . ($row->account_level + 1) ?>" method="post">
                            <button class='btn btn-success btn-sm' type="submit" name="promote_user" value="promote">Promote</button>
                        </form>
                            </div>
                        <? endif ?>
                    </td>
                </tr>
            <? endforeach; // Done looping through suggestions records. ?>
            </tbody>
        </table>
    </div>
</div>