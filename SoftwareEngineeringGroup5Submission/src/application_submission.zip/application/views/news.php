<div class="container body-content">
	<h1>News</h1>
	<hr />
	<?php 
	foreach ($news_query as $row)
	{
		echo '<h3 style="font-weight: bolder">' . $row->title . '</h3>';
		echo '<p>' . nl2br($row->body) . '</p>';
		echo '<br />';
	}
	?>
	<hr />
	
	<div class="row">
		<div class="col-md-6 col-md-offset-3">
			<div class="well">
				<form class="form-horizontal" method="post" action="/se/test/index.php/news/insert">
					<legend>
						New Article
					</legend>
					<div class="form-group">
						<label class="col-md-2 control-label" for="article_title">Title </label>
						<div class="col-md-10">
							<input class="form-control" type="text" id="article_title" name="article_title" placeholder="Enter the title...">
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-2 control-label" for="article_title">Body </label>
						<div class="col-md-10">
							<textarea class="form-control" id="body" name="body" rows="10" placeholder="Type your article here..."></textarea>
						</div>
					</div>
					<div class="form-group">
						<div class="col-xs-12 col-xs-offset-10">
							<input class="btn btn-primary btn-border" type="submit" value="Post">
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>