<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There area two reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router what URI segments to use if those provided
| in the URL cannot be matched to a valid route.
|
*/

$route['default_controller'] = 'content/pages/view_page';

$route['profile'] = 'content/users_controller/view_profile';

$route['events'] = 'calendar/calendar_controller/load';
$route['events/(:num)/(:num)'] = 'calendar/calendar_controller/load/$1/$2';
$route['view_event/(:any)'] = 'calendar/calendar_controller/view_event/$1';

$route['blogs/view/(:any)'] = 'content/blogs_controller/article/$1';
$route['news/view/(:any)'] = 'content/news_article_controller/article/$1';
$route['news/view/all'] = 'content/news_article_controller/view';
$route['news/insert'] = 'content/news_article_controller/insert';
$route['submit_suggestion'] = 'content/suggestions_controller/submit_suggestion';
$route['register_user'] = 'login_system/register_controller/register_user';
$route['verify_login'] = 'login_system/verify_login/verify';
$route['verify_login/header'] = 'login_system/verify_login/verify/header';
$route['logout'] = 'login_system/verify_login/logout';

$route['dashboard/delete/suggestion/(:num)'] = 'admin/dashboard_controller/delete_suggestion/$1';
//$route['dashboard/users/suspend/(:num)'] = 'dashboard_controller/suspend_user/$1';
$route['dashboard/users/level/(:any)/(:any)'] = 'admin/dashboard_controller/adjust_user_account_level/$1/$2';

$route['dashboard/custom_pages/create'] = 'content/custom_page_controller/create';
$route['dashboard/custom_pages/submit_create'] = 'content/custom_page_controller/submit_create';
$route['dashboard/custom_pages/edit/(:any)'] = 'content/custom_page_controller/edit/$1';
$route['dashboard/custom_pages/submit_edit'] = 'content/custom_page_controller/submit_edit';
$route['dashboard/custom_pages/delete/(:any)'] ='content/custom_page_controller/submit_delete/$1';

$route['dashboard/site_information/submit_changes/(:any)'] = 'content/dynamic_content_controller/submit_changes/$1';

$route['dashboard/tags/insert_tag'] = 'content/tag_controller/insert_tag';

$route['dashboard/videos/insert_video'] = 'media/video_controller/insert_video';

$route['dashboard/roles/insert_role'] = 'admin/dashboard_controller/insert_role';

$route['dashboard/users/update_user_role'] = 'admin/dashboard_controller/update_user_role';

$route['upload/file'] = 'files/upload_controller/file_view';
$route['upload/do_upload'] = 'files/upload_controller/do_upload';
$route['user/do_upload'] = 'content/users_controller/do_upload';
$route['user/delete_image'] = 'content/users_controller/delete_user_profile_image';

$route['dashboard'] = 'admin/dashboard_controller/load';
$route['dashboard/(:any)'] = 'admin/dashboard_controller/load/$1';

$route['custom/(:any)'] = 'content/custom_page_controller/load/$1';

$route['discussion/load/(:any)'] = 'content/discussion_controller/load/$1';
$route['discussion/(:any)'] = 'content/discussion_controller/load/$1';
$route['discussion/new_topic'] = 'content/discussion_controller/new_topic';
$route['discussion/new_reply'] = 'content/discussion_controller/new_reply';

$route['ControllerTest'] = 'developer/ControllerTest';

$route['dev/view/(:any)'] = 'developer/developer_controller/view/$1';

$route['search'] = 'search/Search_controller/by_keyword';

$route['unit_test_driver/(:any)'] = 'developer/Unit_test_driver/$1';

$route['(:any)'] = 'content/pages/view_page/$1';
$route['test'] = 'content/pages/view_page/landing';
$route['submit_event'] = 'calendar/calendar_controller/submit_event';
$route['delete_event'] = 'calendar/calendar_controller/delete_event';




//$route['news'] = 'news_article_controller/view';
//$route['news/insert'] = 'news_article_controller/insert';
//$route['login_system/verify'] = 'login_system/verify';
//$route['login_system'] = 'pages/view/login_system';
//$route['register/register_user'] = 'register_controller/register_user';
//$route['site'] = 'pages/view/videos';


/* End of file routes.php */
/* Location: ./application/config/routes.php */