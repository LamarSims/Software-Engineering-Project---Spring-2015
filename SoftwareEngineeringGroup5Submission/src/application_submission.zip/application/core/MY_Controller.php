<?php

/**
 * Class MY_Controller
 * Includes all of the base functionality required of the site.
 */
class MY_Controller extends CI_Controller
{

    /**
     * A global array to be accessed by all successor controllers and views.
     * Views access this data using the association as the variable name:
     * i.e. data['some_variable'] (controller) -> $some_variable (within a view)
     * @var array Data to be accessed by all controllers and views.
     */
	public $data = array();

    /**
     * Default class constructor for this and all successor controllers.
     */
	function __construct()
	{
		parent::__construct();
        $this->load->library('session');
		// $this->initialize_session(); Does not work properly. Doing the functionality directly for now.

        // Is there a current session?
        if ( ! $this->session_exists())
        {
            $session_data = array(
                'exists' => TRUE,
                //'theme' => '', // For future use?
                'landing_page' => TRUE, // Don't repeatedly show landing page.
                'logged_in' => FALSE,
                'user_id' => '',
                'username' => '',
                'email' => '',
                'password' => '',
                'account_level' => ''
            );
            $this->session->set_userdata($session_data);
        }
        $this->data['session'] = $this->session->all_userdata();

        $this->data['is_logged_in'] = $this->is_logged_in();
       // $this->data['session'] = $this->session->all_userdata();
        if ($this->check_account_level(4))
        {
            $this->output->enable_profiler(TRUE);
        }

	}
	
	/**
     * Initializes the session if it hasn't been already.
     * (Not currently in use.)
     */
	function initialize_session()
	{
        // Is there a current session?
        if ( ! $this->session_exists())
        {
            die('hello'); // Debug.
            $session_data = array(
                'exists' => TRUE,
                'theme' => 'flatly',
                'landing_page' => TRUE, // Don't repeatedly show landing page.
                'logged_in' => FALSE,
                'user_id' => '',
                'username' => '',
                'email' => '',
                'password' => '',
                'account_level' => ''
            );
            $this->session->set_userdata($session_data);
        }
        $this->data['session'] = $this->session->all_userdata();
	}

    /**
     * @return bool If a session is already exists.
     */
    public function session_exists()
    {
        return $this->session->userdata('exists');
    }

    /**
     * @return bool A session is currently logged in.
     */
	public function is_logged_in()
	{
		return ($this->session->userdata('logged_in') !== FALSE);
	}

    /**
     * Navigates to a view within the "views" directory.
     * @param string $page Default page.
     * @param int $blogs_page Indicates the blog page number for the home page blog pager.
     */
    public function view_page($page = 'landing', $blogs_page = 1)
    {
        // Is the current page the landing page AND the session's landing_page value TRUE?
        // The landing page does not follow the page template.
        // If the session variable "landing_page" is set to false, then the default page becomes the home page.
        if ($page == 'landing' && $this->data['session']['landing_page'])
        {
            $this->load_view('templates/' . $page, 'landing');
            $this->session->set_userdata('landing_page', FALSE); // Load landing page only once per session.
            return;
        }
        else if ($page == 'landing' && ! $this->session->userdata('landing_page'))
        {
           $page = 'home';
        }

        // Send to 404 page if the file doesn't exist.
        if ( ! file_exists(APPPATH.'/views/pages/'.$page.'.php'))
        {
            show_404();
        }

        // Sets the title of the page.
        $this->data['title'] = ucfirst($page); // Capitalize the first letter

        // Load blog query into home page.
        if ($page == 'home')
        {
            // Set offset for query based on 3 articles per page.
            // Page 1 = article1, article2, article3 => Page 2 = article4, article5, article6, etc...
            $offset = ($blogs_page - 1) * 3;

            $this->load->model('blogs');
            $this->data['current_blogs_page'] = $blogs_page;
            $this->data['blog_query'] = $this->blogs->get(3, $offset);

            $this->load->model('custom_pages');
            $this->data['current_record_page'] = $blogs_page;
            $this->data['custom_page_query'] = $this->custom_pages->get_latest(3, $offset);

            $this->data['num_rows'] = $this->blogs->count();
            $this->data['num_rows'] = $this->custom_pages->count();
        }

        if ($page == 'blogs')
        {
            $this->load->model('blogs');
            $this->data['blog_title'] = $this->blogs->get_by_id(1)->title;
            $this->data['blog_body'] = $this->blogs->get_by_id(1)->body;
        }

        // Data for the About Us and Contact Pages.
        // Administrator is allowed to edit content on these pages.
        if ($page == 'about' || $page == 'contact')
        {
            $this->load->model('dynamic_content');
            $this->data['content_body'] = $this->dynamic_content->get_by_id($page)->row()->content_body;
        }

        // Data for the members page.
        if ($page == 'members')
        {
            $this->load->model('user');
            $this->load->model('roles');
            for ($i = 0; $i <= 7; $i++)
            {
                $this->data['account_type'][$i] = $this->user->get_title($i);
            }
            $this->data['role_name'][0] = '';
            foreach ($roles = $this->roles->get_all()->result() as $role)
            {
                $this->data['role_name'][$role->role_id] = $role->role_name;
            }

            $this->data['film_club_members'] = $this->user->get_by_account_level(1); // Level 1+ are members.
        }

        if ($page == 'pictures'){
            $this->load->model('images');
            $this->data['pictures'] = $this->images->get_all_nonuser_images();
        }

        if ($page == 'profile'){
            $this->load->model('user');
            $this->data['profile'] = $this->user->get_user_image($this->session->userdata('user_id'));
        }

        if ($page == 'site_pages')
        {
            $this->load->model('custom_pages');
            $this->data['custom_pages_table'] = $this->custom_pages->get();
        }

        if ($page == 'videos')
        {
            $this->load->model('videos');
            $this->load->model('videos_tags');
            $this->data['videos'] = $this->videos->get(100, 0);
            foreach ($this->data['videos']->result() as $video)
            {
                $this->data['videos_tags'][$video->video_id] = $this->videos_tags->get_by_video($video->video_id);
            }

        }

        // Load the template.
        //$this->load->view('templates/header', $this->data);
        //$this->load->view('pages/'.$page, $this->data);
        //$this->load->view('templates/footer', $this->data);

        $this->load_template($page);
    }

    /**
     * Load view at given directory and title.
     * @param string $path The directory the "view".php file is located.
     * @param string $title The title for the view page.
     */
    public function load_view($path, $title = '')
    {
        $this->data['title'] = ucfirst($title);
        $this->load->view($path, $this->data);
    }

    /**
     * @param $page The "view".php file within the /views/pages directory to sandwich between
     *              the header and footer.
     */
    public function load_template($page)
    {
        $this->load->view('templates/header', $this->data);
        $this->load->view('pages/' . $page, $this->data);
        $this->load->view('templates/footer', $this->data);
    }

    /**
     * Checks the session if the session account level is at least as high as the passed account level.
     * @param $account_level , The account level to check for.
     * @return bool , Is the session account level at least as high as the passed account level?
     */
    public function check_account_level($account_level)
    {
        if ($this->session->userdata('account_level') == FALSE)
        {
            return FALSE;
        }
        return $this->session->userdata('account_level') >= $account_level;
    }

    /**
     * Uses the HTMLPurifier framework to clean HTML code of XSS techniques. Excludes YouTube iframe elements.
     * @param $html The HTML code to clean.
     * @return string The cleaned string of HTML code.
     */
    public function clean_html($html) /* Utilized by many child controllers so we put it here. */
    {
        $config = HTMLPurifier_Config::createDefault();
        $config->set('HTML.Trusted', true);
        $config->set('Filter.YouTube', true);
        $purifier = new HTMLPurifier($config);
        return $purifier->purify($html);
    }
    
    public function pagination($number_of_rows, $results_per_page, $current_page)
    {
    	$this->data['pagination'] = array();
    	$this->data['pagination']['total_pages'] = ceil($number_of_rows / $results_per_page);
    	$this->data['pagination']['current_page'] = $current_page; 
    	$this->data['pagination']['results_per_page'] = $results_per_page;
    }

    public function is_unit_test_active()
    {
        return $this->session->userdata('unit_test_active');
    }
	
}

interface Searchable {

    public function search($keyword);

}

interface Unit_testable {

    public function test();

}

?>