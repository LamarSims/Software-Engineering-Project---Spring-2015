<?php
/**
 * Created by PhpStorm.
 * User: Chad
 * Date: 4/16/2015
 * Time: 8:33 AM
 */

interface Searchable {

    public function search($keyword);

}