<?php

/**
 * Class Video_controller
 *
 * Responsible for directing the requests to insert and view YouTube videos.
 *
 * @package media
 */
class Video_controller extends MY_Controller
{

    /**
     * Default no-arg constructor for this controller.
     */
    public function __construct()
    {
        parent::__construct();
        if (!$this->check_account_level(1)) // Does the account have privileges?
        {
            $error_message = '403 Forbidden: You are not authorized to view this page' .
                             '<div class="text-center">' .
                             '<a href="' . base_url() . 'login" class="btn btn-info">Officer Sign In</a>' .
                             '</div>';
            show_error($error_message);
        }
        $this->load->model('videos');
        $this->load->model('videos_tags');
        $this->load->library('form_validation');
    }

    /**
     * Validates user input and on success inserts a new video record into the database. On failure the
     * user is greeted with an error message.
     */
    public function insert_video()
    {
        /* Validate the form. */
        $this->form_validation->set_rules('insert_video_id', 'YouTube ID', 'trim|required|xss_clean');
        $this->form_validation->set_rules('insert_site_description', 'Site Description', 'trim|required|xss_clean');

        if (!$this->form_validation->run())
        { // If form validation fails, send back to page with errors.
            $this->data['title'] = 'Videos';
            $this->session->set_flashdata('errors', validation_errors());
            redirect('dashboard/videos');
        }

        $video_id         = $this->input->post('insert_video_id');
        $user_id          = $this->input->post('user_id_hidden');
        $site_description = $this->input->post('insert_site_description');

        // Insert data will be passed to videos model as array.
        $video_insert_data = array(
            'video_id'         => $video_id,
            'user_id'          => $user_id,
            'site_description' => $site_description
        );

        // Insert video record.
        $this->videos->insert($video_insert_data);

        // For each checked checkbox, insert a videos_tags record.
        foreach ($this->input->post('checkbox_tags') as $checkbox)
        {
            $this->videos_tags->insert(array('video_id' => $video_id, 'tag_name' => $checkbox));
        }

        $this->session->set_flashdata('success', 'You have successfully added the video!');
        redirect('dashboard/videos');
    }


}