<?php

/**
 * Class Search_controller
 * Responsible for directing user input from the footer search bar to the appropriate
 * searchable models and directing the results to a search results view page.
 * @package search
 *
 */
class Search_controller extends MY_Controller
{

    public function __construct() {
        parent::__construct();
        $this->load->helper('inflector');
    }

    /**
     * Takes the user's input from the footer search bar and queries the searchable models
     * for records containing matching strings.
     * @param int $page_number The page sequence number for the search results.
     * @param int $results_per_page The number of records to show per page.
     */
    public function by_keyword($page_number = 1, $results_per_page = 20)
    {
        $keywords = $this->_filtered_input();

        $db_results = array(
            'videos' => $this->_search_videos($keywords),
            'custom_pages' => $this->_search_custom_pages($keywords)
        );

        $this->data['html_result_tables'] = $this->_generate_result_tables($db_results);

        $this->data['title'] = 'Search for: ' . $keywords;
        $this->load->view('templates/header', $this->data);
        $this->load->view('pages/search', $this->data);
        $this->load->view('templates/footer', $this->data);
    }

    /**
     * Generates the HTML markup for the results tables.
     * @param array $results The models to query against.
     * @return string The HTML table markup for the search results.
     */
    private function _generate_result_tables($results = array('videos'))
    {


        $result_view = ''; // The resulting HTML tables to show in the view. Pass as $this->data['result_view'].
        foreach ($results as $key => $value) { // For every "thing" to search within the results array.
            $result_view .= '<h3>' . humanize($key) . '</h3>';
            $result_view .= '<hr />';
            $result_view .= '<table class="table table-striped table-bordered">';
            $count = 0;
            if ( $value->num_rows == 0)
            {
                $result_view .= '<p><em>No results</em></p>';
                //continue;
            }
            foreach ($value->result() as $field) // For each row in current query.
            {
                $result_view .= '<tr>';
                if ($count++ == 0) // Print out table headers
                {
                    $result_view .= '<th>';
                    $result_view .= 'Name/ID';
                    $result_view .= '</th>';
                    $result_view .= '<th>';
                    $result_view .= 'Details';
                    $result_view .= '</th>';
                    $result_view .= '</tr>';
                }
                $result_view .= '<td>'; // Start first table cell
                $result_view .= $field->name_or_id;
                $result_view .= '</td>'; // End first table cell
                $result_view .= '<td>'; // Start second table cell
                $result_view .= $field->details;
                $result_view .= '</td>'; // End second table cell
                $result_view .= '</tr>';
            }
            $result_view .= '</table>';
        }
        return $result_view;
    }

    /**
     * Signal the model to query the database for matching video results.
     * @param $keywords String The string to run a search with for matching database records.
     * @return mixed The search results for result count > 0. For row count == 0 returns false.
     */
    private function _search_videos($keywords)
    {
        $this->load->model('videos');
        return $this->videos->search($keywords);
    }

    /**
     * Signal the model to query the database for matching video results.
     * @param $keywords String The string to run a search with for matching database records.
     * @return mixed The search results for result count > 0. For row count == 0 returns false.
     */
    private function _search_custom_pages($keywords)
    {
        $this->load->model('custom_pages');
        return $this->custom_pages->search($keywords);
    }


    /**
     * Filters the search bar input for XSS.
     * @return string The filtered HTML mark-up.
     */
    private function _filtered_input()
    {
        return $this->clean_html($this->input->post('search_bar_footer'));
    }

}