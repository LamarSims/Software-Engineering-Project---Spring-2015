<?php
/**
 * Created by PhpStorm.
 * User: Chad
 * Date: 3/20/2015
 * Time: 1:35 PM
 */
class discussion_controller extends MY_Controller
{

    /**
     * Class constructor for this controller.
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('discussion_topics');
        $this->load->model('discussion_replies');
        $this->load->library('form_validation');
    }

    /**
     * Loads the discussion on the page of specified page number and results per page.
     * @param int $page_number The page number of the discussion.
     * @param int $results_per_page The number of results to show per page.
     */
    public function load($page_number = 1, $results_per_page = 20)
    {

        if ($per_page_selection = $this->input->post('results_per_page_selection'))
        {
            $results_per_page =  $per_page_selection;
        }

        $DISCUSSION_BOARD_ID = 1;
        $RESULTS_PER_PAGE = $results_per_page;
        $this->data['topics'] =
            $this->discussion_topics->
            get_by_discussion_board_by_page($DISCUSSION_BOARD_ID, $page_number, $RESULTS_PER_PAGE)->result();
        if ( empty($this->data['topics'])) // Are they any results for the requested page number?
        {
            $this->session->set_flashdata('errors', 'There are no results for that page.');
            redirect('discussion/load/1');
        }
        foreach ($this->data['topics'] as $row)
        {
            $discussion_topic_id = $row->discussion_topic_id;
            $this->data['replies'][$discussion_topic_id] =
                $this->discussion_replies->get_replies_by_discussion_topic_id($discussion_topic_id);
        }

        if ( isset($discussion_topic_id)) // Are there any discussion topics?
        {
            // Defined earlier $RESULTS_PER_PAGE = 20;
            $NUMBER_OF_ROWS = $this->discussion_topics->get_by_discussion_board($DISCUSSION_BOARD_ID)->num_rows();
            $CURRENT_PAGE = $page_number;
            $this->pagination($NUMBER_OF_ROWS, $RESULTS_PER_PAGE, $CURRENT_PAGE);
        }


        $this->view_page('discussion');
    }

    /**
     * Stores a new topic to the database from the New Topic form.
     * @throws PHPUnit_Framework_Exception
     */
    public function new_topic()
    {
        if ( ! $this->check_account_level(0))
        {
            $error_message = 'Error 403: You must be logged in to do that.' .
                '<p><a href="' . base_url() . 'login_system" class="btn btn-info">Sign In</a></p>';
            show_error($error_message);
        }
        /* Validate the form. */
        $this->form_validation->set_rules('discussion_topic', 'Title', 'trim|required|xss_clean');
        // Will use HTMLPurifier to filter xss later.
        $this->form_validation->set_rules('discussion_body', 'Message', 'trim|required');

        if ($this->form_validation->run() == FALSE)
        { // If form validation fails, send back to suggestion page with errors.
            $this->data['title'] = 'Discussions';
            $this->session->set_flashdata('errors', validation_errors());
            redirect($this->input->post('page_route_hidden'));
            //redirect('discussion/load/1');
        }
        else // Form validation successful.
        {
            // Gather data from post variables.
            $title = $this->input->post('discussion_topic');
            $body = $this->input->post('discussion_body');
            $user_id = $this->input->post('user_id_hidden');
            $discussion_board_id = $this->input->post('discussion_board_id_hidden');

            // Clean up body content using HTMLPurifier defined in MY_Controller.
            // This will allow iframe youtube elements to appear and store correctly.
            $body = $this->clean_html($body);


            // Insert into DB.
            $this->discussion_topics->insert(
                $title,
                $body,
                $user_id,
                $discussion_board_id // Main discussion_board_id = 1.
            );

            // Redirect user to suggestions page with success message.
            $this->data['title'] = 'Discussion';
            $this->session->set_flashdata(
                'success',
                'Your topic was successfully posted!'
            );
            redirect($this->input->post('page_route_hidden'));
        }
    }

    /**
     * Stores a new topic to the database from a New Topic form.
     * @throws PHPUnit_Framework_Exception
     */
    public function new_reply()
    {
        if ( ! $this->check_account_level(0))
        {
            $error_message = 'Error 403: You must be logged in to do that.' .
                             '<p><a href="' . base_url() . 'login_system" class="btn btn-info">Sign In</a></p>';
            show_error($error_message);
        }

        /* Validate the message body. Will be cleaned up for XSS later. */
        $this->form_validation->set_rules('reply_body', 'Message', 'trim|required');

        if ($this->form_validation->run() == FALSE)
        { // If form validation fails, send back to suggestion page with errors.
            $this->data['title'] = 'Discussions';
            $this->session->set_flashdata('errors', validation_errors());
            redirect($this->input->post('page_route_hidden'));
            //redirect('discussion/load/1');
        }
        else // Form validation successful.
        {
            // Gather data from post variables.
            $discussion_topic_id = $this->input->post('hidden_discussion_topic_id');
            $reply_body = $this->input->post('reply_body');
            $user_id = $this->input->post('hidden_user_id');

            // Clean up body content using HTMLPurifier defined in MY_Controller.
            // This will allow iframe youtube elements to appear and store correctly.
            $reply_body = $this->clean_html($reply_body);


            // Insert into DB.
            $this->discussion_replies->insert(
                $user_id,
                $discussion_topic_id,
                $reply_body
            );

            // Redirect user to suggestions page with success message.
            $this->data['title'] = 'Discussion';
            $this->session->set_flashdata(
                'success',
                'Your reply was successfully posted!'
            );
            redirect($this->input->post('page_route_hidden'));
        }

    }



}