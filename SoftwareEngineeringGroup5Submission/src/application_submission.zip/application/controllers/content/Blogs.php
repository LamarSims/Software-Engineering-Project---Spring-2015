<?php

/**
 * Class blogs
 * @deprecated Replaced with Custom Pages
 */
class blogs extends MY_Controller
{

    function __construct() {
        parent::__construct();
    }

    function view()
    {
        $this->load->model('blogs');
        $this->data['news_query'] = $this->blogs->get();
        $this->data['title'] = 'News';
        $this->load->view('templates/header', $this->data);
        $this->load->view('news', $this->data);
        $this->load->view('templates/footer', $this->data);
    }

    function insert()
    {

        $title = $this->input->post('article_title');
        $body = $this->input->post('body');

        $news = array(
            'title' => $title,
            'body' => $body
        );

        $this->load->model('blogs');
        $this->blogs->insert($news['title'], $news['body']);

        $this->view();
    }

    function article($blog_id)
    {
        $this->load->model('blogs');

        if ($this->data['article'] = $this->blogs->get_by_id($blog_id))
        {
            $this->data['title'] = $this->data['article']->title;
            $this->load->view('templates/header', $this->data);
            $this->load->view('blogs/view_blog', $this->data);
            $this->load->view('templates/footer', $this->data);
        }
        else
        {
            show_404();
        }
    }
}