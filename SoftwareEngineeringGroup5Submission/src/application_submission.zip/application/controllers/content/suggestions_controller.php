<?php
/**
 * Created by PhpStorm.
 * User: chad
 * Date: 2/11/15
 * Time: 9:08 AM
 */

class suggestions_controller extends MY_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->model('suggestions');
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->library('security');
    }

    function submit_suggestion()
    {
        // Validate the form. The password will be checked through the check_password() function.
        $this->form_validation->set_rules('first_name', 'First Name', 'trim|required|xss_clean');
        $this->form_validation->set_rules('last_name', 'Last Name', 'trim|required|xss_clean');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|xss_clean|valid_email');
        $this->form_validation->set_rules('phone', 'Phone', 'trim|required|xss_clean');
        $this->form_validation->set_rules('subject', 'Subject', 'trim|required|xss_clean');
        $this->form_validation->set_rules('body', 'Message', 'trim|required|xss_clean');

        if ($this->form_validation->run() == FALSE)
        { // If form validation fails, send back to suggestion page with errors.
            $this->data['title'] = 'Suggestions';

            $this->session->set_flashdata('validation_errors', validation_errors());
            redirect('suggestions');
        }
        else // Form validation successful.
        {
            // Gather data from post variables.
            $contact_first_name = $this->input->post('first_name');
            $contact_last_name = $this->input->post('last_name');
            $contact_email = $this->input->post('email');
            $contact_phone = $this->input->post('phone');
            $subject = $this->input->post('subject');
            $body = $this->input->post('body');

            // Insert into DB.
            $this->suggestions->insert(
                $contact_first_name,
                $contact_last_name,
                $contact_email,
                $contact_phone,
                $subject,
                $body
            );

            // Redirect user to suggestions page with success message.
            $this->data['title'] = 'Suggestions';
            $this->session->set_flashdata('success', 'Thank you! Your suggestion was successfully submitted. We may contact you soon.');
            redirect('suggestions');
        }
    }

}