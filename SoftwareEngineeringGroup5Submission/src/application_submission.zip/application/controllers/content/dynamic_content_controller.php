<?php
/**
 * Created by PhpStorm.
 * User: Chad Golden
 * Date: 3/17/2015
 * Time: 12:57 PM
 */
class Dynamic_content_controller extends MY_Controller
{

    /**
     * Class constructor for this controller.
     */
    function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('dynamic_content');
    }

    /**
     * Submit changes of a dynamic content record of a specified content_id.
     * @param $content_id The ID for the content record.
     */
    function submit_changes($content_id)
    {
        // Validate the form.
        $this->form_validation->set_rules($content_id . '_content_body', 'Body', 'required');

        if ($this->form_validation->run() == FALSE)
        { // If form validation fails, send back to suggestion page with errors.
            $this->data['title'] = 'Site Information';

            $this->session->set_flashdata('validation_errors', validation_errors());
            redirect('dashboard/site_information');
        }
        else // Form validation successful.
        {
            // Gather data from post variables.
            $content_body = $this->input->post($content_id . '_content_body');

            // Clean up body content using HTMLPurifier defined in MY_Controller.
            // This will allow iframe youtube elements to appear and store correctly.
            $content_body = $this->clean_html($content_body);

            // Insert into DB.
            $this->dynamic_content->update(
                $content_id,
                $content_body
            );

            // Redirect user to suggestions page with success message.
            $this->data['title'] = 'Edit Success';
            $this->session->set_flashdata(
                'success',
                '<h4>Your page was successfully modified!</h4><div class="text-center">' .
                '<a href="'. base_url() . 'dashboard/site_information" class="btn btn-info">' .
                'Return to the dashboard</a></div>'
            );
            redirect('dashboard/site_information');
        }
    }


}