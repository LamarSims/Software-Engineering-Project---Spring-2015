<?php

/**
 * Class Pages
 * This class handles most of the operations of loading pages on the system.
 */
class Pages extends MY_Controller {

    /**
     * Class constructor for this controller.
     */
	function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form'));
	}

    /**
     * View a page.
     * @param string $page The name of the page to load from the views/pages/ directory.
     * @param int $blogs_page Current page number of the blogs display on the home page.
     * @throws PHPUnit_Framework_Exception
     */
	public function view($page = 'landing', $blogs_page = 1)
	{
		
		// Session data...
		//$data['session'] = $this->session->all_userdata();
		
// 		// Sends if the user is logged in to all pages as part of the $data array.
// 		if ($data['is_logged_in'] = $this->is_logged_in())
// 		{
// 			// If the user is logged in, then send the session data to all pages through $data[]
// 			$data['session'] = $this->session->all_userdata();
// 		}
		
		// The landing page does not follow the page template.
		if ($page == 'landing')
		{
			$this->data['title'] = ucfirst($page); // Capitalize the first letter
			$this->load->view('templates/landing', $this->data);
			return;
		}
		
		if ($page == 'unittesting')
		{
			$this->load->library('unit_test');
			$test = 1 + 2;
			$expected_result = 2;
			$test_name = 'Adds one plus one.';
			$this->data['unit_test'] = $this->unit->run($test, $expected_result, $test_name);
		}


		
		if ( ! file_exists(APPPATH.'/views/pages/'.$page.'.php'))
		{
			// Page not found
			show_404();
		}
		
		// Sets the title of the page.
		$this->data['title'] = ucfirst($page); // Capitalize the first letter
		
		// Load news query into home page.
		if ($page == 'home')
		{
			// Set offset for query based on 3 articles per page.
			// Page 1 = article1, article2, article3 => Page 2 = article4, article5, article6, etc...
			$offset = ($blogs_page - 1) * 3;
			$this->load->model('blogs');
			$this->data['current_blogs_page'] = $blogs_page;
			$this->data['blog_query'] = $this->blogs->get(3, $offset);
			$this->data['num_rows'] = $this->blogs->count();
		}

		if ($page == 'blogs')
		{
			$this->load->model('blogs');
			$this->data['blog_title'] = $this->blogs->get_by_id(1)->title;
			$this->data['blog_body'] = $this->blogs->get_by_id(1)->body;
		}

		//
		
		// Load the template.
		$this->load->view('templates/header', $this->data);
		$this->load->view('pages/'.$page, $this->data);
		$this->load->view('templates/footer', $this->data);
	}

    /**
     * Shows an error message.
     * @param string $page The name of the page.
     * @param $error_header A title for the error header.
     * @param $error_message A message for the error message.
     */
	public function error($page = 'error', $error_header, $error_message)
	{
		$this->data['title'] = 'Error';
		$this->data['error_header'] = $error_header;
		$this->data['error_message'] = $error_message;
		$this->load->view('templates/header', $this->data);
		$this->load->view('pages/'.$page, $this->data);
		$this->load->view('templates/footer', $this->data);
	}

    /**
     * Initializes the user's session if one doesn't already exist.
     */
	public function initialize_session()
	{
		if (!isset($this->session->all_userdata()['logged_in'])) // If there is no session
		{
			$session_data = array(
					'logged_in' => FALSE,
					'user_id' => '',
					'username' => '',
					'email' => '',
					'password' =>''
			);
				
			$this->session->set_userdata($session_data);
		}
	}
	
}