<?php
/**
 * Created by PhpStorm.
 * User: Chad
 * Date: 4/4/2015
 * Time: 8:19 AM
 */

class Tag_controller extends MY_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('tags');
        $this->load->library('form_validation');
    }

    public function insert_tag()
    {
        // Validate the form.
        $this->form_validation->set_rules('insert_tag_name', 'Tag Name', 'trim|required|xss_clean');
        $this->form_validation->set_rules('insert_tag_description', 'Tag Description', 'trim|required|xss_clean');

        if ($this->form_validation->run() == FALSE)
        { // If form validation fails, send back to suggestion page with errors.
            $this->data['title'] = 'Manage Tags';

            $this->session->set_flashdata('validation_errors', validation_errors());
            redirect('dashboard/manage_tags');
        }
        else // Form validation successful.
        {
            // Gather data from post variables.
            $tag_name = $this->input->post('insert_tag_name');
            $tag_description = $this->input->post('insert_tag_description');

            // Insert into DB.
            $this->tags->insert(
                $tag_name,
                $tag_description
            );

            // Redirect user to suggestions page with success message.
            $this->data['title'] = 'Manage Tags';
            $this->session->set_flashdata('success', 'You successfully added a tag!');
            redirect('dashboard/manage_tags');
        }
    }

}