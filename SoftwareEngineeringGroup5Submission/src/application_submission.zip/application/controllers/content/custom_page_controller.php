<?php
/**
 * Created by PhpStorm.
 * User: Chad
 * Date: 3/6/2015
 * Time: 5:25 PM
 */
class Custom_page_controller extends MY_Controller {

    /**
     * Class constructor for this controller.
     */
    function __construct()
    {
        parent::__construct();
        $this->load->model('custom_pages');
        $this->load->model('discussions');
        $this->load->model('discussion_topics');
        $this->load->model('discussion_replies');
        $this->load->library('form_validation');
        $this->load->library('unit_test');
        $this->check_account_level(3); // Must have administrator privileges to do anything here.
    }

    /**
     * Loads the page given a page_id.
     * @param $page_id Identifies the page record to pull the from the database.
     * @param int $page_number The page number for displaying the results of the discussion/comments query.
     * @param int $results_per_page The query results to display per page.
     */
    function load($page_id, $page_number = 1, $results_per_page = 20)
    {
        // Go ahead and set the title for the page.
        $this->data['title'] = $this->custom_pages->get_title($page_id)->row()->title;

        // Soon to remove.
        //$this->data['author'] = $this->custom_pages->get_author_of_page($page_id)->row()->username; Don't need

        // Data from the `custom_pages` table.
        $this->data['page_data'] = $this->custom_pages->get_custom_page($page_id);

        // Not needed. Soon to be removed.
        $this->data['discussion_data'] = $this->discussions->get_by_custom_page($page_id);

        // Get discussion topics (comments).
        $this->data['discussion_topics'] =
            $this->discussion_topics->
            get_by_discussion_board_by_page(
                $this->data['page_data']->row()->discussion_board_id,
                $page_number,
                $results_per_page
            );

        // Get data for each of the replies of each discussion topic. Will be accessed from the view as...
        // $discussion_replies[{reply_id}] .
        foreach ($this->data['discussion_topics']->result() as $row)
        {
            $topic_id = $row->discussion_topic_id;
            $this->data['discussion_replies'][$topic_id] =
                $this->discussion_replies->get_by_discussion_topic_id($topic_id);
        }

//        if ( isset($this->data['discussion_topics']->row()->discussion_topic_id))
//        {
//            $replies = $this->data['discussion_topics']->row()->discussion_topic_id;
//            $this->data['discussion_replies'] = $this->discussion_replies->get_by_discussion_topic_id($replies);
//        }

        // Configure pagination.
        if ( $this->data['discussion_topics']->num_rows() > 0) // Are there any discussion topics (comments)?
        {
            $DISCUSSION_BOARD_ID = $this->data['page_data']->row()->discussion_board_id;
            $RESULTS_PER_PAGE = $results_per_page;
            $NUMBER_OF_ROWS = $this->discussion_topics->get_by_discussion_board($DISCUSSION_BOARD_ID)->num_rows();
            $CURRENT_PAGE = $page_number;
            // Load pagination into the $data[] array from within MY_Controller so it is accessible within the view.
            $this->pagination($NUMBER_OF_ROWS, $RESULTS_PER_PAGE, $CURRENT_PAGE);
        }


        $this->data['reply_data'] = $this->discussions->replies_by_custom_page($page_id);
        //die(var_dump($this->data['reply_data']));
        $this->load->view('templates/header', $this->data);
        $this->load->view('custom/custom_page', $this->data);
        $this->load->view('templates/footer', $this->data);
    }

    /**
     * Loads the edit-a-page page when passed the page_id.
     * @param $page_id Unique identifier for the custom page.
     */
    function edit($page_id)
    {
        $this->data['page_data'] = $this->custom_pages->get_custom_page($page_id);
        $this->data['title'] = 'Edit: ' . $this->data['page_data']->row()->title;
        $this->load->view('templates/header', $this->data);
        $this->load->view('custom/edit_custom_page', $this->data);
        $this->load->view('templates/footer', $this->data);
    }

    /**
     * Loads the create-a-page page.
     */
    function create()
    {
        $this->data['title'] = 'Create Custom Page';
        $this->load->view('templates/header', $this->data);
        $this->load->view('custom/create_custom_page', $this->data);
        $this->load->view('templates/footer', $this->data);
    }

    /**
     * Validate custom page form and record to database if validation is successful.
     */
    function submit_create()
    {
        // Validate the form. The password will be checked through the check_password() function.
        $this->form_validation->set_rules('account_level_option', 'Audience', 'trim|required|xss_clean');
        $this->form_validation->set_rules('custom_page_title', 'Title', 'trim|required|xss_clean');
        $this->form_validation->set_rules('custom_page_body', 'Body Text', 'trim|required'); // Filter XSS later.
        $this->form_validation->set_rules('user_id_hidden', 'User ID', 'trim|required|xss_clean');

        // Unit testing.
        $this->unit_test($this->input->post('user_id_hidden'), 'is_integer', 'User ID Numbers must be integers');

        if ($this->form_validation->run() == FALSE)
        { // If form validation fails, send back to suggestion page with errors.
            $this->data['title'] = 'Create Custom Page';

            $this->session->set_flashdata('validation_errors', validation_errors());
            redirect('dashboard/custom_pages/create');
        }
        else // Form validation successful.
        {
            // Gather data from post variables.
            $user_id = $this->input->post('user_id_hidden');
            $account_level_option = $this->input->post('account_level_option');
            $custom_page_title = $this->input->post('custom_page_title');
            $custom_page_body = $this->input->post('custom_page_body');

            // Clean up body content using HTMLPurifier defined in MY_Controller.
            // This will allow iframe youtube elements to appear and store correctly.
            $custom_page_body = $this->clean_html($custom_page_body);

            // Insert into DB.
            $this->custom_pages->insert(
                $custom_page_title,
                $custom_page_body,
                $account_level_option,
                $user_id
            );

            // Redirect user to suggestions page with success message.
            $this->data['title'] = '';
            $this->session->set_flashdata(
                'success',
                '<h4>Your page was successfully created!</h4><div class="text-center"><a href="dashboard/custom_pages" class="btn btn-info">' .
                'Return to the dashboard</a></div>'
                );
            redirect('dashboard/custom_pages/create');
        }
    }

    /**
     * Handles the edit-a-page form.
     */
    function submit_edit()
    {
        // Validate the form. The password will be checked through the check_password() function.
        $this->form_validation->set_rules('account_level_option', 'Audience', 'trim|required|xss_clean');
        $this->form_validation->set_rules('custom_page_title', 'Title', 'trim|required|xss_clean');
        $this->form_validation->set_rules('custom_page_body', 'Body Text', 'trim|required');
        $this->form_validation->set_rules('user_id_hidden', 'User ID', 'trim|required|xss_clean');
        $this->form_validation->set_rules('page_id_hidden', 'Page ID', 'trim|required|xss_clean');

        // Unit testing.
        //$this->_unit_test_this();

        if ($this->form_validation->run() == FALSE)
        { // If form validation fails, send back to suggestion page with errors.
            $this->data['title'] = 'Create Custom Page';

            $this->session->set_flashdata('validation_errors', validation_errors());
            redirect('dashboard/custom_pages/create');
        }
        else // Form validation successful.
        {
            // Gather data from post variables.
            $user_id = $this->input->post('user_id_hidden');
            $page_id = $this->input->post('page_id_hidden');
            $account_level_option = $this->input->post('account_level_option');
            $custom_page_title = $this->input->post('custom_page_title');
            $custom_page_body = $this->input->post('custom_page_body');

            // Clean up body content using HTMLPurifier defined in MY_Controller.
            // This will allow iframe youtube elements to appear and store correctly.
            $custom_page_body = $this->clean_html($custom_page_body);

            // Insert into DB.
            $this->custom_pages->update(
                $page_id,
                $custom_page_title,
                $custom_page_body,
                $account_level_option,
                $user_id
            );

            // Redirect user to suggestions page with success message.
            $this->data['title'] = 'Edit Success';
            $this->session->set_flashdata(
                'success',
                '<h4>Your page was successfully modified!</h4><div class="text-center">' .
                '<a href="'. base_url() . 'dashboard/custom_pages" class="btn btn-info">' .
                'Return to the dashboard</a></div>'
            );
            redirect('dashboard/custom_pages/edit/' . $page_id);
        }
    }

    /**
     * Deletes a custom page of the specified page ID.
     * @param $page_id
     * @throws PHPUnit_Framework_Exception
     */
    function submit_delete($page_id)
    {
        if ( ! $this->custom_pages->delete($page_id))
        {
            show_error('Error: Unable to delete custom page. Please try again later. ');
        }
        else
        {
            $this->session->set_flashdata('success', 'Custom page ' . '(PageID: ' . $page_id . ') was successfully deleted.');
            redirect('dashboard/custom_pages');
        }
    }

    /**
     * Compare actual and intended output.
     * @param $actual The actual output for the test.
     * @param $expected The expected output for the test.
     * @param $description A description of the test.
     */
    function unit_test($actual, $expected, $description)
    {
        $this->load->library('unit_test');
        $this->unit->run($actual, $expected, $description);
    }

    /**
     * Test unit test function.
     */
    private function _unit_test_this()
    {
        // Unit testing.
        $this->unit_test($this->input->post('user_id_hidden'), 'is_integer', 'User ID Numbers must be integers');
        $this->unit_test($this->input->post('page_id_hidden'), 'is_integer', 'Page ID Numbers must be integers');
    }

}