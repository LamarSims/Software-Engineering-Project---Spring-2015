<?php
/**
 * Created by PhpStorm.
 * User: cg03734
 * Date: 3/9/2015
 * Time: 12:34 PM
 */

class Users_controller extends MY_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->model('user');
        $this->load->model('images');
        if ( ! $this->is_logged_in())
        {
            show_error('403: Forbidden. You do not have permission to view this page.');
        }
    }

    function view_profile()
    {
        $user_id = $this->session->userdata('user_id');
        $this->data['user_data'] = $this->user->get_by_id($user_id);
        $this->view_page('profile');
    }

    /**
     * Uploads a file to the /submitted_images directory. If the upload fails an error message will be sent back
     * to the upload page.
     */
    public function do_upload()
    {
        $config = array(
            'upload_path' => "./submitted_images/",
            'allowed_types' => "gif|jpg|png|jpeg|pdf",
            'overwrite' => TRUE,
            'max_size' => "2048000", // Can be set to particular file size , here it is 2 MB(2048 Kb)
            'max_height' => "1400",
            'max_width' => "1400",
            'file_name' => $this->images->get_maxid()
        );

        //die(var_dump($config));
        $this->load->library('upload', $config);
        if ($this->upload->do_upload()) {
            $this->data['upload_data'] = array('upload_data' => $this->upload->data());


            //send picture to be uploaded to the database
            $this->user->insert_image($this->session->userdata('user_id'),
                'submitted_images/',
                $this->data['upload_data']['upload_data']['file_ext']);
            redirect('profile');
            //$this->load->view('upload/upload_success', $this->data);
        } else {
            //die(var_dump($config));
            $error = array('error' => $this->upload->display_errors());
            // $this->load->view('upload/file_view', $error);
            redirect('profile');
        }
    }

    function delete_user_profile_image(){
        $this->user->delete_profile_image($this->user->get_user_image($this->session->userdata('user_id'))->row()->image_id);
        redirect('profile');
    }

    function view_upload_template($view, $data = array('error' => ' '))
    {
        $this->data['title'] = $view;
        $this->load->view('templates/header', $this->data);
        $this->load->view('upload/profile', $data);
        $this->load->view('templates/footer', $this->data);
    }

}