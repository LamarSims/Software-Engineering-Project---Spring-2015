<?php 
class News_article_controller extends MY_Controller
{
    /**
     * Class constructor for the News Article controller.
     */
	function __construct() {
		parent::__construct();
	}
	
	function view()
	{
		$this->load->model('news_article');
		$this->data['news_query'] = $this->news_article->get();
		$this->data['title'] = 'News';
		$this->load->view('templates/header', $this->data);
		$this->load->view('news', $this->data);
		$this->load->view('templates/footer', $this->data);
	}
	
	function insert() 
	{

		$title = $this->input->post('article_title');
		$body = $this->input->post('body');
		
		$news = array(
				'title' => $title,
				'body' => $body
		);
		
		$this->load->model('news_article');
		$this->news_article->insert($news['title'], $news['body']);
		
		$this->view();
	}
	
	function article($news_id)
	{
		$this->load->model('news_article');
		
		if ($this->data['article'] = $this->news_article->get_by_id($news_id))
		{
			$this->data['title'] = $this->data['article']->title;
			$this->load->view('templates/header', $this->data);
			$this->load->view('news/view_article', $this->data);
			$this->load->view('templates/footer', $this->data);
		}
		else
		{
			show_404();
		}
	}
}