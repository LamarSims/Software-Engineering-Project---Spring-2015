<?php
/**
 * Controls the flow of login between the dashboard modules. Its purpose is to allow an accoutn of appropriate
 * account level to manage the main content of the system.
 * Created by PhpStorm.
 * User: Chad
 * Date: 3/5/2015
 * Time: 10:29 PM
 */
class Dashboard_controller extends MY_Controller
{

    /**
     * Class constructor for the dashboard controller. Loads the suggestions, users, and custom pages models.
     */
    function __construct()
    {
        parent::__construct();
        $this->load->model('suggestions');
        $this->load->model('user');
        $this->load->model('custom_pages');
    }

    /**
     * Loads the module (dashboard page) within the dashboard skeleton.
     * Checks if user has rights to view dashboard.
     * @param string $module_name The page within the dashboard.
     */
    public function load($module_name = 'overview')
    {
        if ($this->has_rights())
        {
            $this->load_module($module_name);
        }
        else
        {
            show_error('403: You are not authorized to view this page.', 403);
        }
    }

    /**
     * Sandwiches the specified module within the dashboard template.
     * @param string $module_name The name of the page within the dashboard.
     */
    public function load_module($module_name = 'overview')
    {
        $this->data['ordered_suggestions'] = $this->suggestions->get_order_by_date();
        $this->data['users_table'] = $this->user->get();
        foreach($this->data['users_table']->result() as $row){
            $this->data['account_level'][$row->user_id] = $this->user->get_title($row->account_level);
        }
        $this->data['custom_pages_table'] = $this->custom_pages->get();
        if ($module_name == 'site_information')
        {
            $this->load->model('dynamic_content');
            $this->data['dynamic_content_about'] = $this->dynamic_content->get_by_id('about');
            $this->data['dynamic_content_contact'] = $this->dynamic_content->get_by_id('contact');
        }
        if ($module_name == 'manage_tags' || $module_name == 'videos')
        {
            $this->load->model('tags');
            $this->data['tags'] = $this->tags->get();
        }
        if ($module_name == 'manage_user_roles')
        {
            $this->load->model('roles');
            $this->load->model('user');
            $this->data['members'] = $this->user->get_by_account_level(1);
            $this->data['roles_table'] = $this->roles->get_all();
            $this->data['roles'][0] = '';
            foreach ($this->data['roles_table']->result() as $role)
            {
                $this->data['roles'][$role->role_id] = $role->role_name;
            }

            // Create a select list for use inside view.
            $this->data['role_select_list'] =
                '<select class="form-control" style="width: inherit; display: inline;" name="role_select_list">';
            foreach ($this->data['roles_table']->result() as $role)
            {
                $this->data['role_select_list']
                    .= '<option value="' . $role->role_id . '">' . $role->role_name . '</option>';
            }
            $this->data['role_select_list'] .= '</select>';

        }
        $this->load_view('templates/header', $module_name);
        $this->load_view('dashboard/skeleton_top', $module_name);
        $this->load_view('dashboard/' . $module_name);
        $this->load_view('dashboard/skeleton_bottom', $module_name);
        $this->load_view('templates/footer', $module_name);
    }

    /**
     * Does the account (session) have the right to view this page?
     * @return bool The user may view this page.
     */
    public function has_rights()
    {
        return $this->session->userdata('account_level') >= 2;
    }

    /**
     * Deletes a specified suggestion record.
     * @param $suggestion_id The ID of the suggestion record.
     */
    public function delete_suggestion($suggestion_id)
    {
        if ( ! $this->has_rights()) {
            show_error('Invalid operation: You do not have permission to that.');
        }
        if ($this->suggestions->delete($suggestion_id))
        {
            redirect('dashboard');
        }
    }

    public function insert_role()
    {
        $this->load->model('roles');
        // Validate the form.
        $this->load->library('form_validation');
        $this->form_validation->set_rules('insert_role_name', 'Role Name', 'trim|required|xss_clean');
        $this->form_validation->set_rules('insert_role_description', 'Role Description', 'trim|required|xss_clean');

        if ($this->form_validation->run() == FALSE)
        { // If form validation fails, send back to suggestion page with errors.
            $this->data['title'] = 'Manage User Roles';

            $this->session->set_flashdata('errors', validation_errors());
            redirect('dashboard/manage_user_roles');
        }
        else // Form validation successful.
        {
            // Gather data from post variables.
            $role_name = $this->input->post('insert_role_name');
            $role_description = $this->input->post('insert_role_description');

            // Insert into DB.
            $insert_params = array(
                'role_name' => $role_name,
                'role_description' => $role_description
            );
            $this->roles->insert(
                $insert_params
            );

            // Redirect user to suggestions page with success message.
            $this->data['title'] = 'Manage User Roles';
            $this->session->set_flashdata('success', 'You successfully added a role!');
            redirect('dashboard/manage_user_roles');
        }
    }

    public function update_user_role()
    {
        $role_id = $this->input->post('role_select_list');
        $user_id = $this->input->post('hidden_user_id');

        $this->load->model('user');

        if ($this->user->update_user_role($user_id, $role_id))
        {
            $this->session->set_flashdata('success', 'You have updated the user\'s role.');
            redirect('dashboard/manage_user_roles');
        }
        else
        {
            $this->session->set_flashdata('errors', 'Unable to update the user\'s role.');
            redirect('dashboard/manage_user_roles');
        }
    }

    /**
     * Adjusts the specified user to the specified account level.
     * @param $user_id
     * @param $account_level
     * @throws PHPUnit_Framework_Exception
     */
    public function adjust_user_account_level($user_id, $account_level)
    {

        if ( ! $this->has_rights()) {
            show_error('Invalid operation: You do not have permission to that.');
        }
        if ($this->user->update_account_level($user_id, $account_level))
        {
            redirect('dashboard/manage_users');
        }
    }



}