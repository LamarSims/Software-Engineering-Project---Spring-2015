<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class Verify_Login
 * Handles the process of logging in a user to the system using sessions and the database.
 * @package login_system
 */
class Verify_Login extends MY_Controller implements Unit_testable {
    public $area_count = 0;
	/**
     * Class constructor for this controller. Loads the user model, form validation, session, and security libraries.
     */
	function __construct()
	{
		parent::__construct();
		$this->load->model('user','',TRUE);
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->library('security');
        $this->load->library('unit_test');
        //$this->data['coverage_amount'] = $this->test();
        if (parent::is_unit_test_active()){
            $this->load->model('unit_test_results');
            $this->unit->run('String that is equal', 'String that is equal', 'Unit Test test...');
            $this->test1();
            $this->test2();
            $this->test3();
            $this->test4();
            $this->test5();

            $results = $this->unit->result();

            foreach ($results as $result)
            {
                $insertion_array = array(
                    'test_name' =>  $result['Test Name'],
                    'test_datatype' => $result['Test Datatype'],
                    'expected_datatype' => $result['Expected Datatype'],
                    'result' => $result['Result'],
                    'file_name' => $result['File Name'],
                    'line_number' => $result['Line Number'],
                    'notes' => $result['Notes'],
                    'coverage' => $this->area_count,
                );
                $this->unit_test_results->insert($insertion_array);
            }

            $this->load->model('unit_tests');
            $this->unit_tests->insert($this->area_count);
        }

	}

    /**
     * Verifies form information from a login form.
     * @param string $form_location Location of the form. (e.g. Navbar, Login page).
     */
	function verify($form_location = 'login_system')
	{
		// Validate the form. The password will be checked through the check_password() function.
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|xss_clean');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean|callback_check_password');

		if($this->form_validation->run() == FALSE)
		{
			// Validation failed. Redirect to the login_system page.
			$data['title'] = 'Login';
			
			// Set temporary session data to reflect the validation errors when redirecting to the login_system page.
			$this->session->set_flashdata('validation_errors', validation_errors());

			redirect('login');
// 			$this->load->view('templates/header', $data);
// 			$this->load->view('pages/login_system', $data);
// 			$this->load->view('templates/footer', $data);
		}
		else // LOGIN SUCCESS! Now we need to do the session data.
		{
			// Log session data.
			$result = $this->user->get_by_email($this->input->post('email'));
			
			$session_data = array(
				'logged_in' => TRUE,
				'user_id' => $result->user_id,
				'username' => $result->username,
				'email' => $result->email,
				'password' => $result->password,
				'account_level' => $result->account_level	
			);
			
			// Go back home.
			$this->session->set_userdata($session_data);
			redirect('home', 'refresh');
		}
	}

    /**
     * Checks the email and password combination against the database. Callback for the form validation.
     * @return bool Is the combination valid?
     */
	function check_password()
	{
		// Get email and input password variables from post and clean them up.
		$email          = $this->security->xss_clean($this->input->post('email'));
		$input_password = $this->security->xss_clean($this->input->post('password'));
		
		if (!$email_exists = $this->user->get_by_email($email)) // Email does not exist in the database. Combination is therefore wrong.
		{
			$this->form_validation->set_message('check_password', 'Invalid email address and password combination.');
			return FALSE; // If the email doesn't exist, we end here.
		}
		else // The email exists, now get ready to check the password.
		{
			$database_hash = $email_exists->password;
		}

		// Match the supplied password with the database password. (Bcrypt method)
		if ($predicate = password_verify($input_password, $database_hash))
		{
			return TRUE; // They match.
		}
		else 
		{
			// They do not match. Set error message to reflect this.
			$this->form_validation->set_message('check_password', 'Invalid email address and password combination.');
			return FALSE;
		}
	}

    /**
     * Destroys the user's current session and redirects them to the home page. Thus they are logged out.
     */
	function logout()
	{
		$this->session->sess_destroy();
		redirect('home', 'refresh');
	}

    /**
     * Run some meaningful tests for this component and store the results in the database table.
     */
    public function test()
    {
        $area_count = 0;
        if (parent::is_unit_test_active())
        {
            $this->load->model('unit_test_results');
            $this->unit->run('String that is equal', 'String that is equal', 'Unit Test test...');

            //$this->load->model('user');


            if ($user_id = $this->session->userdata('user_id')) // Does user_id exist?
            {
                // Match user account level with session account level.
                $user_account_level = $this->user->get_by_id($user_id)->account_level;
                $session_account_level = $this->session->userdata('account_level');
                $this->unit->run($user_account_level, $session_account_level,
                    'Actual and session account levels must match.');

                // Force bad password matches
                $password = $this->user->get_by_id($user_id)->password;
                $invalid_password = 'blah';
                $this->unit->run
                ( ! password_verify($invalid_password, $password), true,
                    'Bad password does not match hashed password.');
                ++$area_count;
            }

            // Test invalid password match
            if (!($email = $this->input->post('email')) && !($password_attempt = $this->input->post('password'))){
                $area_count++;
                $no_input = $email && $password_attempt;
                $this->unit->run(
                    $no_input, true, 'No email or password specified!'
                );
            }
            else if (!($email = $this->input->post('email')) && ($password_attempt = $this->input->post('password'))){
                $area_count++;
                $no_input = $email && $password_attempt;
                $this->unit->run(
                    $no_input, true, 'No email specified!'
                );
            }
            else if (($email = $this->input->post('email')) && !($password_attempt = $this->input->post('password'))){
                $area_count++;
                $no_input = $email && $password_attempt;
                $this->unit->run(
                    $no_input, true, 'No password specified!'
                );
            }
            else if (($email = $this->input->post('email')) && ($password_attempt = $this->input->post('password')))
            {
                //die ($email . '    password:   ' . $password_attempt);
                if ($user = $this->user->get_by_email($email))
                {
                    $database_password = $user->password;
                    $this->unit->run(
                        password_verify($password_attempt, $database_password), true, 'Bad password attempt'
                    );
                    $area_count++;
                }
                $area_count++;

            }

            // Test invalid ID numbers.
            /*$bad_id_number = 'awawefawn;239fw}#133';
            $this->unit->run
            ( is_numeric($bad_id_number), false, 'Good ID numbers are numeric.');

            // Bad ID number returns 0 results from DB.
            $result = $this->user->get_by_id($bad_id_number);
            $number_of_elements = count($result);
            $this->unit->run
            ( $number_of_elements == 0, true, 'No results should be returned from bad ID number.');*/

            $results = $this->unit->result();

            foreach ($results as $result)
            {
                $insertion_array = array(
                    'test_name' =>  $result['Test Name'],
                    'test_datatype' => $result['Test Datatype'],
                    'expected_datatype' => $result['Expected Datatype'],
                    'result' => $result['Result'],
                    'file_name' => $result['File Name'],
                    'line_number' => $result['Line Number'],
                    'notes' => $result['Notes'],
                    'coverage' => $area_count,
                );
                $this->unit_test_results->insert($insertion_array);
            }
        }

        $this->load->model('unit_tests');
        $this->unit_tests->insert($area_count + 1);
        //$this->data['area_count'] = $this->unit_tests->get()->result()->row()->coverage;

        return $area_count;
    }

    function test1(){
        if (parent::is_unit_test_active()){
            if ($user_id = $this->session->userdata('user_id')) // Does user_id exist?
            {
                // Match user account level with session account level.
                $user_account_level = $this->user->get_by_id($user_id)->account_level;
                $session_account_level = $this->session->userdata('account_level');
                $this->unit->run($user_account_level, $session_account_level,
                    'Actual and session account levels must match.');

                // Force bad password matches
                $password = $this->user->get_by_id($user_id)->password;
                $invalid_password = 'blah';
                $this->unit->run
                ( ! password_verify($invalid_password, $password), true,
                    'Bad password does not match hashed password.');
                ++$this->area_count;
            }
        }
    }

    function test2(){
        if (parent::is_unit_test_active()){
            $email = $this->input->post('email');
            $password_attempt = $this->input->post('password');
            if (!$email && !$password_attempt){
                $this->area_count++;
                $no_input = $email && $password_attempt;
                $this->unit->run(
                    $no_input, true, 'No email or password specified!'
                );
            }else{
                $this->area_count++;
                $no_input = $email && $password_attempt;
                $this->unit->run(
                    !$no_input, true, 'Email or password specified!'
                );
            }
        }
    }

    function test3(){
        if (parent::is_unit_test_active()){
            $email = $this->input->post('email');
            $password_attempt = $this->input->post('password');
            if (!$email && $password_attempt || (!$email && !$password_attempt)){
                $this->area_count++;
                $no_input = $email && $password_attempt;
                $this->unit->run(
                    $no_input, true, 'No email specified!'
                );
            }else{
                $this->area_count++;
                $no_input = $email && $password_attempt;
                $this->unit->run(
                    !$no_input, true, 'Email was specified!'
                );
            }
        }
    }

    function test4(){
        if (parent::is_unit_test_active()){
            $email = $this->input->post('email');
            $password_attempt = $this->input->post('password');
            if ($email && !$password_attempt || (!$email && !$password_attempt)){
                $this->area_count++;
                $no_input = $email && $password_attempt;
                $this->unit->run(
                    $no_input, true, 'No password specified!'
                );
            }else{
                $this->area_count++;
                $no_input = $email && $password_attempt;
                $this->unit->run(
                    !$no_input, true, 'Password was specified!'
                );
            }
        }
    }

    function test5(){
        if (parent::is_unit_test_active()){
            if (($email = $this->input->post('email')) && ($password_attempt = $this->input->post('password')))
            {
                //die ($email . '    password:   ' . $password_attempt);
                $user = $this->user->get_by_email($email);
                $database_password = $user->password;
                if ($user && !password_verify($password_attempt, $database_password))
                {

                    $this->unit->run(
                        password_verify($password_attempt, $database_password), true, 'Bad password attempt'
                    );
                    $this->area_count++;
                }else{
                    $this->area_count++;

                    $this->unit->run(
                        password_verify($password_attempt, $database_password), true, 'Good password!'
                    );
                }
                $this->area_count++;

            }
        }
    }
}