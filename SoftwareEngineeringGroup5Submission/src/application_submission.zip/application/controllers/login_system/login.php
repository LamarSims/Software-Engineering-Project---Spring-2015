<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class Login
 * @package login_system
 * @deprecated Replaced by Verify_login.php and register_controller.php.
 */
class Login extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
	}
	
	function index()
	{
		$this->load->helper(array('form'));
		$this->load->view('pages/login_system');
	}
	
	function verify()
	{
		$this->load->helper(array('form'));
		$this->load->model('user');

		$login['email'] = $this->input->post('email');
		$login['password'] = $this->input->post('password');
		
		if ($this->user->getuser($login['email'], $login['password']))
		{
			redirect('home');
		}
		else
		{
			$this->error('Login Error', 'Invalid username and password combination.');
		}
	}
	
	public function error($error_header, $error_message)
	{
		$data['title'] = 'Error';
		$data['error_header'] = $error_header;
		$data['error_message'] = $error_message;
		$this->load->view('templates/header', $data);
		$this->load->view('errors/error', $data);
		$this->load->view('templates/footer', $data);
	}
}
