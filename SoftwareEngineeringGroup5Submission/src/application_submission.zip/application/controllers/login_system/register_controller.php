<?php

/**
 * Class Register_controller
 * Processes user input for the registration form view. Upon registration requirements being met,
 * the user will be registered into the database.
 * @package login_system
 */
class Register_controller extends MY_Controller
{
    /**
     * No-arg class constructor for this controller.
     */
	public function __construct() 
	{
		parent::__construct();
	}

    /**
     * @deprecated
     */
	public function index()
	{
		$this->load->model('user');
		
		$register['username'] = $this->input->post('username');
		$register['email'] = $this->input->post('email');
		$register['password'] = sha1($this->input->post('password'));
		
		
		if ($this->user->insertuser($register['username'], $register['email'], $register['password']))
		{
			die('Registration Successful!');
		}
		else
		{
			die('Registration unsuccessful!');	
		}
	}

    /**
     * Registration processing for the registration form.
     */
	public function register_user()
	{
		// Load the form validation library.
		$this->load->library('form_validation');
		
		// Load the user model.
		$this->load->model('user');
		
		// Validate input from the registration form
		$this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[3]|max_length[15]|xss-clean');
		$this->form_validation->set_rules('email', 'Email', 'trim|required|min_length[3]|max_length[32]|valid_email|xss-clean|callback_check_email');
        $this->form_validation->set_rules('first_name', 'First Name', 'trim|required|xss-clean');
        $this->form_validation->set_rules('last_name', 'Last Name', 'trim|required|xss-clean');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[4]|max_length[32]|xss-clean');
		$this->form_validation->set_rules('password_conf', 'Confirm Password', 'trim|required|min_length[4]|max_length[32]|xss-clean');
		
		if ($this->form_validation->run() == FALSE) // Registration failed: notify the user on the registration page.
		{
			$data['title'] = 'Registration';
			//$this->load->view('templates/header', $data);
			//$this->load->view('pages/register', $data);
			//$this->load->view('templates/footer', $data);
            $this->view_page('register');
		}
		else // Registration passes form validation: enter the user into the database.
		{
			
			$register['username'] = $this->input->post('username');
			$register['email'] = $this->input->post('email');
            $first_name = $this->input->post('first_name');
            $last_name = $this->input->post('last_name');
			
			// Hash the user password using bcrypt algorithm with CPU cost option of '11'
			$register['password'] = $this->bcrypt_hash($this->input->post('password'));

			// Register user into database.
			// TODO: If a database error occurs here, we have a problem. Consider transaction?
			$this->user->insertuser($register['username'], $register['email'], $register['password'], $first_name, $last_name);

            $this->session->set_flashdata(
                'success',
                'Thank you! You have successfully registered!' .
                ' You may now &nbsp;&nbsp;<a class="btn btn-info btn-sm" href="' . base_url() . '/login_system">Sign In</a>'
            );
            redirect('register');
			// Redirect user to home page upon success.
			//redirect(base_url());
		}
	}

    /**
     * Form validation callback that checks that the provided POST email does not already exist in the database.
     * @return bool Does the email exist in the database already?
     */
	public function check_email()
	{
		// Get email from input
		$email = $this->input->post('email');
		
		if ($email_exists = $this->user->get_by_email($email)) 
		{
			// Email address already exists in the database.
			$this->form_validation->set_message('check_email', 'That username or email address is already registered.');
			return FALSE;
		}
		else
		{
			// The supplied email address doesn't exist already. Good to go.
			return TRUE;
		}
	}

    /**
     * Returns a hashed password using the BCrypt algorithm for PHP.
     * @param $unhashed_password string The raw password text. (Could also use POST variable).
     * @return bool|string The BCrypt hashed password.
     */
	public function bcrypt_hash($unhashed_password)
	{
		// Options for bcrypt hash. CPU cost of 11 should suffice for now.
        // Any higher causes concern for registration overload denial-of-service attack.
		$options = array(
				'cost' => 11
		);
		
		return password_hash($unhashed_password, PASSWORD_BCRYPT, $options);
	}
}
