<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class Upload_controller
 *
 * Handles the upload of files to the web server.
 *
 * @package files
 *
 */
class Upload_controller extends MY_Controller
{

    /**
     * Default no-arg class constructor for this controller.
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->model('images');
    }

    /**
     * Loads the view containing a file upload form.
     */
    public function file_view()
    {
        // $this->load->view('upload/file_view', array('error' => ' ' ));
        $this->view_upload_template('file_view');
    }

    /**
     * Uploads a file to the /submitted_images directory. If the upload fails an error message will be sent back
     * to the upload page.
     */
    public function do_upload()
    {
        $config = array(
            'upload_path'   => "./submitted_images/",
            'allowed_types' => "gif|jpg|png|jpeg|pdf",
            'overwrite'     => TRUE,
            'max_size'      => "2048000", // Can be set to particular file size , here it is 2 MB(2048 Kb)
            'max_height'    => "1400",
            'max_width'     => "1400",
            'file_name'     => $this->images->get_maxid()
        );
        //die(var_dump($config));
        $this->load->library('upload', $config);
        if ($this->upload->do_upload())
        {
            $this->data['upload_data'] = array('upload_data' => $this->upload->data());
            $this->view_upload_template('upload_success', $this->data['upload_data']);

            //send picture to be uploaded to the database
            $this->images->insert_image('submitted_images/',
                                        $this->data['upload_data']['upload_data']['file_ext']);
            //$this->load->view('upload/upload_success', $this->data);
        }
        else
        {
            $error = array('error' => $this->upload->display_errors());
            // $this->load->view('upload/file_view', $error);
            $this->view_upload_template('file_view', $error);
        }
    }

    /**
     * Loads the specified view within the /upload directory sandwiched between the website header and footer.
     *
     * @param string $view The view within the /upload directory in which to load.
     * @param array  $data The error or success information to be passed to the view.
     */
    function view_upload_template($view, $data = array('error' => ' '))
    {
        $this->data['title'] = $view;
        $this->load->view('templates/header', $this->data);
        $this->load->view('upload/' . $view, $data);
        $this->load->view('templates/footer', $this->data);
    }

}
