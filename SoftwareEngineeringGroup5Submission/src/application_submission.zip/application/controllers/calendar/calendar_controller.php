<?php
/**
 * Created by PhpStorm.
 * User: chad & oneal
 * Date: 2/12/15
 * Time: 10:40 AM
 */

class calendar_controller extends MY_Controller
{

    function __construct()
    {
        parent::__construct();
        /*commented out until database model is set up for event*/
        //$this->load->model('event_submission');
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->library('security');
        $this->load->model('events');
    }

    function load($month = -1, $year = -1)
    {
        if ($month == -1)
        {
            $month = date('n');
        }

        if ($year == -1)
        {
            $year = date('Y');
        }

        $this->data['calendar_data']['current_month'] = $month;
        $this->data['calendar_data']['current_year'] = $year;
        $this->data['calendar_data']['is_leap_year'] = $this->isLeapYear($year);
        $this->data['calendar_data']['start_day'] = $this->getStartDay($year, $month);
        $this->data['calendar_data']['current_day_of_month'] = $this->get_current_day_of_month();
        $this->data['calendar_data']['days_in_current_month'] = $this->getNumberOfDaysInMonth($year,$month);


        $this->data['title'] = 'Events Calendar';

        // Days of the week for the calendar headings
        $this->data['calendar_data']['day_heading'] = array(
            'Sunday',
            'Monday',
            'Tuesday',
            'Wednesday',
            'Thursday',
            'Friday',
            'Saturday'
        );

        // A running day.
        //$this->data['calendar_data']['day'] = date('w', mktime(0, 0, 0, $month, 1, $year));

        $this->data['get_current_day'] = $this->get_current_day();
        $this->data['all_events'] = $this->events->get_all_rows();

        $this->load->view('templates/header', $this->data);
        $this->load->view('pages/events', $this->data);
        $this->load->view('templates/footer', $this->data);

    }

    function get_current_day() {
        return date('l');
    }

    function get_current_day_of_month(){
        return date('j');
    }

    function submit_event(){
        // Validate the form. The password will be checked through the check_password() function.
        $this->form_validation->set_rules('event_name', 'Event Name', 'trim|required|xss_clean');
        $this->form_validation->set_rules('date', 'Date', 'trim|required|xss_clean');
        $this->form_validation->set_rules('time', 'Time', 'trim|required|xss_clean');
        $this->form_validation->set_rules('location', 'Location', 'trim|required|xss_clean');
        $this->form_validation->set_rules('event_description', 'Event Description', 'trim|required|xss_clean');

        if ($this->form_validation->run() == FALSE)
        { // If form validation fails, send back to suggestion page with errors.
            $this->data['title'] = 'Events';

            $this->session->set_flashdata('validation_errors', validation_errors());
            redirect('event_submission');
        }
        else // Form validation successful.
        {
            // Gather data from post variables.
            $event_name = $this->input->post('event_name');
            $date = $this->input->post('date');
            $time = $this->input->post('time');
            $location = $this->input->post('location');
            $event_description = $this->input->post('event_description');

            // Insert into DB.
            //Commented out until DB model for events is set up
            $this->events->insert_event(
                $event_name,
                $date,
                $time,
                $location,
                $event_description
            );

            // Redirect user to suggestions page with success message.
            $this->data['title'] = 'Events';
            $this->session->set_flashdata('success', 'Thank you! Your event was successfully submitted.');
            redirect('event_submission');
        }
    }

    /**
     * Retrieves an event_id from HTTP POST and attempts to remove it from the database.
     */
    public function delete_event()
    {

        $event_id_to_delete = $this->input->post('hidden_event_id');

        if ($this->events->delete_event($event_id_to_delete))
        {
            $this->session->set_flashdata('success', 'You have successfully deleted event #' . $event_id_to_delete);
            redirect('events');
        }
        else
        {
            $this->session->set_flashdata('errors', 'There was a problem submitting your request.');
            redirect('view_event/' . $event_id_to_delete);
        }

    }
    
    /** Print month body */
    function printMonthBody($year, $month) {
    	// Get start day of the week for the first date in the month
    	$startDay = getStartDay($year, $month);
    
    	// Get number of days in the month
    	$numberOfDaysInMonth = getNumberOfDaysInMonth($year, $month);
    
    	// Pad space before the first day of the month
    	$i = 0;
    	for ($i = 0; $i < startDay; $i++)
    		System.out.printf("    ");
    
    		for ($i = 1; $i <= $numberOfDaysInMonth; $i++) {
    		System.out.printf("%4d", $i);
    
    		if (($i + $startDay) % 7 == 0)
    			System.out.println();
    		}
    
    		System.out.println();
    }
    
    /** Get the start day of month/1/year */
    function getStartDay($year, $month) {
    	$START_DAY_FOR_JAN_1_1800 = 3;
    	// Get total number of days from 1/1/1800 to month/1/year
    	$totalNumberOfDays = $this->getTotalNumberOfDays($year, $month);
    
    	// Return the start day for month/1/year
    	return ($totalNumberOfDays + $START_DAY_FOR_JAN_1_1800) % 7;
    }
    
    /** Get the total number of days since January 1, 1800 */
    function getTotalNumberOfDays($year, $month) {
    	$total = 0;
    
    	// Get the total days from 1800 to 1/1/year
    	for ($i = 1800; $i < $year; $i++)
    		if ($this->isLeapYear($i))
    			$total = $total + 366;
    			else
    				$total = $total + 365;
    
    				// Add days from Jan to the month prior to the calendar month
    				for ($i = 1; $i < $month; $i++)
    				$total = $total + $this->getNumberOfDaysInMonth($year, $i);
    
    				return $total;
    }
    
    /** Get the number of days in a month */
    function getNumberOfDaysInMonth($year, $month) {
    	if ($month == 1 || $month == 3 || $month == 5 || $month == 7 ||
    			$month == 8 || $month == 10 || $month == 12)
    				return 31;
    
    			if ($month == 4 || $month == 6 || $month == 9 || $month == 11)
    				return 30;
    
    			if ($month == 2) return $this->isLeapYear($year) ? 29 : 28;
    
    			return 0; // If month is incorrect
    }
    
    /** Determine if it is a leap year */
    function isLeapYear($year) {
        if ($year % 400 == 0 || ($year % 4 == 0 && $year % 100 != 0)) {
            return true;
        }
        else {
            return false;
        }
    	//return $year % 400 == 0 || ($year % 4 == 0 && $year % 100 != 0);
    }

    function view_event($event_id)
    {
        $this->data['event_data'] = $this->events->get_event($event_id);
        $this->data['title'] = "View Event";
        $this->load->view('templates/header', $this->data);
        $this->load->view('events/event', $this->data);
        $this->load->view('templates/footer', $this->data);
    }

}