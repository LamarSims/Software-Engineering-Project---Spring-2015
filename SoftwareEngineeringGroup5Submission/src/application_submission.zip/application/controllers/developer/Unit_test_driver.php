<?php
/**
 * Created by PhpStorm.
 * User: cg03734
 * Date: 4/23/2015
 * Time: 2:39 PM
 */

class Unit_test_driver extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('unit_test');
        $this->load->model('unit_test_results');
        $this->load->model('unit_tests');
    }

    public function view()
    {
        $this->data['title'] = 'Unit Test View';
        $this->data['is_running'] = parent::is_unit_test_active();
        $this->data['current_test_results'] = $this->unit_test_results->get_results();
        $this->data['area_count'] = $this->unit_tests->get()->result()[0]->coverage;

        $this->load->view('templates/header', $this->data);
        $this->load->view('developer/unit_test_driver_view', $this->data);
        $this->load->view('templates/footer', $this->data);
    }

    public function start()
    {
        $this->unit_test_results->delete_all();
        $this->session->set_userdata('unit_test_active', true);
        $this->unit->active(TRUE);
        redirect('unit_test_driver/view');
    }

    public function stop()
    {
        $this->session->set_userdata('unit_test_active', false);
        $this->unit->active(FALSE);
        redirect('unit_test_driver/view');
    }

}