<?php
/**
 * Created by PhpStorm.
 * User: Chad
 * Date: 3/24/2015
 * Time: 8:05 PM
 */

class developer_controller extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
        if ( ! $this->has_developer_account())
        {
            $message = 'Error 403: Only developers may access the content of this page.';
            show_error($message);
        }
        $this->load->library('unit_test');
    }

    public function index()
    {
        $this->data['title'] = 'Unit Test';
        $this->_run_unit_tests();
        $this->data['controller_location'] = uri_string();
        $this->load->view('templates/header', $this->data);
        $this->load->view('developer/unit_test', $this->data);
        $this->load->view('developer/unit_test_template', $this->data);
        $this->load->view('templates/footer', $this->data);

    }

    public function view()
    {
        $this->index();
    }

    private function has_developer_account()
    {
        return $this->session->userdata('account_level') >= 7;
    }

    private function _run_unit_tests()
    {
        $this->load->model('user');

        // Match user account level with session account level.
        $user_id = $this->session->userdata('user_id');
        $user_account_level = $this->user->get_by_id($user_id)->account_level;
        $session_account_level = $this->session->userdata('account_level');
        $this->unit->run($user_account_level, $session_account_level, 'Actual and session account levels must match.');

        // Force bad password matches
        $password = $this->user->get_by_id($user_id)->password;
        $invalid_password = 'blah';
        $this->unit->run
            ( ! password_verify($invalid_password, $password), true, 'Bad password does not match hashed password.');

        // Test invalid ID numbers.
        $bad_id_number = 'awawefawn;239fw}#133';
        $this->unit->run
        ( is_numeric($bad_id_number), false, 'Good ID numbers are numeric.');

        // Bad ID number returns 0 results from DB.
        $result = $this->user->get_by_id($bad_id_number);
        $number_of_elements = count($result);
        $this->unit->run
        ( $number_of_elements == 0, true, 'No results should be returned from bad ID number.');


    }

}


function sum($number_one, $number_two)
{
    return $number_one + $number_two;
}