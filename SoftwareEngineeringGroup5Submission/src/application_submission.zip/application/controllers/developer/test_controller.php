<?php

class test_controller extends MY_Controller {

    function __construct()
    {
        parent::__construct();
    }

    function say_hi()
    {
        die('hello');
    }


}